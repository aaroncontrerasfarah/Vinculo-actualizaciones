/* Terapia2 — utilidades de interfaz: escape, gráficos SVG, avisos, modales y archivos. */
"use strict";
const UIX=(()=>{
  const e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const COL={a:'var(--pa)',b:'var(--pb)',t:'var(--accent)',gas:'var(--ink)'};
  const fCorta=f=>{if(!f)return'';const[y,m,d]=f.split('-');return`${+d}/${+m}`};
  const fLarga=f=>{if(!f)return'';const d=MED.aDate(f);return d.toLocaleDateString('es-CL',{weekday:'long',day:'numeric',month:'long'})};

  /* Gráfico de líneas. series:[{nombre,color,datos:[{x,y}],guion}] x categórica (fechas ordenables). */
  function lineas({series,min=0,max=10,corte=null,corteTxt='',alto=170,yfmt=v=>v}){
    const xs=[...new Set(series.flatMap(s=>s.datos.map(d=>d.x)))].sort();
    if(!xs.length)return'<p class="note">Todavía no hay datos para graficar.</p>';
    const W=320,H=alto,L=28,Rr=8,T=10,B=22,iw=W-L-Rr,ih=H-T-B;
    const X=i=>L+(xs.length===1?iw/2:iw*i/(xs.length-1)),Y=v=>T+ih*(1-(v-min)/(max-min));
    let g='';const ticks=max-min<=10?[min,(min+max)/2,max]:[min,Math.round((min+max)/2),max];
    ticks.forEach(t=>{g+=`<line x1="${L}" x2="${W-Rr}" y1="${Y(t)}" y2="${Y(t)}" class="gl"/><text x="${L-5}" y="${Y(t)+3.5}" class="ax" text-anchor="end">${yfmt(t)}</text>`});
    if(corte!=null)g+=`<line x1="${L}" x2="${W-Rr}" y1="${Y(corte)}" y2="${Y(corte)}" class="cut"/><text x="${W-Rr}" y="${Y(corte)-4}" class="ax" text-anchor="end">${e(corteTxt)}</text>`;
    const paso=Math.max(1,Math.ceil(xs.length/6));
    xs.forEach((x,i)=>{if(i%paso===0||i===xs.length-1)g+=`<text x="${X(i)}" y="${H-6}" class="ax" text-anchor="middle">${fCorta(x)}</text>`});
    for(const s of series){const pts=s.datos.filter(d=>d.y!=null).map(d=>[X(xs.indexOf(d.x)),Y(Math.max(min,Math.min(max,d.y))),d]);
      if(!pts.length)continue;
      if(pts.length>1)g+=`<polyline fill="none" stroke="${s.color}" stroke-width="2.4" ${s.guion?'stroke-dasharray="5 4"':''} stroke-linejoin="round" stroke-linecap="round" points="${pts.map(p=>p[0].toFixed(1)+','+p[1].toFixed(1)).join(' ')}"/>`;
      pts.forEach(p=>{g+=`<circle cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="${s.guion?2.6:3.4}" fill="${s.guion?'var(--surface)':s.color}" stroke="${s.color}" stroke-width="2"><title>${e(s.nombre)} · ${fCorta(p[2].x)}: ${p[2].y}</title></circle>`})}
    const ley=series.filter(s=>s.datos.some(d=>d.y!=null)).map(s=>`<span class="ley"><i style="border-color:${s.color};${s.guion?'border-style:dashed':''}"></i>${e(s.nombre)}</span>`).join('');
    return`<svg class="chart" viewBox="0 0 ${W} ${H}" role="img">${g}</svg><div class="leyenda">${ley}</div>`}

  function toast(msg,ms=2600){const t=document.getElementById('toast');if(!t)return;t.textContent=msg;t.hidden=false;clearTimeout(toast._t);toast._t=setTimeout(()=>t.hidden=true,ms)}

  function modal(html,{onClose}={}){const m=document.getElementById('modal');m.innerHTML=`<div class="mbox" role="dialog" aria-modal="true">${html}</div>`;m.hidden=false;
    document.body.classList.add('nos');m._close=onClose;m.querySelector('input,textarea,select')?.focus?.();return m.querySelector('.mbox')}
  function cerrarModal(){const m=document.getElementById('modal');m.hidden=true;m.innerHTML='';document.body.classList.remove('nos');if(m._close){const f=m._close;m._close=null;f()}}

  function confirmar(txt,si='Sí',no='Cancelar'){return new Promise(res=>{modal(`<p>${txt}</p><div class="row end"><button class="btn ghost" data-c="0">${e(no)}</button><button class="btn pri" data-c="1">${e(si)}</button></div>`);
    document.getElementById('modal').querySelectorAll('[data-c]').forEach(b=>b.onclick=()=>{cerrarModal();res(b.dataset.c==='1')})})}

  /* Guarda y comparte un archivo (en el teléfono) o lo descarga (en el navegador). */
  async function compartirArchivo(nombre,contenido,tipo='text/html'){
    const C=window.Capacitor,nat=!!(C&&C.isNativePlatform&&C.isNativePlatform());
    if(nat&&C.Plugins?.Filesystem&&C.Plugins?.Share){
      const b64=btoa(unescape(encodeURIComponent(contenido)));
      const w=await C.Plugins.Filesystem.writeFile({path:nombre,data:b64,directory:'CACHE'});
      await C.Plugins.Share.share({title:nombre,url:w.uri,dialogTitle:'Compartir'});return}
    const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([contenido],{type:tipo}));a.download=nombre;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)}
  async function compartirTexto(txt){const C=window.Capacitor;
    try{if(C?.isNativePlatform?.()&&C.Plugins?.Share){await C.Plugins.Share.share({text:txt});return}
      if(navigator.share){await navigator.share({text:txt});return}}catch(x){return}
    try{await navigator.clipboard.writeText(txt);toast('Copiado al portapapeles')}catch(x){toast('No se pudo copiar')}}

  /* Casa de la Relación Sólida: niveles [{id,n,estado(0 fortaleza|1 trabajar|2 problema|null),txt}] */
  function casa(niv){const W=320,H=300,x0=40,x1=280,piso=26,base=H-8;const col=v=>v===0?'var(--ok)':v===1?'var(--pb)':v===2?'var(--warn)':'var(--line)';
    const by=Object.fromEntries(niv.map(n=>[n.id,n]));const pisos=['mapas','carino','acercarse','perspectiva','conflicto','suenos'];let g='';
    pisos.forEach((id,i)=>{const n=by[id];const y=base-(i+1)*piso;g+=`<rect x="${x0+24}" y="${y}" width="${x1-x0-48}" height="${piso-3}" rx="4" fill="${col(n.estado)}" opacity=".9"/><text x="${W/2}" y="${y+piso/2+2}" text-anchor="middle" class="ct">${e(n.n)}${n.txt?' · '+e(n.txt):''}</text>`});
    const top=base-6*piso;const s=by.significado;g+=`<path d="M${x0} ${top-3} L${W/2} ${top-70} L${x1} ${top-3} Z" fill="${col(s.estado)}" opacity=".9"/><text x="${W/2}" y="${top-22}" text-anchor="middle" class="ct">${e(s.n)}</text>${s.txt?`<text x="${W/2}" y="${top-10}" text-anchor="middle" class="ct">${e(s.txt)}</text>`:''}`;
    [['confianza',x0],['compromiso',x1-21]].forEach(([id,x])=>{const n=by[id];g+=`<rect x="${x}" y="${top}" width="21" height="${6*piso-3}" rx="4" fill="${col(n.estado)}" opacity=".9"/><text transform="translate(${x+14} ${base-6*piso/2}) rotate(-90)" text-anchor="middle" class="ct">${e(n.n)}${n.txt?' · '+e(n.txt):''}</text>`});
    return`<svg class="casa" viewBox="0 0 ${W} ${H}" role="img" aria-label="Casa de la Relación Sólida">${g}</svg><div class="leyenda"><span class="ley"><i style="border-color:var(--ok)"></i>Fortaleza</span><span class="ley"><i style="border-color:var(--pb)"></i>Por trabajar</span><span class="ley"><i style="border-color:var(--warn)"></i>Problema</span><span class="ley"><i style="border-color:var(--line)"></i>Sin evaluar</span></div>`}
  return{casa,e,COL,fCorta,fLarga,lineas,toast,modal,cerrarModal,confirmar,compartirArchivo,compartirTexto}})();
