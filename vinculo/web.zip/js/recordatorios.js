/* Terapia2 — recordatorio diario con notificaciones locales (sin internet).
   El texto es neutro para no revelar contenido de la terapia en la pantalla bloqueada. */
"use strict";
const Recordatorio=(()=>{
  const ID=7101;
  const plug=()=>{const C=window.Capacitor;return C?.isNativePlatform?.()?C.Plugins?.LocalNotifications:null};
  async function programar({on,hora}){const p=plug();if(!p)return false;
    try{await p.cancel({notifications:[{id:ID}]})}catch(x){}
    if(!on)return true;
    let perm=await p.checkPermissions();if(perm.display!=='granted')perm=await p.requestPermissions();
    if(perm.display!=='granted')return false;
    const[h,m]=String(hora||'20:30').split(':').map(Number);
    await p.schedule({notifications:[{id:ID,title:'Recordatorio',body:'¿Registraste tu día?',schedule:{on:{hour:h,minute:m},allowWhileIdle:true}}]});
    return true}
  /* Aviso al terminar una pausa para calmarse (quinto principio). */
  async function avisoPausa(cuando){const p=plug();if(!p)return false;
    let perm=await p.checkPermissions();if(perm.display!=='granted')perm=await p.requestPermissions();if(perm.display!=='granted')return false;
    try{await p.cancel({notifications:[{id:7102}]})}catch(x){}
    await p.schedule({notifications:[{id:7102,title:'Recordatorio',body:'Terminó tu pausa. ¿Están listos para retomar con calma?',schedule:{at:new Date(cuando),allowWhileIdle:true}}]});return true}
  return{programar,avisoPausa}})();
