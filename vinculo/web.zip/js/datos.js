/* Terapia2 — datos en el teléfono y sincronización con el servidor.
   Cada teléfono guarda su copia (funciona sin internet) y envía/recibe cambios cuando hay conexión.
   Modo demostración: el "servidor" y los tres teléfonos (terapeuta, él, ella) viven dentro de este
   mismo equipo, para probar la app completa sin instalar nada. */
"use strict";
const Datos=(()=>{
  const PFX='vinculo.';
  const ls={get(k,d){try{const v=localStorage.getItem(PFX+k);return v?JSON.parse(v):d}catch(e){return d}},
    set(k,v){try{localStorage.setItem(PFX+k,JSON.stringify(v))}catch(e){console.warn('No se pudo guardar',e)}},
    del(k){try{localStorage.removeItem(PFX+k)}catch(e){}}};

  let cfg=ls.get('cfg',{modo:null,servidor:'',demoRol:'t'});
  let dev=null;           // estado del dispositivo actual
  const oyentes=new Set();
  const avisar=()=>oyentes.forEach(f=>{try{f()}catch(e){console.error(e)}});

  const devKey=()=>cfg.modo==='demo'?'demo.dev.'+cfg.demoRol:'dev';
  function cargar(){dev=ls.get(devKey(),null)||{rol:cfg.modo==='demo'?cfg.demoRol:null,parejas:{},activa:null};
    if(cfg.modo==='demo')dev.rol=cfg.demoRol}
  const guardarDev=()=>ls.set(devKey(),dev);
  const guardarCfg=()=>ls.set('cfg',cfg);

  /* ---------- servidor ---------- */
  /* Dirección del servidor: la de Ajustes solo si es válida. Las direcciones antiguas de Google Apps Script
     o mal escritas se ignoran y se usa la predeterminada (www/js/config.js). */
  const urlValida=u=>(/^https:\/\/[^\s\/]+\.[^\s\/]+\/\S*$/.test(u)||/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\/\S*$/.test(u))&&!/script\.google(usercontent)?\.com/.test(u);
  const url=()=>{const c=String(cfg.servidor||'').trim();return urlValida(c)?c:String(window.VINCULO_SERVIDOR_URL||'').trim()};
  const demoAlm={existe:c=>!!ls.get('demo.srv.'+c,null),leer:c=>ls.get('demo.srv.'+c,null),escribir:(c,D)=>ls.set('demo.srv.'+c,D),borrar:c=>{try{localStorage.removeItem('vinculo.demo.srv.'+c)}catch(e){}}};
  const demoCr={hash:s=>{let h1=0x811c9dc5,h2=0x1b873593;for(let i=0;i<s.length;i++){const c=s.charCodeAt(i);h1=Math.imul(h1^c,16777619);h2=Math.imul(h2^c,2246822519)}return(h1>>>0).toString(16)+(h2>>>0).toString(16)},
    azar:n=>{const a=new Uint32Array(1);(crypto.getRandomValues?crypto.getRandomValues(a):a[0]=Math.random()*4e9);return a[0]%n},ahora:()=>Date.now()};
  async function llamar(d){d=Object.assign({app:'vinculo'},d);
    if(cfg.modo==='demo'){await new Promise(r=>setTimeout(r,120));return JSON.parse(JSON.stringify(NUCLEO.atender(JSON.parse(JSON.stringify(d)),demoAlm,demoCr)))}
    const u=url();if(!u)throw new Error('Falta la dirección del servidor (Ajustes → Servidor).');
    const ctl=new AbortController();const t=setTimeout(()=>ctl.abort(),30000);
    try{const r=await fetch(u,{method:'POST',body:JSON.stringify(d),headers:{'Content-Type':'text/plain;charset=utf-8'},redirect:'follow',signal:ctl.signal});
      if(!r.ok)throw new Error('El servidor respondió '+r.status);return await r.json()}
    catch(e){let h=u;try{h=new URL(u).host}catch(x){}if(e.name==='AbortError')throw new Error('El servidor ('+h+') tardó demasiado.');if(e instanceof TypeError)throw new Error('Sin conexión con el servidor ('+h+'). Revisa tu internet o Ajustes → Servidor.');throw e}
    finally{clearTimeout(t)}}

  /* ---------- parejas ---------- */
  const P=c=>dev.parejas[c];
  const R=c=>(P(c)||{}).R||{};
  function nuevaLocal(codigo,token,extra){dev.parejas[codigo]=Object.assign({codigo,token,R:{},srv:0,pend:{},ultimaSync:0,error:''},extra||{});dev.activa=codigo;guardarDev()}

  async function crearPareja(nombres,datos){
    const r=await llamar({accion:'crear',claveProfesional:cfg.claveProfesional||''});if(!r.ok)throw new Error(r.error);
    nuevaLocal(r.codigo,r.claveTerapeuta,{clavePareja:r.clavePareja});
    const ahora=Date.now();
    guardar(r.codigo,Object.assign({id:'pareja',tipo:'pareja',nombres:{a:nombres.a||'Él',b:nombres.b||'Ella'},inicio:MED.hoy(),compartirEval:true,compartirCSI:false,recordatorio:'20:30',creado:ahora},datos||{}),true);
    await sync(r.codigo);return r}

  async function unirse(codigo,clave,rol,consentimiento){codigo=NUCLEO.limpiar(codigo);
    const r=await llamar({accion:'unirse',codigo,clave,rol,consentimiento});if(!r.ok)throw new Error(r.error);
    dev.rol=rol;dev.parejas={};nuevaLocal(r.codigo,r.token);await sync(r.codigo);return r}

  /* Guarda un registro local y lo deja pendiente de envío. */
  function guardar(codigo,rec,sinSync){const p=P(codigo);if(!p)throw new Error('Pareja no encontrada');
    rec=Object.assign({},rec,{autor:dev.rol==='t'?'t':dev.rol,mod:Date.now()});delete rec.srv;
    p.R[rec.id]=rec;p.pend[rec.id]=1;guardarDev();avisar();if(!sinSync)programarSync(codigo);return rec}
  function borrar(codigo,id){const r=R(codigo)[id];if(r)guardar(codigo,Object.assign({},r,{borrado:true}))}

  const timers={};
  function programarSync(c){clearTimeout(timers[c]);timers[c]=setTimeout(()=>sync(c).catch(()=>{}),900)}
  let enCurso={};
  async function sync(codigo){const p=P(codigo);if(!p)return;if(enCurso[codigo])return enCurso[codigo];
    enCurso[codigo]=(async()=>{
      const ids=Object.keys(p.pend);const cambios=ids.map(id=>p.R[id]).filter(Boolean);
      const compAntes=JSON.stringify([p.R.pareja?.compartirEval,p.R.pareja?.compartirCSI]);
      try{const r=await llamar({accion:'sync',codigo,rol:dev.rol,token:p.token,desde:p.srv,cambios});
        if(!r.ok){p.error=r.error;guardarDev();avisar();throw new Error(r.error)}
        for(const id of ids){if(p.R[id]&&cambios.find(c=>c.id===id&&c.mod===p.R[id].mod))delete p.pend[id]}
        (r.rechazados||[]).forEach(id=>{delete p.pend[id]});
        MED.fusionar(p.R,(r.registros||[]).filter(x=>!p.pend[x.id]));
        p.srv=r.srv;p.error='';p.ultimaSync=Date.now();
        // Si el terapeuta cambió qué se comparte, se pide todo de nuevo.
        if(dev.rol!=='t'&&JSON.stringify([p.R.pareja?.compartirEval,p.R.pareja?.compartirCSI])!==compAntes&&compAntes!=='[null,null]'){p.srv=0;guardarDev();enCurso[codigo]=null;return sync(codigo)}
        guardarDev();avisar();return r}
      finally{enCurso[codigo]=null}})();
    return enCurso[codigo]}
  async function syncTodo(){const out=[];for(const c of Object.keys(dev.parejas)){try{await sync(c);out.push([c,null])}catch(e){out.push([c,e.message])}}return out}

  async function liberar(codigo,rol){const p=P(codigo);const r=await llamar({accion:'liberar',codigo,token:p.token,liberar:rol});if(!r.ok)throw new Error(r.error);return r}
  async function pedir(accion,codigo,extra){const p=P(codigo);const r=await llamar(Object.assign({accion,codigo,rol:dev.rol,token:p.token},extra||{}));if(!r.ok)throw new Error(r.error);return r}
  function setClaveProfesional(k){cfg.claveProfesional=String(k||'').trim();guardarCfg()}
  async function estado(codigo){const p=P(codigo);const r=await llamar({accion:'estado',codigo,token:p.token});if(!r.ok)throw new Error(r.error);return r}

  /* ---------- configuración ---------- */
  function elegirModo(m){cfg.modo=m;guardarCfg();cargar();avisar()}
  function demoRol(rol){cfg.demoRol=rol;guardarCfg();cargar();avisar()}
  /* Acceso profesional: solo los teléfonos habilitados (gesto oculto en el logo) ven la opción de terapeuta. */
  function setPro(v){cfg.pro=!!v;guardarCfg();avisar()}
  function setServidor(u){u=String(u||'').trim();if(u&&!urlValida(u))throw new Error('Dirección no válida. Debe empezar con https:// (por ejemplo, '+(window.VINCULO_SERVIDOR_URL||'https://…/api')+').');cfg.servidor=u;guardarCfg()}
  function salirDemo(){Object.keys(localStorage).filter(k=>k.startsWith(PFX+'demo.')).forEach(k=>localStorage.removeItem(k));cfg.modo=null;cfg.demoRol='t';guardarCfg();cargar();avisar()}
  function setRol(rol){dev.rol=rol;guardarDev();avisar()}
  function activar(c){dev.activa=c;guardarDev();avisar()}
  function quitarPareja(c){delete dev.parejas[c];if(dev.activa===c)dev.activa=Object.keys(dev.parejas)[0]||null;guardarDev();avisar()}
  function respaldo(){return{app:'vinculo',version:1,fecha:new Date().toISOString(),cfg:{modo:cfg.modo},dispositivo:dev}}
  function restaurar(j){if(!j||j.app!=='vinculo'||!j.dispositivo)throw new Error('El archivo no es un respaldo de Terapia2');
    if(cfg.modo==='demo')throw new Error('Sal del modo demostración antes de restaurar');
    dev=j.dispositivo;guardarDev();avisar()}
  function borrarTodo(){Object.keys(localStorage).filter(k=>k.startsWith(PFX)).forEach(k=>localStorage.removeItem(k));cfg={modo:null,servidor:'',demoRol:'t'};cargar();avisar()}
  const pendientes=c=>Object.keys((P(c)||{}).pend||{}).length;

  cargar();
  return{get cfg(){return cfg},get dev(){return dev},url,llamar,crearPareja,unirse,guardar,borrar,sync,syncTodo,liberar,estado,R,P,
    elegirModo,demoRol,setServidor,urlValida,setPro,setClaveProfesional,pedir,salirDemo,setRol,activar,quitarPareja,respaldo,restaurar,borrarTodo,pendientes,on:f=>oyentes.add(f),ls}})();
