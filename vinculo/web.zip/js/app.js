/* Terapia2 — app para parejas en terapia: terapeuta, él y ella, cada uno en su teléfono. */
"use strict";
const {e,toast,modal,cerrarModal,confirmar}=UIX;
const S={tab:null,sub:'resumen',bib:'sug',hoy:{},bloqueado:false,filtroBib:'sug'};
const $=s=>document.querySelector(s);
const rol=()=>Datos.dev.rol;
const C=()=>Datos.dev.activa;
const R=()=>Datos.R(C());
const pareja=()=>R().pareja||{nombres:{a:'Él',b:'Ella'}};
const nom=r=>(pareja().nombres||{})[r]||(r==='a'?'Él':'Ella');
const otro=r=>r==='a'?'b':'a';
const uid=p=>p+'-'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const hoy=()=>MED.hoy();
const regs=t=>MED.regs(R(),t);
const GASTXT={'-2':'Mucho menos de lo esperado','-1':'Menos de lo esperado','0':'Resultado esperado','1':'Más de lo esperado','2':'Mucho más de lo esperado'};
/* Íconos de trazo (24×24, estilo Lucide), dibujados en SVG para que se vean iguales en todos los teléfonos. */
const ICON={
  hoy:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M9 16l2 2 4-4"/>',
  objetivos:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  ejercicios:'<path d="M7 20h10"/><path d="M10 20c5.5-2.5.8-6.4 3-10"/><path d="M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z"/><path d="M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z"/>',
  progreso:'<path d="M22 7l-8.5 8.5-5-5L2 17"/><path d="M16 7h6v6"/>',
  mas:'<circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/>',
  parejas:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  biblioteca:'<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
  ajustes:'<path d="M21 4h-7M10 4H3M21 12h-9M8 12H3M21 20h-5M12 20H3M14 2v4M8 10v4M16 18v4"/>',
  pausa:'<path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/><path d="M9.6 4.6A2 2 0 1 1 11 8H2"/><path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>',
  candado:'<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  ojo:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
  mensaje:'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  corazon:'<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7z"/>',
  flecha:'<path d="m9 18 6-6-6-6"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/>',
  conversar:'<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22z"/>',
  escuchar:'<path d="M6 8.5a6.5 6.5 0 1 1 13 0c0 6-6 6-6 10a3.5 3.5 0 1 1-7 0"/><path d="M15 8.5a2.5 2.5 0 0 0-5 0v1a2 2 0 1 1 0 4"/>',
  escudo:'<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>',
  mapa:'<path d="M14.1 4.6 9.9 2.4a2 2 0 0 0-1.8 0L3.6 4.7A1 1 0 0 0 3 5.6v14.8a1 1 0 0 0 1.4.9l4.7-2.4a2 2 0 0 1 1.8 0l4.2 2.2a2 2 0 0 0 1.8 0l4.5-2.3a1 1 0 0 0 .6-.9V3.6a1 1 0 0 0-1.4-.9l-4.7 2.4a2 2 0 0 1-1.8 0z"/><path d="M15 5.8v15M9 3.2v15"/>',
  taza:'<path d="M10 2v2M14 2v2M6 2v2M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1"/>',
  luna:'<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9z"/>',
  casa:'<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .7-1.5l7-6a2 2 0 0 1 2.6 0l7 6a2 2 0 0 1 .7 1.5v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  ayuda:'<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/><path d="m4.9 4.9 4.3 4.3M14.8 9.2l4.3-4.3M14.8 14.8l4.3 4.3M9.2 14.8l-4.3 4.3"/>',
  documento:'<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"/><path d="M14 2v4a2 2 0 0 0 2 2h4M10 13h4M10 17h4"/>',
  firmado:'<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"/><path d="M14 2v4a2 2 0 0 0 2 2h4M9 15l2 2 4-4"/>',
  descarga:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  papelera:'<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>'};
/* Fila de lista con ícono, título, detalle y flecha (para menús como "Más"). */
const fila=(act,ic,t,d='',attrs='',cls='')=>`<button class="lrow ${cls}" data-act="${act}" ${attrs}><span class="lic">${ico(ic)}</span><span class="ltx"><b>${t}</b>${d?`<span>${d}</span>`:''}</span>${ico('flecha','chev')}</button>`;
const ICO_EJ={incidente:'conversar',rapoport:'escuchar',jinetes:'escudo',mapas:'mapa',estres:'taza',sueno:'luna',significado:'casa'};
const saludo=()=>{const h=new Date().getHours();return h>=5&&h<12?'Buenos días':h>=12&&h<20?'Buenas tardes':'Buenas noches'};
const ico=(n,c='')=>`<svg class="ico ${c}" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">${ICON[n]||''}</svg>`;
/* Los pacientes nunca ven la opción de terapeuta. Un teléfono queda habilitado como profesional
   con el gesto oculto (mantener presionado el logo 3 segundos) o si ya se usaba como terapeuta. */
const esPro=()=>!!Datos.cfg.pro||(Datos.cfg.modo==='real'&&rol()==='t');
const NIVEL=v=>v==null?'Sin marcar':v<=1?'Nada':v<=4?'Poco':v<=6?'A medias':v<=8?'Bastante':'Totalmente';
const FREQ=['diario','2 veces por semana','3 veces por semana','1 vez por semana','cuando ocurra'];

/* ===================== Marco general ===================== */
function render(){
  const main=$('#main'),nav=$('#nav'),top=$('#topbar');
  if(S.bloqueado){top.innerHTML='';nav.innerHTML='';main.innerHTML=pantallaPin();return}
  const m=Datos.cfg.modo;
  $('#demobar').hidden=m!=='demo';
  if(m==='demo')$('#demobar').innerHTML=`<div class="wrap demo-in"><span><b>Demostración</b> · ver como</span>${(esPro()?['t','a','b']:['a','b']).map(r=>`<button class="chip ${Datos.cfg.demoRol===r?'on':''}" data-act="demo-rol" data-r="${r}">${r==='t'?'Terapeuta':e(nomDemo(r))}</button>`).join('')}<button class="chip ghost" data-act="demo-salir">Salir</button></div>`;
  if(!m){top.innerHTML=cabecera();nav.innerHTML='';main.innerHTML=pantallaBienvenida();return}
  if(!rol()){top.innerHTML=cabecera();nav.innerHTML='';main.innerHTML=esPro()?pantallaRol():pantallaUnirse();return}
  if(rol()!=='t'&&!C()){top.innerHTML=cabecera();nav.innerHTML='';main.innerHTML=pantallaUnirse();return}
  top.innerHTML=cabecera();
  if(rol()==='t'){
    if(!S.tab||!['parejas','pareja','biblioteca','mas'].includes(S.tab))S.tab='parejas';
    if(S.tab==='pareja'&&!C())S.tab='parejas';
    nav.innerHTML=navHTML([['parejas','Parejas','parejas'],['biblioteca','Biblioteca','biblioteca'],['mas','Ajustes','ajustes']],S.tab==='pareja'?'parejas':S.tab);
    main.innerHTML={parejas:tParejas,pareja:tPareja,biblioteca:tBiblioteca,mas:pMas}[S.tab]();
  }else{
    if(!S.tab||!['hoy','objetivos','ejercicios','progreso','mas'].includes(S.tab))S.tab='hoy';
    nav.innerHTML=navHTML([['hoy','Hoy','hoy'],['objetivos','Objetivos','objetivos'],['ejercicios','Ejercicios','ejercicios'],['progreso','Progreso','progreso'],['mas','Más','mas']],S.tab);
    main.innerHTML={hoy:pHoy,objetivos:pObjetivos,ejercicios:pEjercicios,progreso:pProgreso,mas:pMas}[S.tab]();
  }
  pintarSliders();
}
function nomDemo(r){const d=Datos.ls.get('demo.dev.t',null);const c=d&&d.activa&&d.parejas[d.activa];return c?.R?.pareja?.nombres?.[r]||(r==='a'?'Él':'Ella')}
function navHTML(items,act){return`<div class="wrap nav-in">${items.map(([k,t,i])=>`<button class="nb" data-act="tab" data-t="${k}" ${k===act?'aria-current="page"':''}><span class="ni">${ico(i)}</span>${t}</button>`).join('')}</div>`}
function cabecera(){
  let estado='';
  if(C()&&Datos.cfg.modo){const p=Datos.P(C());const pend=Datos.pendientes(C());
    estado=p?.error?`<button class="pill warn" data-act="sync"><i class="dot"></i>Sin sincronizar</button>`:pend?`<button class="pill" data-act="sync">${pend} por enviar</button>`:`<button class="pill ok" data-act="sync"><i class="dot"></i>Al día</button>`}
  const quien=rol()==='t'?'Terapeuta':(rol()==='a'||rol()==='b')&&C()?e(nom(rol())):'';
  return`<div class="wrap top-in"><div class="brand"><span class="logo" data-pro aria-label="Terapia2">Terapia<b>2</b></span>${quien?`<span class="who">${quien}</span>`:''}</div>${estado}</div>`}

/* ===================== Inicio ===================== */
function pantallaBienvenida(){const pro=esPro();return`
<section class="hero"><div class="mark" aria-hidden="true" data-pro><span></span><span></span></div>
<h1 data-pro aria-label="Terapia2">Terapia<span class="dos">2</span></h1><p class="sub">Terapia de pareja</p><p>Tu espacio entre sesiones.</p>
<ul class="benef"><li>${ico('hoy')}<span><b>Registra tu día en 2 minutos</b>Cómo avanzas en los objetivos que acordaron con tu terapeuta.</span></li>
<li>${ico('progreso')}<span><b>Mira cómo avanzan</b>Tu progreso y el de tu pareja, semana a semana.</span></li>
<li>${ico('candado')}<span><b>Lo privado es privado</b>Tus notas y respuestas confidenciales las ve solo tu terapeuta.</span></li></ul></section>
<div class="stack">
<button class="btn pri big" data-act="modo" data-m="real">Unirme a mi terapia</button>
<button class="btn big" data-act="modo" data-m="demo">Ver cómo funciona</button>
<p class="note">Necesitas el código y la clave que te entregó tu terapeuta. La demostración usa una pareja de ejemplo y no guarda nada tuyo.</p>
<p class="aviso">${ico('info')}<span>${e(LEGAL.AVISO)}</span></p></div>
${pro?`<div class="card"><h3>Acceso profesional</h3><p class="note">Este teléfono está habilitado para terapeutas.</p><button class="btn" data-act="pro-entrar">Entrar como terapeuta</button></div>`:''}
<p class="note center">Basada en modelos de terapia de pareja con respaldo científico. <button class="lnk" data-act="fundamentos">Ver fundamentos</button></p>`}

function pantallaRol(){const u=Datos.url();return`
<div class="sh"><h2>¿Quién eres?</h2><p>Cada persona instala la app en su propio teléfono.</p></div>
${u?'':`<div class="card warnc"><h3>Falta el servidor</h3><p class="note">Para que los tres teléfonos se conecten, la app necesita la dirección del servidor de Terapia2. La entrega quien instala el sistema (ver LEEME).</p>
<label class="fld"><span class="lbl">Dirección del servidor (termina en /exec)</span><input id="srvurl" type="url" placeholder="https://script.google.com/macros/s/…/exec"></label>
<button class="btn" data-act="srv-guardar">Guardar dirección</button></div>`}
<button class="card opt" data-act="set-rol" data-r="t"><b>Soy terapeuta</b><span>Creo la ficha de la pareja, el diagnóstico y los objetivos.</span></button>
<button class="card opt" data-act="set-rol" data-r="p"><b>Soy parte de una pareja</b><span>Tengo el código y la clave que me dio mi terapeuta.</span></button>
<button class="btn ghost sm" data-act="modo" data-m="">← Volver</button>`}

function pantallaUnirse(){const demo=Datos.cfg.modo==='demo';return`
<div class="sh"><h2>Unirme a mi terapia</h2><p>Escribe el código y la clave que te entregó tu terapeuta.</p></div>
${Datos.url()||demo?'':`<div class="card warnc"><h3>Falta la dirección del servidor</h3><p class="note">Pídesela a tu terapeuta.</p>
<label class="fld"><span class="lbl">Dirección del servidor (termina en /exec)</span><input id="srvurl" type="url" placeholder="https://script.google.com/macros/s/…/exec"></label>
<button class="btn" data-act="srv-guardar">Guardar dirección</button></div>`}
<div class="card">
<label class="fld"><span class="lbl">Código de la pareja</span><input id="j-cod" autocapitalize="characters" autocomplete="off" maxlength="8" placeholder="Ej.: K7M2QX"></label>
<label class="fld"><span class="lbl">Clave de la pareja</span><input id="j-cla" autocapitalize="characters" autocomplete="off" maxlength="8"></label>
<div class="fld"><span class="lbl">Yo soy</span><div class="seg"><button class="sg ${S.jrol==='a'?'on':''}" data-act="j-rol" data-r="a">Él</button><button class="sg ${S.jrol==='b'?'on':''}" data-act="j-rol" data-r="b">Ella</button></div></div>
<p class="aviso">${ico('info')}<span>${e(LEGAL.AVISO)}</span></p>
<label class="chk cons"><input type="checkbox" id="j-cons"><span>Soy mayor de 18 años y acepto el <button class="lnk" data-act="legal" data-doc="CONSENTIMIENTO">consentimiento informado</button>, la <button class="lnk" data-act="legal" data-doc="PRIVACIDAD">política de privacidad</button> y los <button class="lnk" data-act="legal" data-doc="TERMINOS">términos de uso</button>, incluido el tratamiento de mis datos de salud.</span></label>
<button class="btn pri" data-act="unirse">Unirme</button>
<p class="note priv">${ico('candado')}<span>Tus respuestas privadas (notas al terapeuta y preguntas confidenciales) nunca se muestran a tu pareja.</span></p></div>
${demo?'':esPro()?'<button class="btn ghost sm" data-act="set-rol" data-r="">← Volver</button>':'<button class="btn ghost sm" data-act="modo" data-m="">← Volver</button>'}`}

/* ===================== Pareja: HOY ===================== */
function pHoy(){const r=rol(),o=otro(r),f=hoy();const obs=MED.objetivosActivos(R()).filter(x=>x.estado==='activo'||!x.estado);
  let h=`<div class="sh"><span class="sn">${e(UIX.fLarga(f))}</span><h2>${saludo()}, ${e(nom(r))}</h2></div>`;
  h+=bannerPausa();
  h+=avisosHoy();
  const ap=regs('aprecio').filter(x=>x.autor===o).sort((a,b)=>a.fecha<b.fecha?1:-1)[0];
  if(ap&&MED.diasDesde(ap.fecha)<=3)h+=`<div class="card aprecio"><span class="lbl">${ico('corazon')}${e(nom(o))} agradeció</span><p>“${e(ap.texto)}”</p></div>`;
  if(!obs.length)return h+`<div class="card"><p>Tu terapeuta todavía no ha definido objetivos. Cuando lo haga, aparecerán aquí para que registres tu avance cada día.</p><button class="btn" data-act="sync">Buscar cambios</button></div>`;
  const yaHoy=regs('evaluacion').filter(x=>x.autor===r&&x.fecha===f);
  h+=`<div class="sh2"><div><h3>Registro de hoy</h3><p class="note">Marca cuánto se cumplió cada objetivo hoy, de 0 a 10.</p></div>${yaHoy.length?'<span class="badge ok">Guardado</span>':''}</div>
  <div class="avance" id="avance">${avanceHTML(obs)}</div>`;
  for(const ob of obs){const d=borrador(ob.id);const yo=MED.aplica(ob,r),el=MED.aplica(ob,o);
    h+=`<div class="card obj"><div class="obh"><b>${e(ob.titulo)}</b></div>`;
    if(yo){h+=slider(`Yo`,ob.id,'propio',d.propio,'¿Cuánto cumplí yo hoy?');
      const tareas=(ob.tareas||[]);if(tareas.length)h+=`<div class="tareas">${tareas.map((t,i)=>`<label class="chk"><input type="checkbox" data-hoy="${ob.id}" data-tarea="${i}" ${d.hechas?.includes(i)?'checked':''}><span>${e(t.t)} <i>${e(t.f||'')}</i></span></label>`).join('')}</div>`}
    if(el)h+=slider(e(nom(o)),ob.id,'otro',d.otro,`¿Cuánto cumplió ${e(nom(o))}?`);
    h+=`<details class="ind"><summary>${ico('info')}¿Qué cuenta como cumplir?</summary><ul>${(ob.indicadores||[]).map(i=>`<li>${e(i)}</li>`).join('')}</ul></details></div>`}
  const ji=S.hoy._ji||(S.hoy._ji=(()=>{const x=regs('jinetes').find(j=>j.autor===r&&j.fecha===f);return{j:[...(x?.jinetes||[])],a:[...(x?.antidotos||[])]}})());
  h+=`<div class="card"><div><h3>Cuatro Jinetes y antídotos</h3><span class="priv">${ico('candado')}Solo lo ve tu terapeuta</span></div><span class="lbl">¿Qué usé hoy al hablar con ${e(nom(o))}?</span>
  <div class="opts">${EVID.JINETES.map(x=>`<button class="op ${ji.j.includes(x.id)?'on warnop':''}" data-act="ji" data-k="j" data-v="${x.id}">${e(x.n)}</button>`).join('')}<button class="op ${ji.j.length===0&&ji.ninguno?'on':''}" data-act="ji" data-k="n">Ninguno</button></div>
  <span class="lbl">Antídotos que usé</span><div class="opts">${EVID.JINETES.map(x=>`<button class="op ${ji.a.includes(x.a)?'on':''}" data-act="ji" data-k="a" data-v="${x.a}" title="${e(x.ad)}">${e(x.an)}</button>`).join('')}</div></div>`;
  const ap2=regs('aprecio').find(x=>x.autor===r&&x.fecha===f);const nt=regs('nota').find(x=>x.autor===r&&x.fecha===f);
  h+=`<div class="card"><label class="fld"><span class="lbl">Algo que agradezco hoy de ${e(nom(o))}</span><span class="priv">${ico('ojo')}Lo verá ${e(nom(o))}</span><textarea id="h-aprecio" rows="2" maxlength="400">${e(S.hoy._aprecio??ap2?.texto??'')}</textarea></label>
  <label class="fld"><span class="lbl">Nota para mi terapeuta</span><span class="priv">${ico('candado')}Privada: solo tu terapeuta</span><textarea id="h-nota" rows="2" maxlength="1500">${e(S.hoy._nota??nt?.texto??'')}</textarea></label></div>
  <div class="savebar"><button class="btn pri big" data-act="guardar-hoy">Guardar mi registro</button></div>`;
  return h}
function avanceHTML(obs){obs=obs||MED.objetivosActivos(R()).filter(x=>x.estado==='activo'||!x.estado);const n=obs.length;
  const k=obs.filter(ob=>{const d=borrador(ob.id);return d.propio!=null||d.otro!=null}).length;const pc=n?Math.round(k/n*100):0;
  return`<div class="row sb"><span>${k===n&&n?'¡Listo! Solo falta guardar':k?'Vas bien':'Empecemos'}</span><b>${k} de ${n}</b></div><div class="pbar" role="progressbar" aria-valuemin="0" aria-valuemax="${n}" aria-valuenow="${k}" aria-label="Objetivos registrados hoy"><i style="width:${pc}%"></i></div>`}
function borrador(id){if(!S.hoy[id]){const ex=regs('evaluacion').find(x=>x.autor===rol()&&x.objetivo===id&&x.fecha===hoy());S.hoy[id]=ex?{propio:ex.propio,otro:ex.otro,hechas:[...(ex.hechas||[])]}:{propio:null,otro:null,hechas:[]}}return S.hoy[id]}
function slider(lbl,id,k,v,aria){return`<div class="sl"><div class="row sb"><span class="sll">${lbl}</span><span class="slv ${v==null?'vacio':''}" data-v="${id}-${k}">${valTxt(v)}</span></div>
<input type="range" min="0" max="10" step="1" value="${v??5}" data-hoy="${id}" data-k="${k}" class="${v==null?'vacio':''}" aria-label="${e(aria||lbl)}" aria-valuetext="${v==null?'Sin marcar':v+', '+NIVEL(v)}"></div>`}
const valTxt=v=>v==null?'Toca para marcar':`<b>${v}</b> ${NIVEL(v)}`;
function pintarSliders(){document.querySelectorAll('input[type=range]').forEach(i=>{const p=(i.value-i.min)/(i.max-i.min)*100;i.style.setProperty('--p',p+'%')})}

function avisosHoy(){const r=rol();let h='';
  const ms=[...regs('mensaje'),...regs('sesion').filter(s=>s.indicaciones)].sort((a,b)=>(a.fecha<b.fecha?1:-1))[0];
  if(ms&&MED.diasDesde(ms.fecha)<=14)h+=`<div class="card msg"><span class="lbl">${ico('mensaje')}${ms.tipo==='sesion'?'Indicaciones de la sesión':'Mensaje de tu terapeuta'} · ${UIX.fCorta(ms.fecha)}</span><p>${e(ms.texto||ms.indicaciones).replace(/\n/g,'<br>')}</p></div>`;
  const pend=[];const fila=(act,t,d,extra='')=>`<button class="trow" data-act="${act}"${extra}><span><b>${t}</b><span>${d}</span></span>${ico('flecha')}</button>`;
  const seg=regs('seguridad').filter(x=>x.autor===r).sort((a,b)=>a.fecha<b.fecha?1:-1)[0];
  if(!seg||MED.diasDesde(seg.fecha)>=28)pend.push(fila('abrir-seguridad','Preguntas confidenciales',`Solo las ve tu terapeuta. ${seg?'Revisión mensual.':'Una vez al inicio.'}`));
  if(!regs('inicial').some(x=>x.autor===r))pend.push(fila('abrir-inicial','Evaluación inicial','¿Qué temas les cuestan como pareja? 2 minutos.'));
  const csi=regs('csi').filter(x=>x.autor===r).sort((a,b)=>a.fecha<b.fecha?1:-1)[0];
  if(!csi||MED.diasDesde(csi.fecha)>=7)pend.push(fila('abrir-csi','Satisfacción semanal','4 preguntas, una vez por semana.'));
  const ses=MED.ultimaSesion(R());
  if(ses&&MED.diasDesde(ses.fecha)<=10&&MED.diasDesde(ses.fecha)>=0&&!regs('alianza').some(x=>x.autor===r&&x.sesion===ses.id))pend.push(fila('abrir-alianza',`¿Cómo te fue en la sesión del ${UIX.fCorta(ses.fecha)}?`,'4 preguntas para tu terapeuta. Tu pareja no las ve.',` data-s="${ses.id}"`));
  if(pend.length)h+=`<div class="card tasks"><div class="row sb"><h3>Pendiente</h3><span class="badge">${pend.length}</span></div>${pend.join('')}</div>`;
  return h}

function guardarHoy(){const r=rol(),f=hoy();let n=0;
  for(const ob of MED.objetivosActivos(R())){const d=S.hoy[ob.id];if(!d)continue;if(d.propio==null&&d.otro==null&&!d.hechas.length)continue;
    Datos.guardar(C(),{id:`ev-${r}-${ob.id}-${f}`,tipo:'evaluacion',objetivo:ob.id,fecha:f,propio:d.propio,otro:d.otro,hechas:d.hechas},true);n++}
  const ap=$('#h-aprecio')?.value.trim(),nt=$('#h-nota')?.value.trim();
  if(ap)Datos.guardar(C(),{id:`ap-${r}-${f}`,tipo:'aprecio',fecha:f,texto:ap},true);
  if(nt)Datos.guardar(C(),{id:`no-${r}-${f}`,tipo:'nota',fecha:f,texto:nt},true);
  const ji=S.hoy._ji;if(ji&&(ji.j.length||ji.a.length||ji.ninguno)){Datos.guardar(C(),{id:`ji-${r}-${f}`,tipo:'jinetes',fecha:f,jinetes:ji.j,antidotos:ji.a},true);n++}
  delete S.hoy._aprecio;delete S.hoy._nota;
  if(!n&&!ap&&!nt){toast('Mueve al menos una barra antes de guardar');return}
  Datos.sync(C()).catch(()=>{});toast('Registro guardado');render()}

/* ---------- Formularios de la pareja ---------- */
function abrirCSI(){const it=EVID.SATISF.items;S.csi=[null,null,null,null];
  modal(`<h3>${e(EVID.SATISF.nombre)}</h3><p class="note">Piensa en la última semana y responde con sinceridad: no hay respuestas correctas.</p>${it.map((q,i)=>`<div class="fld"><span class="q">${i+1}. ${e(q.p)}</span><div class="opts">${q.o.map((t,v)=>`<button class="op" data-act="csi-op" data-i="${i}" data-v="${v}">${e(t)}</button>`).join('')}</div></div>`).join('')}
  <div class="row end"><button class="btn ghost" data-act="cerrar">Cancelar</button><button class="btn pri" data-act="csi-guardar">Guardar</button></div>`)}
function abrirSeguridad(){S.seg={};
  modal(`<h3>Preguntas confidenciales</h3><p class="note">Solo las ve tu terapeuta; tu pareja no puede verlas. Si alguna respuesta es "sí", tu terapeuta conversará contigo a solas.</p>
  ${EVID.SEGURIDAD.map(q=>`<div class="fld"><span class="q">${e(q.p)}</span><div class="seg"><button class="sg" data-act="seg-op" data-k="${q.id}" data-v="0">No</button><button class="sg" data-act="seg-op" data-k="${q.id}" data-v="1">Sí</button></div></div>`).join('')}
  <div class="row end"><button class="btn ghost" data-act="cerrar">Cancelar</button><button class="btn pri" data-act="seg-guardar">Guardar</button></div>`)}
function abrirInicial(){S.ini={};S.iniCasa={};const N=['Nada','Poco','Bastante','Mucho'];const M=['0','1','2','3','4'];
  modal(`<h3>Evaluación inicial</h3><p class="note">¿Cuánto problema es cada tema para ustedes? Tu terapeuta lo usará para el diagnóstico. Tu pareja no ve tus respuestas.</p>
  ${Object.entries(EVID.AREAS).map(([k,t])=>`<div class="fld"><span class="q">${e(t)}</span><div class="seg s4">${N.map((n,v)=>`<button class="sg" data-act="ini-op" data-k="${k}" data-v="${v}">${n}</button>`).join('')}</div></div>`).join('')}
  <h3>Nuestra relación hoy</h3><p class="note">De 0 (nada de acuerdo) a 4 (totalmente de acuerdo).</p>
  ${EVID.CASA.map(c=>`<div class="fld"><span class="q">${e(c.p)}</span><div class="seg s5">${M.map(v=>`<button class="sg" data-act="ini-casa" data-k="${c.id}" data-v="${v}">${v}</button>`).join('')}</div></div>`).join('')}
  <label class="fld"><span class="lbl">¿Qué te gustaría que cambiara con la terapia?</span><textarea id="ini-meta" rows="3" maxlength="1500"></textarea></label>
  <div class="row end"><button class="btn ghost" data-act="cerrar">Cancelar</button><button class="btn pri" data-act="ini-guardar">Guardar</button></div>`)}
function abrirAlianza(sid){S.ali={sesion:sid,resp:{}};
  modal(`<h3>Sobre la última sesión</h3><p class="note">De 0 a 10. Tu terapeuta usa esto para ajustar la terapia; tu pareja no lo ve.</p>
  ${EVID.ALIANZA.map(q=>`<div class="sl"><div class="row sb"><span class="lbl">${e(q.p)}</span><b class="slv" data-v="ali-${q.id}">—</b></div><input type="range" min="0" max="10" value="5" class="vacio" data-ali="${q.id}"></div>`).join('')}
  <label class="fld"><span class="lbl">¿Algo que el terapeuta debería saber?</span><textarea id="ali-txt" rows="2" maxlength="800"></textarea></label>
  <div class="row end"><button class="btn ghost" data-act="cerrar">Cancelar</button><button class="btn pri" data-act="ali-guardar">Enviar</button></div>`);pintarSliders()}
function mostrarRecursos(){modal(`<h3>Ayuda inmediata (Chile)</h3><p class="note">Si estás en peligro, llama ahora. Las llamadas a estas líneas no aparecen en la app.</p>
  <ul class="rec">${EVID.RECURSOS.map(x=>`<li><a href="tel:${x.n.replace(/[^+*\d]/g,'')}"><b>${e(x.n)}</b></a><span>${e(x.d)}</span></li>`).join('')}</ul>
  <div class="row end"><button class="btn pri" data-act="cerrar">Entendido</button></div>`)}

/* ===================== Pareja: EJERCICIOS (principios 5 a 10) ===================== */
function pausaActiva(autor){const p=regs('pausa').filter(x=>x.autor===autor).sort((a,b)=>(a.inicio<b.inicio?1:-1))[0];return p&&!p.terminada&&Date.now()<p.vuelve?p:null}
const hhmm=t=>new Date(t).toLocaleTimeString('es-CL',{hour:'2-digit',minute:'2-digit'});
function bannerPausa(){const r=rol(),o=otro(r);const mia=pausaActiva(r),suya=pausaActiva(o);let h='';
  if(mia)h+=`<div class="card pausa"><b>Estás en pausa hasta las ${hhmm(mia.vuelve)}</b><span class="note">Haz algo que te calme y no repases la discusión. A esa hora retomen la conversación.</span><div class="row"><button class="btn sm" data-act="respirar">Respirar 2 minutos</button><button class="btn sm ghost" data-act="pausa-fin" data-id="${mia.id}">Ya estoy en calma</button></div></div>`;
  else h+=`<button class="btn pausa-btn" data-act="pausa">${ico('pausa')}Necesito una pausa para calmarme</button>`;
  if(suya)h+=`<div class="card pausa"><b>${e(nom(o))} pidió una pausa para calmarse</b><span class="note">Vuelven a conversar a las ${hhmm(suya.vuelve)}. Mientras, evita seguir la discusión por mensajes y haz algo que también te calme a ti.</span></div>`;
  return h}
function abrirPausa(){modal(`<h3>Pausa para calmarme</h3><p class="note">Cuando el corazón se acelera (sobre unas 100 pulsaciones por minuto), la mandíbula se aprieta o dan ganas de huir, el cuerpo entra en modo de alarma y es casi imposible escuchar. Una pausa con hora de regreso no es abandonar la conversación: es cuidarla.</p>
  <span class="lbl">¿Cuándo vuelven a conversar?</span><div class="opts">${[[30,'En 30 minutos'],[60,'En 1 hora'],[120,'En 2 horas'],[720,'Mañana']].map(([m,t])=>`<button class="op" data-act="pausa-ok" data-m="${m}">${t}</button>`).join('')}</div>
  <p class="note">${e(nom(otro(rol())))} verá en su teléfono que pediste una pausa y la hora de regreso. Las pausas sirven si duran al menos 30 minutos y menos de un día.</p>
  <div class="row end"><button class="btn ghost" data-act="cerrar">Cancelar</button></div>`)}
function respirar(){modal(`<h3>Respirar</h3><div class="resp"><div class="bola"></div><b id="resp-t">Inhala</b></div><p class="note center">Inhala 4 segundos y exhala 6. Suelta los hombros y la mandíbula. Ideas para la pausa: caminar, ducharse, escuchar música, ordenar algo. Evita ensayar lo que vas a responder.</p><div class="row end"><button class="btn pri" data-act="cerrar">Terminar</button></div>`,{onClose:()=>clearInterval(S.respT)});
  let i=0;clearInterval(S.respT);S.respT=setInterval(()=>{i=(i+1)%10;const t=$('#resp-t');if(t)t.textContent=i<4?'Inhala':'Exhala'},1000)}

const EJ=[
  {id:'incidente',p:6,t:'Procesar una pelea o incidente',d:'Cinco pasos para conversar con calma una pelea pasada, como si la miraran desde el balcón.'},
  {id:'rapoport',p:7,t:'Entender antes de persuadir',d:'Turnos de hablante y oyente: resumir y validar antes de dar tu postura.'},
  {id:'jinetes',p:7,t:'Los Cuatro Jinetes y sus antídotos',d:'Qué dañan y con qué reemplazarlos.'},
  {id:'mapas',p:8,t:'Preguntas para conocernos hoy',d:'Preguntas abiertas para actualizar sus mapas de amor.'},
  {id:'estres',p:8,t:'Conversación para bajar el estrés',d:'Veinte minutos para hablar del día, del lado del otro.'},
  {id:'sueno',p:10,t:'El sueño dentro del conflicto',d:'Para temas en que están atascados: qué hay detrás de cada postura.'},
  {id:'significado',p:10,t:'Nuestro significado compartido',d:'Rituales, roles y metas que los hacen un "nosotros".'}];
function pEjercicios(){const r=rol(),o=otro(r);
  let h=`<div class="sh"><h2>Ejercicios</h2><p>Herramientas para practicar entre sesiones. Tu terapeuta te dirá cuáles usar.</p></div>
  <button class="card opt ej pausa-ej" data-act="pausa"><span class="lic">${ico('pausa')}</span><span class="ltx"><b>Necesito una pausa para calmarme</b><span>Avisa a ${e(nom(o))}, fija la hora de regreso y te guía para calmarte.</span></span></button>
  ${EJ.map(x=>`<button class="card opt ej" data-act="ej" data-id="${x.id}"><span class="lic">${ico(ICO_EJ[x.id]||'ejercicios')}</span><span class="ltx"><b>${e(x.t)}</b><span>${e(x.d)}</span></span></button>`).join('')}`;
  const inc=regs('incidente').sort((a,b)=>a.fecha<b.fecha?1:-1).slice(0,6);
  if(inc.length)h+=`<div class="card"><h3>Incidentes procesados</h3>${inc.map(i=>`<div class="nota"><span class="lbl">${i.autor===r?'Mi versión':'Versión de '+e(nom(i.autor))} · ${UIX.fCorta(i.fecha)}${i.privado?' · solo terapeuta':''}</span><p><b>${e(i.titulo||'Incidente')}</b></p>${i.autor!==r?resumenIncidente(i):''}</div>`).join('')}</div>`;
  return h}
function resumenIncidente(i){return`<p class="note">Se sintió: ${e((i.sentimientos||[]).join(', ')||'—')}</p>${i.realidad?`<p><i>Su realidad:</i> ${e(i.realidad)}</p>`:''}${i.valido?`<p><i>Lo que entiende de la otra parte:</i> ${e(i.valido)}</p>`:''}${i.detonantes?`<p><i>Qué le detonó:</i> ${e(i.detonantes)}</p>`:''}${i.responsabilidad?`<p><i>Su parte:</i> ${e(i.responsabilidad)}</p>`:''}${i.plan?`<p><i>Para la próxima vez:</i> ${e(i.plan)}</p>`:''}`}
function abrirEjercicio(id){const o=nom(otro(rol()));const J=EVID.JINETES;
  if(id==='incidente'){S.inc={sentimientos:[]};return modal(`<h3>Procesar una pelea o incidente</h3>
  <p class="note">Háganlo cuando ambos estén tranquilos. La idea es entender, no volver a pelear: cada uno tiene su propia realidad y ambas tienen algo de válido. Cada uno completa su versión y luego la conversan.</p>
  <label class="fld"><span class="lbl">¿De qué incidente se trata? (pocas palabras)</span><input id="inc-tit" maxlength="120"></label>
  <div class="fld"><span class="q">1. Cómo me sentí <i class="muted">(solo sentimientos, sin explicar por qué)</i></span><div class="opts">${EVID.SENTIMIENTOS.map(x=>`<button class="op" data-act="inc-s" data-v="${e(x)}">${e(x)}</button>`).join('')}</div></div>
  <label class="fld"><span class="q">2. Mi realidad: cómo lo viví yo</span><textarea id="inc-real" rows="3"></textarea></label>
  <label class="fld"><span class="lbl">Una parte de la realidad de ${e(o)} que entiendo y me hace sentido</span><textarea id="inc-val" rows="2"></textarea></label>
  <label class="fld"><span class="q">3. Qué me detonó <i class="muted">(recuerdos o experiencias que lo intensificaron)</i></span><textarea id="inc-det" rows="2"></textarea></label>
  <label class="fld"><span class="q">4. Mi parte: qué hice yo que contribuyó</span><textarea id="inc-resp" rows="2" placeholder="Por ejemplo: estaba estresado y reaccioné con crítica"></textarea></label>
  <label class="fld"><span class="q">5. Para la próxima vez: algo que yo haré distinto, y algo que te pido</span><textarea id="inc-plan" rows="2"></textarea></label>
  <label class="chk"><input type="checkbox" id="inc-comp" checked><span>Compartir mi versión con ${e(o)} (si no, la ve solo el terapeuta)</span></label>
  <div class="row end"><button class="btn ghost" data-act="cerrar">Cancelar</button><button class="btn pri" data-act="inc-guardar">Guardar</button></div>`)}
  const guias={
    rapoport:`<h3>Entender antes de persuadir</h3><ol class="pasos"><li><b>Quien habla</b> cuenta qué siente, en qué situación y qué necesita, en positivo ("necesito…" en vez de "no quiero…"), sin culpar.</li><li><b>Quien escucha</b> toma notas y solo pregunta para entender. Todavía no da su opinión.</li><li>Quien escucha <b>resume</b> lo que oyó hasta que el otro diga "sí, es eso", y <b>valida</b>: "Desde tu punto de vista, tiene sentido que necesites…".</li><li><b>Cambian de rol.</b></li><li>Solo cuando ambos se sienten comprendidos, buscan un acuerdo en que los dos cedan algo.</li></ol><p class="note">Si alguno se desborda, usen la pausa.</p>`,
    jinetes:`<h3>Los Cuatro Jinetes</h3><p class="note">Son cuatro formas de discutir que, según la investigación de los Gottman, predicen el deterioro de la relación. Cada una tiene un antídoto.</p>${J.map(x=>`<div class="nota"><b>${e(x.n)} → ${e(x.an)}</b><p>${e(x.ad)}</p></div>`).join('')}<p class="note">El desprecio (burla, sarcasmo, ojos en blanco) es el más dañino. En las parejas que funcionan bien, incluso durante un conflicto, los momentos positivos superan con creces a los negativos.</p>`,
    mapas:`<h3>Preguntas para conocernos hoy</h3><p class="note">Las personas cambian; conocer cómo está el otro hoy es la base de la amistad de pareja. Elijan una pregunta, escuchen con curiosidad y sin corregir.</p><div class="preg" id="preg">${e(EVID.PREGUNTAS_MAPAS[Math.floor(Math.random()*EVID.PREGUNTAS_MAPAS.length)])}</div><button class="btn" data-act="otra-preg">Otra pregunta</button>`,
    estres:`<h3>Conversación para bajar el estrés</h3><p class="note">Unos 20 minutos al día para hablar del estrés de fuera de la relación (trabajo, familia, salud). No es momento para hablar de problemas entre ustedes.</p><ol class="pasos"><li>Túrnense: unos 10 minutos cada uno.</li><li>Quien escucha muestra interés genuino y pregunta "¿qué es lo que más te preocupa?" o "cuéntame más".</li><li>No dar consejos si no los piden: primero comprender.</li><li>Ponerse de su lado: "nosotros contra el problema".</li><li>Expresar cariño: "qué pesado, entiendo que estés agotado".</li></ol>`,
    sueno:`<h3>El sueño dentro del conflicto</h3><p class="note">Muchos conflictos que se repiten no se resuelven porque detrás de cada postura hay un sueño, un valor o una historia que no se ha dicho. El objetivo no es resolver todavía, sino entenderse.</p><ol class="pasos"><li>Elijan un tema en que estén atascados.</li><li>Uno es quien cuenta su sueño; el otro solo pregunta y escucha, sin intentar convencer.</li><li>Después cambian de rol.</li></ol><span class="lbl">Preguntas para quien escucha</span><ul>${EVID.PREGUNTAS_SUENO.map(q=>`<li>${e(q)}</li>`).join('')}</ul><p class="note">Al final, cada uno puede decir qué parte del sueño del otro está dispuesto a apoyar.</p>`,
    significado:`<h3>Nuestro significado compartido</h3><p class="note">Las parejas fuertes construyen un "nosotros" con rituales, roles, metas y símbolos propios. Conversen una pregunta por vez:</p><ul><li><b>Rituales:</b> ¿cómo queremos que sean nuestras comidas, despedidas, reencuentros, fines de semana y celebraciones?</li><li><b>Roles:</b> ¿qué significa para cada uno ser pareja, padre o madre, hijo o hija, amigo?</li><li><b>Metas:</b> ¿qué queremos lograr juntos en los próximos años?</li><li><b>Símbolos y valores:</b> ¿qué objetos, lugares o frases nos representan? ¿Qué valores queremos transmitir?</li></ul>`};
  modal((guias[id]||'')+`<div class="row end"><button class="btn pri" data-act="cerrar">Cerrar</button></div>`)}

/* ===================== Pareja: OBJETIVOS y PROGRESO ===================== */
function tarjetaObjetivo(ob,ses){const g=ses?.gas?.[ob.id];
  return`<div class="card obj"><div class="obh"><span class="mtag">${e(EVID.MODELOS[ob.modelo]?.corto||'')}</span><b>${e(ob.titulo)}</b>${ob.estado==='logrado'?'<span class="badge ok">Logrado</span>':''}</div>
  <p>${e(ob.desc||'')}</p><span class="lbl">Para: ${ob.para==='a'?e(nom('a')):ob.para==='b'?e(nom('b')):'ambos'}</span>
  ${(ob.indicadores||[]).length?`<div><span class="lbl">Indicadores</span><ul>${ob.indicadores.map(i=>`<li>${e(i)}</li>`).join('')}</ul></div>`:''}
  ${(ob.tareas||[]).length?`<div><span class="lbl">Tareas</span><ul>${ob.tareas.map(t=>`<li>${e(t.t)} <i class="muted">· ${e(t.f||'')}</i></li>`).join('')}</ul></div>`:''}
  <div class="gas">${['2','1','0','-1','-2'].map(k=>`<div class="gl ${g!=null&&String(g)===k?'on':''}"><b>${k>0?'+'+k:k}</b><span>${e(ob.gas?.[k]||'')}</span></div>`).join('')}</div>
  ${g!=null?`<p class="note">Marcado en la sesión del ${UIX.fCorta(ses.fecha)}.</p>`:''}</div>`}
function pObjetivos(){const obs=MED.objetivosActivos(R());const ses=MED.ultimaSesion(R());
  return`<div class="sh"><h2>Objetivos</h2><p>Los define tu terapeuta según el diagnóstico. La escala de −2 a +2 muestra cómo se ve cada nivel de avance; 0 es la meta esperada.</p></div>`+(obs.length?obs.map(o=>tarjetaObjetivo(o,ses)).join(''):'<div class="card"><p class="note">Todavía no hay objetivos.</p></div>')}

function pProgreso(){const r=rol(),o=otro(r),p=pareja();let h=`<div class="sh"><h2>Progreso</h2><p>Cómo te evalúas tú y cómo te ve ${e(nom(o))}${p.compartirEval?'':' (tu terapeuta decidió no mostrar las evaluaciones de tu pareja)'}.</p></div>`;
  const cc=MED.serieCSI(R())[r];const gg=MED.serieGAS(R());
  if((cc.length>=2&&cc[cc.length-1].total>cc[0].total)||(gg.length>=2&&gg[gg.length-1].t>gg[0].t))h+=`<div class="card aprecio"><b>Van avanzando</b><p class="note">${cc.length>=2&&cc[cc.length-1].total>cc[0].total?`Tu satisfacción subió de ${cc[0].total} a ${cc[cc.length-1].total}. `:''}${gg.length>=2&&gg[gg.length-1].t>gg[0].t?'El logro de los objetivos mejora de sesión en sesión. ':''}Los cambios en pareja toman tiempo y tienen altibajos; lo importante es la tendencia.</p></div>`;
  const ad=MED.adherencia(R(),r);h+=`<div class="card"><div class="row sb"><span>Días registrados esta semana</span><b class="big">${ad.dias}/7</b></div></div>`;
  for(const ob of MED.objetivosActivos(R())){if(!MED.aplica(ob,r)&&!MED.aplica(ob,o))continue;const s=MED.serieObjetivo(R(),ob.id);
    const series=[{nombre:'Yo',color:UIX.COL[r],datos:s.map(x=>({x:x.semana,y:x[r+'_self']}))}];
    if(p.compartirEval)series.push({nombre:`Cómo me ve ${nom(o)}`,color:UIX.COL[r],guion:true,datos:s.map(x=>({x:x.semana,y:x[r+'_por_'+o]}))});
    series.push({nombre:`Cómo veo a ${nom(o)}`,color:UIX.COL[o],guion:true,datos:s.map(x=>({x:x.semana,y:x[o+'_por_'+r]}))});
    h+=`<div class="card"><b>${e(ob.titulo)}</b><span class="lbl">Promedio semanal (0–10)</span>${UIX.lineas({series})}</div>`}
  const c=MED.serieCSI(R());const cs=[{nombre:'Yo',color:UIX.COL[r],datos:c[r].map(x=>({x:x.fecha,y:x.total}))}];if(c[o].length)cs.push({nombre:nom(o),color:UIX.COL[o],datos:c[o].map(x=>({x:x.fecha,y:x.total}))});
  h+=`<div class="card"><b>Satisfacción con la relación</b><span class="lbl">0 a 20 · cada punto es una semana</span>${UIX.lineas({series:cs,min:0,max:20})}</div>`;
  const sj=MED.serieJinetes(R());if(sj.length)h+=`<div class="card"><b>Mis jinetes y antídotos</b><span class="lbl">Por semana</span>${UIX.lineas({series:[{nombre:'Jinetes',color:'var(--warn)',datos:sj.map(x=>({x:x.semana,y:x[r+'_j']}))},{nombre:'Antídotos',color:'var(--ok)',datos:sj.map(x=>({x:x.semana,y:x[r+'_a']}))}],min:0,max:Math.max(10,...sj.flatMap(x=>[x[r+'_j'],x[r+'_a']]))})}</div>`;
  const g=MED.serieGAS(R());if(g.length)h+=`<div class="card"><b>Logro de objetivos según las sesiones</b><span class="lbl">Puntaje GAS (50 = metas cumplidas como se esperaba)</span>${UIX.lineas({series:[{nombre:'Puntaje GAS',color:'var(--ink)',datos:g.map(x=>({x:x.fecha,y:x.t}))}],min:20,max:80,corte:50,corteTxt:'meta'})}</div>`;
  return h}

/* ===================== Terapeuta ===================== */
function tParejas(){const ps=Object.values(Datos.dev.parejas);
  let h=`<div class="sh row sb"><div><h2>Parejas</h2><p>${ps.length?'Toca una pareja para ver su avance.':'Crea la primera ficha para entregar el código a la pareja.'}</p></div></div>
  <button class="btn pri big" data-act="nueva-pareja">+ Nueva pareja</button>`;
  for(const p of ps){const Rr=p.R||{};const pa=Rr.pareja||{};const al=MED.alertas(Rr);const grave=al.filter(a=>a.nivel>=2).length;
    const ult=[MED.ultimoRegistro(Rr,'a'),MED.ultimoRegistro(Rr,'b')].filter(Boolean).sort().pop();
    h+=`<button class="card opt pcard" data-act="abrir-pareja" data-c="${e(p.codigo)}"><div class="row sb"><b>${e(pa.nombres?.a||'Él')} y ${e(pa.nombres?.b||'Ella')}</b>${grave?`<span class="badge warn">${grave} alerta${grave>1?'s':''}</span>`:al.length?`<span class="badge">${al.length} aviso${al.length>1?'s':''}</span>`:''}</div>
    <span>Código ${e(p.codigo)} · ${MED.objetivosActivos(Rr).length} objetivos · ${ult?'último registro '+UIX.fCorta(ult):'sin registros aún'}</span></button>`}
  return h}

function tPareja(){const subs=[['resumen','Resumen'],['evaluacion','Evaluación'],['diagnostico','Diagnóstico'],['objetivos','Objetivos'],['sesion','Sesiones'],['datos','Pareja']];
  return`<div class="sh"><button class="back" data-act="tab" data-t="parejas">← Parejas</button><h2>${e(nom('a'))} y ${e(nom('b'))}</h2></div>
  <div class="subnav">${subs.map(([k,t])=>`<button class="st" data-act="sub" data-s="${k}" ${S.sub===k?'aria-current="page"':''}>${t}</button>`).join('')}</div>`+
  ({resumen:tResumen,evaluacion:tEvaluacion,diagnostico:tDiagnostico,objetivos:tObjetivos,sesion:tSesiones,datos:tDatos}[S.sub]||tResumen)()}

function tResumen(){const Rr=R();let h='';const al=MED.alertas(Rr);
  if(al.length)h+=`<div class="card"><h3>Alertas</h3>${al.map(a=>`<div class="al n${a.nivel}"><span>${e(a.txt)}</span>${a.tipo==='seguridad'?`<div class="row"><button class="btn sm" data-act="ver-seg" data-r="${a.rol}">Ver respuestas</button><button class="btn sm ghost" data-act="revisar" data-id="${e(a.id)}">Marcar revisada</button></div>`:''}</div>`).join('')}</div>`;
  else h+=`<div class="card soft"><p class="note">Sin alertas. Las alertas avisan de respuestas de seguridad, bajas en la satisfacción, sesiones mal evaluadas, diferencias grandes de percepción y días sin registro.</p></div>`;
  const ad={a:MED.adherencia(Rr,'a'),b:MED.adherencia(Rr,'b')};const c=MED.serieCSI(Rr);const g=MED.serieGAS(Rr);
  const lastC=r=>c[r].length?c[r][c[r].length-1].total:'—';
  h+=`<div class="kpis"><div class="kpi"><span>${e(nom('a'))}</span><b>${ad.a.dias}/7</b><i>días con registro</i></div><div class="kpi"><span>${e(nom('b'))}</span><b>${ad.b.dias}/7</b><i>días con registro</i></div>
  <div class="kpi"><span>Satisfacción actual</span><b>${lastC('a')} · ${lastC('b')}</b><i>de 20 · zona baja bajo 9</i></div><div class="kpi"><span>Puntaje GAS</span><b>${g.length?g[g.length-1].t:'—'}</b><i>50 = esperado</i></div></div>`;
  h+=`<div class="card"><b>Satisfacción semanal</b>${UIX.lineas({series:[{nombre:nom('a'),color:UIX.COL.a,datos:c.a.map(x=>({x:x.fecha,y:x.total}))},{nombre:nom('b'),color:UIX.COL.b,datos:c.b.map(x=>({x:x.fecha,y:x.total}))}],min:0,max:20,corte:MED.SAT_BAJO,corteTxt:'zona baja'})}</div>`;
  if(g.length)h+=`<div class="card"><b>Logro de metas por sesión (GAS, puntaje T)</b>${UIX.lineas({series:[{nombre:'GAS',color:'var(--ink)',datos:g.map(x=>({x:x.fecha,y:x.t}))}],min:20,max:80,corte:50,corteTxt:'esperado'})}</div>`;
  for(const ob of MED.objetivosActivos(Rr)){const s=MED.serieObjetivo(Rr,ob.id);const ba=MED.brecha(s,'a'),bb=MED.brecha(s,'b');
    h+=`<div class="card"><div class="obh"><span class="mtag">${e(EVID.MODELOS[ob.modelo]?.corto||'')}</span><b>${e(ob.titulo)}</b></div>
    ${UIX.lineas({series:[{nombre:`${nom('a')} se evalúa`,color:UIX.COL.a,datos:s.map(x=>({x:x.semana,y:x.a_self}))},{nombre:`${nom('b')} evalúa a ${nom('a')}`,color:UIX.COL.a,guion:true,datos:s.map(x=>({x:x.semana,y:x.a_por_b}))},
      {nombre:`${nom('b')} se evalúa`,color:UIX.COL.b,datos:s.map(x=>({x:x.semana,y:x.b_self}))},{nombre:`${nom('a')} evalúa a ${nom('b')}`,color:UIX.COL.b,guion:true,datos:s.map(x=>({x:x.semana,y:x.b_por_a}))}]})}
    <p class="note">Brecha de percepción (autoevaluación − evaluación de la pareja, últimas 2 semanas): ${e(nom('a'))} ${ba??'—'} · ${e(nom('b'))} ${bb??'—'}</p></div>`}
  const sj=MED.serieJinetes(Rr);
  if(sj.length)h+=`<div class="card"><b>Cuatro Jinetes y antídotos (por semana)</b><span class="lbl">Suma de jinetes y de antídotos que cada uno reporta usar</span>${UIX.lineas({series:[{nombre:`${nom('a')}: jinetes`,color:UIX.COL.a,datos:sj.map(x=>({x:x.semana,y:x.a_j}))},{nombre:`${nom('a')}: antídotos`,color:UIX.COL.a,guion:true,datos:sj.map(x=>({x:x.semana,y:x.a_a}))},{nombre:`${nom('b')}: jinetes`,color:UIX.COL.b,datos:sj.map(x=>({x:x.semana,y:x.b_j}))},{nombre:`${nom('b')}: antídotos`,color:UIX.COL.b,guion:true,datos:sj.map(x=>({x:x.semana,y:x.b_a}))}],min:0,max:Math.max(10,...sj.flatMap(x=>[x.a_j,x.a_a,x.b_j,x.b_a]))})}</div>`;
  const inc=regs('incidente').sort((a,b)=>a.fecha<b.fecha?1:-1).slice(0,6);const pa=regs('pausa').filter(p=>MED.diasDesde(p.fecha)<=14);
  if(inc.length||pa.length)h+=`<div class="card"><h3>Incidentes y pausas</h3>${pa.length?`<p class="note">Pausas para calmarse en 14 días: ${e(nom('a'))} ${pa.filter(p=>p.autor==='a').length} · ${e(nom('b'))} ${pa.filter(p=>p.autor==='b').length}</p>`:''}
    ${inc.map(i=>`<details class="nota"><summary><span class="lbl">${e(nom(i.autor))} · ${UIX.fCorta(i.fecha)}${i.privado?' · privado':''}</span> <b>${e(i.titulo||'Incidente')}</b></summary>${resumenIncidente(i)}</details>`).join('')}</div>`;
  const notas=[...regs('nota'),...regs('aprecio')].sort((a,b)=>a.fecha<b.fecha?1:-1).slice(0,12);
  if(notas.length)h+=`<div class="card"><h3>Notas recientes</h3>${notas.map(n=>`<div class="nota"><span class="lbl">${e(nom(n.autor))} · ${UIX.fCorta(n.fecha)} · ${n.tipo==='nota'?'privada':'aprecio (compartido)'}</span><p>${e(n.texto)}</p></div>`).join('')}</div>`;
  const ali=regs('alianza').sort((a,b)=>a.fecha<b.fecha?1:-1).slice(0,4);
  if(ali.length)h+=`<div class="card"><h3>Retroalimentación de sesiones</h3>${ali.map(a=>`<div class="nota"><span class="lbl">${e(nom(a.autor))} · ${UIX.fCorta(a.fecha)}</span><p>${EVID.ALIANZA.map(q=>`${e(q.p)}: <b>${a.resp?.[q.id]??'—'}</b>`).join(' · ')}${a.texto?`<br>“${e(a.texto)}”`:''}</p></div>`).join('')}</div>`;
  h+=`<button class="btn" data-act="informe">Exportar informe de avance</button>`;
  return h}

function tDiagnostico(){const f=R().formulacion||{};const ini={a:regs('inicial').filter(x=>x.autor==='a').pop(),b:regs('inicial').filter(x=>x.autor==='b').pop()};
  const areas=new Set(f.areas||[]);const N=['—','Poco','Bastante','Mucho'];
  let h=`<div class="card"><h3>Diagnóstico y formulación</h3>
  <label class="fld"><span class="lbl">Motivo de consulta</span><textarea id="f-motivo" rows="2">${e(f.motivo||'')}</textarea></label>
  <label class="fld"><span class="lbl">Diagnóstico / hipótesis clínica</span><textarea id="f-diag" rows="3">${e(f.diagnostico||'')}</textarea></label>
  <label class="fld"><span class="lbl">Modelo principal</span><select id="f-modelo">${Object.entries(EVID.MODELOS).map(([k,m])=>`<option value="${k}" ${f.modelo===k?'selected':''}>${e(m.nombre)}</option>`).join('')}</select></label>
  <div class="fld"><span class="lbl">Áreas de problema (con lo que reportó cada uno en la evaluación inicial)</span><div class="areas">${Object.entries(EVID.AREAS).map(([k,t])=>{const va=ini.a?.areas?.[k],vb=ini.b?.areas?.[k];
    return`<label class="chk area"><input type="checkbox" data-area="${k}" ${areas.has(k)?'checked':''}><span>${e(t)}${(va||vb)?` <i class="muted">${e(nom('a'))}: ${N[va||0]} · ${e(nom('b'))}: ${N[vb||0]}</i>`:''}</span></label>`}).join('')}</div>
  ${!ini.a||!ini.b?`<p class="note">${[!ini.a&&nom('a'),!ini.b&&nom('b')].filter(Boolean).map(e).join(' y ')} todavía no completa la evaluación inicial en su teléfono.</p>`:''}</div>
  <details class="fld" ${f.modelo==='ibct'?'open':''}><summary class="lbl">Formulación DEEP (IBCT)</summary>
   ${[['d','Diferencias'],['e','Sensibilidades emocionales'],['x','Estrés externo'],['p','Patrón de interacción']].map(([k,t])=>`<label class="fld"><span class="lbl">${t}</span><textarea data-deep="${k}" rows="2">${e(f.deep?.[k]||'')}</textarea></label>`).join('')}</details>
  <details class="fld" ${f.modelo==='eft'?'open':''}><summary class="lbl">Ciclo negativo (EFT)</summary>
   <div class="g2">${['a','b'].map(r=>`<label class="fld"><span class="lbl">${e(nom(r))} en el ciclo</span><select data-ciclo="${r}">${['','persigue','se retira','ambos alternan'].map(v=>`<option ${f.ciclo?.[r]===v?'selected':''}>${v}</option>`).join('')}</select></label>`).join('')}</div>
   <label class="fld"><span class="lbl">Descripción del ciclo y emociones primarias</span><textarea id="f-ciclo" rows="3">${e(f.ciclo?.desc||'')}</textarea></label></details>
  <label class="fld"><span class="lbl">Fortalezas de la pareja</span><textarea id="f-fort" rows="2">${e(f.fortalezas||'')}</textarea></label>
  <label class="fld"><span class="lbl">Riesgos o contraindicaciones (violencia, consumo, salud mental)</span><textarea id="f-riesgo" rows="2">${e(f.riesgos||'')}</textarea></label>
  <button class="btn pri" data-act="guardar-diag">Guardar diagnóstico</button>
  <p class="note">El diagnóstico es privado: la pareja no lo ve.</p></div>`;
  const sug=EVID.sugerir(f.areas||[],f.modelo,MED.casaDebil(R()));const tiene=new Set(MED.objetivosActivos(R()).map(o=>o.base));
  h+=`<div class="card"><h3>Objetivos sugeridos según el diagnóstico</h3>${sug.length?sug.slice(0,10).map(o=>filaBiblioteca(o,tiene.has(o.id))).join(''):'<p class="note">Marca áreas de problema (y completa la evaluación) para ver sugerencias.</p>'}</div>`;
  return h}
/* ---------- Evaluación y ruta (principios 2, 3 y 4) ---------- */
function tEvaluacion(){const f=R().formulacion||{};const P=MED.perfilCasa(R());S.casaEv=S.casaEv||Object.assign({},f.casa||{});
  const ent=f.entrevistas||{},band=f.banderas||{};const EV=['Fortaleza','Por trabajar','Problema'];
  const pr=r=>P[r]?'':'<i class="muted">sin respuesta</i>';
  return`<div class="card"><h3>Evaluación: Casa de la Relación Sólida</h3><p class="note">Evaluar antes de decidir el tratamiento. Junto a cada nivel, lo que cada uno respondió en su teléfono (0 a 4; breve, no validado). Marca tu evaluación clínica.</p>
  ${EVID.CASA.map(c=>`<div class="gasrow"><div class="row sb"><b>${e(c.n)}${c.muro?' <i class="muted">(muro)</i>':''}</b><span class="lbl">${e(nom('a'))}: ${P.a?.[c.id]??'—'} · ${e(nom('b'))}: ${P.b?.[c.id]??'—'}</span></div><span class="note">${e(c.d)}</span>
  <div class="seg">${EV.map((t,v)=>`<button class="sg ${S.casaEv[c.id]===v?'on':''}" data-act="casa-ev" data-k="${c.id}" data-v="${v}">${t}</button>`).join('')}</div></div>`).join('')}
  ${!P.a||!P.b?`<p class="note">${[!P.a&&nom('a'),!P.b&&nom('b')].filter(Boolean).map(e).join(' y ')} todavía no responde la evaluación inicial.</p>`:''}</div>
  <div class="card"><h3>Lista de chequeo y señales de alarma</h3>
  ${EVID.BANDERAS.map(x=>`<label class="chk"><input type="checkbox" data-band="${x.id}" ${band[x.id]?'checked':''}><span><b>${e(x.n)}</b><br><i>${e(x.txt)}</i></span></label>`).join('')}
  <h3>Mundo interior de cada uno</h3><p class="note">Entrevista individual con cada miembro: historia de la relación, infancia y relaciones anteriores, traumas, consumo, y si siente miedo de su pareja. Explica la política de cero secretos: lo que se cuente a solas que afecte la terapia (por ejemplo, una relación con otra persona) no se guarda en secreto.</p>
  ${[['ia','Entrevista individual con '+nom('a')],['ib','Entrevista individual con '+nom('b')],['historia','Historia de la relación'],['secretos','Política de cero secretos explicada'],['consumo','Consumo de alcohol y drogas consultado']].map(([k,t])=>`<label class="chk"><input type="checkbox" data-ent="${k}" ${ent[k]?'checked':''}><span>${e(t)}</span></label>`).join('')}
  <div class="g2">${['a','b'].map(r=>`<label class="fld"><span class="lbl">${e(nom(r))}: historia, apego, heridas, sueños</span><textarea data-mundo="${r}" rows="4">${e(f.mundo?.[r]||'')}</textarea></label>`).join('')}</div>
  <button class="btn pri" data-act="guardar-eval">Guardar evaluación</button></div>
  ${tRuta()}`}
function tRuta(){const f=R().formulacion||{};const ev=f.casa||{};const obs=MED.objetivosActivos(R()).filter(o=>o.estado!=='archivado');
  const cuenta=id=>obs.filter(o=>(o.casa||EVID.OBJETIVOS.find(t=>t.id===o.base)?.casa)===id).length;
  const niv=EVID.CASA.map(c=>({id:c.id,n:c.n,estado:ev[c.id]??null,txt:cuenta(c.id)?cuenta(c.id)+' obj.':''}));
  const debiles=MED.casaDebil(R());const sinObj=debiles.filter(d=>!cuenta(d)).map(d=>EVID.CASA.find(c=>c.id===d).n);
  return`<div class="card"><h3>Ruta de tratamiento</h3><p class="note">La casa resume la evaluación y muestra cuántos objetivos trabajan cada nivel. Puedes mostrársela a la pareja para explicar la ruta.</p>${UIX.casa(niv)}
  ${sinObj.length?`<p class="note">Niveles con dificultad sin objetivo asignado: <b>${sinObj.map(e).join(', ')}</b>. Revisa las sugerencias.</p>`:''}
  ${ev.conflicto>=1&&(ev.mapas>=1||ev.carino>=1||ev.acercarse>=1)?'<p class="note">Hay dificultades en la amistad y en el conflicto: suele ayudar empezar por calmarse y procesar incidentes, y fortalecer la amistad en paralelo.</p>':''}</div>`}

function filaBiblioteca(o,ya){return`<div class="lib"><div><span class="mtag">${e(EVID.MODELOS[o.modelo].corto)}</span> <b>${e(o.titulo)}</b><p class="note">${e(o.desc)}</p></div>${rol()==='t'&&S.tab==='pareja'?(ya?'<span class="badge ok">Asignado</span>':`<button class="btn sm" data-act="agregar-obj" data-id="${o.id}">Agregar</button>`):''}</div>`}

function tObjetivos(){const obs=Object.values(R()).filter(r=>r.tipo==='objetivo'&&!r.borrado).sort((a,b)=>(a.estado==='archivado')-(b.estado==='archivado')||(a.orden||0)-(b.orden||0));
  let h=`<div class="row"><button class="btn pri" data-act="sub" data-s="diagnostico">+ Desde sugeridos</button><button class="btn" data-act="tab" data-t="biblioteca">Biblioteca completa</button><button class="btn ghost" data-act="obj-nuevo">Objetivo propio</button></div>`;
  if(!obs.length)return h+`<div class="card"><p class="note">Sin objetivos. Agrégalos desde las sugeridas por el diagnóstico o desde la biblioteca; luego puedes adaptar el texto, los indicadores y la escala.</p></div>`;
  for(const o of obs)h+=`<div class="card obj ${o.estado==='archivado'?'arch':''}"><div class="obh"><span class="mtag">${e(EVID.MODELOS[o.modelo]?.corto||'')}</span><b>${e(o.titulo)}</b><span class="badge ${o.estado==='logrado'?'ok':''}">${e(o.estado||'activo')}</span></div>
   <span class="lbl">Para: ${o.para==='a'?e(nom('a')):o.para==='b'?e(nom('b')):'ambos'} · peso ${o.peso||1}${o.casa?' · '+e(EVID.CASA.find(c=>c.id===o.casa)?.n||''):''}</span><div class="row"><button class="btn sm" data-act="obj-editar" data-id="${o.id}">Editar</button></div></div>`;
  return h}

function editarObjetivo(o){const nuevo=!o.id;o=Object.assign({para:'ambos',peso:1,estado:'activo',modelo:'comun',gas:{},indicadores:[],tareas:[]},o);S.edit=o;
  modal(`<h3>${nuevo?'Nuevo objetivo':'Editar objetivo'}</h3>
  <label class="fld"><span class="lbl">Título</span><input id="o-tit" value="${e(o.titulo||'')}"></label>
  <label class="fld"><span class="lbl">Descripción (la ve la pareja)</span><textarea id="o-desc" rows="3">${e(o.desc||'')}</textarea></label>
  <div class="g2"><label class="fld"><span class="lbl">Para</span><select id="o-para"><option value="ambos">Ambos</option><option value="a" ${o.para==='a'?'selected':''}>${e(nom('a'))}</option><option value="b" ${o.para==='b'?'selected':''}>${e(nom('b'))}</option></select></label>
  <label class="fld"><span class="lbl">Modelo</span><select id="o-mod">${Object.entries(EVID.MODELOS).map(([k,m])=>`<option value="${k}" ${o.modelo===k?'selected':''}>${m.corto}</option>`).join('')}</select></label>
  <label class="fld"><span class="lbl">Peso (importancia)</span><select id="o-peso">${[1,2,3].map(v=>`<option ${o.peso==v?'selected':''}>${v}</option>`).join('')}</select></label>
  <label class="fld"><span class="lbl">Nivel de la casa</span><select id="o-casa"><option value="">—</option>${EVID.CASA.map(c=>`<option value="${c.id}" ${o.casa===c.id?'selected':''}>${e(c.n)}</option>`).join('')}</select></label>
  <label class="fld"><span class="lbl">Estado</span><select id="o-est">${['activo','logrado','pausado','archivado'].map(v=>`<option ${o.estado===v?'selected':''}>${v}</option>`).join('')}</select></label></div>
  <label class="fld"><span class="lbl">Indicadores observables (uno por línea)</span><textarea id="o-ind" rows="3">${e((o.indicadores||[]).join('\n'))}</textarea></label>
  <div class="fld"><span class="lbl">Escala de logro (GAS)</span>${['2','1','0','-1','-2'].map(k=>`<label class="gasin"><b>${k>0?'+'+k:k}</b><input data-gas="${k}" value="${e(o.gas?.[k]||'')}" placeholder="${e(GASTXT[k])}"></label>`).join('')}</div>
  <label class="fld"><span class="lbl">Tareas (una por línea: tarea | frecuencia)</span><textarea id="o-tar" rows="3">${e((o.tareas||[]).map(t=>t.t+(t.f?' | '+t.f:'')).join('\n'))}</textarea></label>
  <p class="note">Frecuencias sugeridas: ${FREQ.join(', ')}.</p>
  <div class="row end">${nuevo?'':'<button class="btn ghost danger" data-act="obj-borrar">Eliminar</button>'}<button class="btn ghost" data-act="cerrar">Cancelar</button><button class="btn pri" data-act="obj-guardar">Guardar</button></div>`)}
function guardarObjetivo(){const o=S.edit;const v=id=>$(id).value.trim();
  const rec=Object.assign({},o,{id:o.id||uid('ob'),tipo:'objetivo',titulo:v('#o-tit')||'Objetivo',desc:v('#o-desc'),para:v('#o-para'),modelo:v('#o-mod'),casa:v('#o-casa')||undefined,peso:+v('#o-peso'),estado:v('#o-est'),
    indicadores:v('#o-ind').split('\n').map(x=>x.trim()).filter(Boolean),gas:Object.fromEntries([...document.querySelectorAll('[data-gas]')].map(i=>[i.dataset.gas,i.value.trim()])),
    tareas:v('#o-tar').split('\n').map(x=>x.trim()).filter(Boolean).map(x=>{const[t,f]=x.split('|');return{t:t.trim(),f:(f||'').trim()}}),creado:o.creado||Date.now(),orden:o.orden??MED.objetivosActivos(R()).length});
  Datos.guardar(C(),rec);cerrarModal();toast('Objetivo guardado');render()}
function agregarDeBiblioteca(id){const t=EVID.OBJETIVOS.find(x=>x.id===id);if(!t)return;
  editarObjetivo({base:t.id,casa:t.casa,titulo:t.titulo,desc:t.desc,modelo:t.modelo,indicadores:[...t.indicadores],gas:Object.assign({},t.gas),tareas:t.tareas.map(x=>({...x}))})}

function tSesiones(){const obs=MED.objetivosActivos(R()).filter(o=>o.estado!=='archivado');const ses=regs('sesion').sort((a,b)=>a.fecha<b.fecha?1:-1);
  S.gasDraft=S.gasDraft||{};
  let h=`<div class="card"><h3>Registrar sesión</h3><label class="fld"><span class="lbl">Fecha</span><input type="date" id="s-fecha" value="${hoy()}"></label>
  ${obs.length?`<span class="lbl">Nivel de logro de cada objetivo (GAS)</span>`+obs.map(o=>`<div class="gasrow"><span>${e(o.titulo)}</span><div class="seg s5">${['-2','-1','0','1','2'].map(k=>`<button class="sg ${S.gasDraft[o.id]===k?'on':''}" data-act="gas-op" data-o="${o.id}" data-v="${k}" title="${e(o.gas?.[k]||GASTXT[k])}">${k>0?'+'+k:k}</button>`).join('')}</div>${S.gasDraft[o.id]!=null?`<p class="note">${e(o.gas?.[S.gasDraft[o.id]]||GASTXT[S.gasDraft[o.id]])}</p>`:''}</div>`).join(''):'<p class="note">Agrega objetivos para poder marcar su avance.</p>'}
  <label class="fld"><span class="lbl">Indicaciones y tareas para la pareja (las verán en "Hoy")</span><textarea id="s-ind" rows="3"></textarea></label>
  <label class="fld"><span class="lbl">Nota clínica (privada)</span><textarea id="s-nota" rows="3"></textarea></label>
  <button class="btn pri" data-act="guardar-sesion">Guardar sesión</button><p class="note">Después de guardar, cada uno recibe 4 preguntas breves para evaluar la sesión.</p></div>
  <div class="card"><h3>Mensaje a la pareja</h3><textarea id="m-txt" rows="2" placeholder="Recordatorio, ánimo o una tarea extra"></textarea><button class="btn" data-act="enviar-msg">Enviar</button></div>`;
  if(ses.length)h+=`<div class="card"><h3>Sesiones anteriores</h3>${ses.map((s,i)=>{const n=regs('notaSesion').find(x=>x.ref===s.id);const t=MED.gasT(obs.filter(o=>s.gas?.[o.id]!=null).map(o=>({x:+s.gas[o.id],w:o.peso||1})));
    return`<div class="nota"><span class="lbl">Sesión ${ses.length-i} · ${UIX.fCorta(s.fecha)}${t!=null?` · GAS ${t}`:''}</span>${s.indicaciones?`<p>${e(s.indicaciones)}</p>`:''}${n?`<p class="muted">🔒 ${e(n.texto)}</p>`:''}</div>`}).join('')}</div>`;
  return h}
function guardarSesion(){const f=$('#s-fecha').value||hoy();const id=uid('se');const gas={};Object.entries(S.gasDraft||{}).forEach(([k,v])=>{if(v!=null)gas[k]=+v});
  Datos.guardar(C(),{id,tipo:'sesion',fecha:f,gas,indicaciones:$('#s-ind').value.trim()},true);
  const nt=$('#s-nota').value.trim();if(nt)Datos.guardar(C(),{id:'ns-'+id,tipo:'notaSesion',ref:id,fecha:f,texto:nt},true);
  S.gasDraft={};Datos.sync(C()).catch(()=>{});toast('Sesión guardada');render()}

function tDatos(){const p=Datos.P(C());const pa=pareja();const demo=Datos.cfg.modo==='demo';
  return`<div class="card"><h3>Acceso de la pareja</h3><p class="note">Entrega estos datos en sesión. Cada uno instala Terapia2 en su teléfono, toca "Unirme a mi terapia", acepta el consentimiento informado y escribe:</p>
  <div class="cred"><div><span class="lbl">Código</span><b>${e(p.codigo)}</b></div><div><span class="lbl">Clave de la pareja</span><b>${e(p.clavePareja||'(no guardada en este teléfono)')}</b></div></div>
  <button class="btn" data-act="compartir-cred">Compartir instrucciones</button>
  <div id="vinc" class="note">${demo?'':'Revisando qué teléfonos están vinculados…'}</div>
  <div class="row"><button class="btn sm ghost" data-act="liberar" data-r="a">Liberar lugar de ${e(nom('a'))}</button><button class="btn sm ghost" data-act="liberar" data-r="b">Liberar lugar de ${e(nom('b'))}</button></div>
  <p class="note">Liberar sirve si alguien cambió de teléfono: el teléfono anterior deja de recibir datos.</p></div>
  <div class="card"><h3>Datos de la pareja</h3><div class="g2"><label class="fld"><span class="lbl">Nombre de él</span><input id="p-a" value="${e(nom('a'))}"></label><label class="fld"><span class="lbl">Nombre de ella</span><input id="p-b" value="${e(nom('b'))}"></label></div>
  <label class="chk"><input type="checkbox" id="p-ce" ${pa.compartirEval?'checked':''}><span>Cada uno puede ver cómo lo evalúa su pareja en los objetivos</span></label>
  <label class="chk"><input type="checkbox" id="p-cc" ${pa.compartirCSI?'checked':''}><span>Cada uno puede ver la satisfacción semanal del otro</span></label>
  <label class="fld"><span class="lbl">Hora sugerida para el recordatorio diario</span><input type="time" id="p-rec" value="${e(pa.recordatorio||'20:30')}"></label>
  <label class="fld"><span class="lbl">N.º de ficha en el gestor clínico (opcional)</span><input id="p-ficha" value="${e(pa.fichaGestor||'')}" maxlength="60" autocomplete="off"></label>
  <button class="btn pri" data-act="guardar-pareja">Guardar</button>
  <p class="note">Mostrar a cada uno cómo lo ve el otro favorece la conversación, pero si hay mucha hostilidad conviene desactivarlo por un tiempo.</p></div>
  <div class="card"><h3>Ficha</h3><button class="btn ghost danger" data-act="quitar-pareja">Quitar esta pareja de este teléfono</button><p class="note">Los datos siguen en el servidor; puedes recuperarla restaurando un respaldo.</p>
  ${demo?'':`<button class="btn ghost danger" data-act="eliminar-pareja">Eliminar pareja del servidor</button><p class="note">Para el término del tratamiento o una solicitud de eliminación, una vez cumplido el plazo de conservación de la ficha clínica.</p>`}</div>`}
async function revisarVinculos(){const el=$('#vinc');if(!el)return;try{const r=await Datos.estado(C());const cs=r.consentimientos||[],sol=(r.solicitudes||[]).filter(x=>!x.resuelta);const cons=k=>{const c=cs.filter(x=>x.rol===k).pop();return c?`consentimiento ${UIX.fCorta(MED.fecha(c.fecha))} (v${e(c.version)})`:'sin consentimiento registrado'};
  el.innerHTML=`Vinculados: ${e(nom('a'))} ${r.vinculados.a?'sí':'aún no'} · ${e(nom('b'))} ${r.vinculados.b?'sí':'aún no'}<br>${e(nom('a'))}: ${cons('a')} · ${e(nom('b'))}: ${cons('b')}`+
   (sol.length?`<div class="al n3"><b>Solicitud de eliminación de datos</b>${sol.map(x=>`<span>${e(nom(x.rol))} · ${UIX.fCorta(MED.fecha(x.fecha))}${x.motivo?': '+e(x.motivo):''}</span>`).join('')}<span>Responde dentro de 30 días. Conserva lo que exige la ficha clínica y elimina el resto.</span><button class="btn sm" data-act="resolver-solicitudes">Marcar como atendida</button></div>`:'')}catch(x){el.textContent='No se pudo revisar ('+x.message+')'}}

function tBiblioteca(){const f=S.filtroBib;let h=`<div class="sh"><h2>Biblioteca</h2><p>Objetivos de tratamiento basados en modelos de terapia de pareja con evidencia. Al agregarlos a una pareja se pueden adaptar.</p></div>
  <div class="subnav">${[['sug','Todos'],['princ','Principios'],...Object.entries(EVID.MODELOS).map(([k,m])=>[k,m.corto])].map(([k,t])=>`<button class="st" data-act="bib" data-f="${k}" ${f===k?'aria-current="page"':''}>${t}</button>`).join('')}</div>`;
  if(f==='princ')return h+`<div class="card"><p class="note">Adaptados de Gottman, J. S., y Gottman, J. M. (2015). <i>10 principles for doing effective couples therapy</i>. Norton. Resumen con palabras propias.</p><ol class="princ">${EVID.PRINCIPIOS.map(x=>`<li><b>${e(x.t)}</b><p class="note">${e(x.app)}</p></li>`).join('')}</ol></div>`;
  if(f!=='sug'){const m=EVID.MODELOS[f];h+=`<div class="card soft"><b>${e(m.nombre)}</b><span class="lbl">${e(m.autores)}</span><p>${e(m.idea)}</p><p class="note"><b>Evidencia:</b> ${e(m.evidencia)}</p></div>`}
  const lista=EVID.OBJETIVOS.filter(o=>f==='sug'||o.modelo===f);const nivel=o=>o.casa?' · '+EVID.CASA.find(c=>c.id===o.casa).n:'';const tiene=new Set(C()?MED.objetivosActivos(R()).map(o=>o.base):[]);
  h+=`<div class="card">${lista.map(o=>`<div class="lib"><div><span class="mtag">${e(EVID.MODELOS[o.modelo].corto)}</span> <b>${e(o.titulo)}</b><p class="note">${e(o.desc)}</p><span class="lbl">Áreas: ${o.areas.map(a=>EVID.AREAS[a]).join(', ')}${e(nivel(o))}</span></div>${C()?(tiene.has(o.id)?'<span class="badge ok">Asignado</span>':`<button class="btn sm" data-act="agregar-obj" data-id="${o.id}">Agregar a ${e(nom('a'))} y ${e(nom('b'))}</button>`):''}</div>`).join('')}</div>
  <button class="btn ghost" data-act="fundamentos">Fundamentos y referencias</button>`;return h}

/* ===================== Más / Ajustes ===================== */
function pMas(){const t=rol()==='t',demo=Datos.cfg.modo==='demo';let h=`<div class="sh"><h2>${t?'Ajustes':'Más'}</h2></div>`;
  if(!t){const pa=pareja();const rec=Datos.ls.get('recordatorio',{on:false,hora:pa.recordatorio||'20:30'});
    h+=`<div class="card"><h3>Recordatorio diario</h3><p class="note">Un aviso discreto para registrar tu día. No muestra contenido de la terapia.</p>
    <div class="row"><input type="time" id="rec-hora" value="${e(rec.hora)}"><label class="chk"><input type="checkbox" id="rec-on" ${rec.on?'checked':''}><span>Activado</span></label></div><button class="btn" data-act="guardar-rec">Guardar recordatorio</button></div>
    <div class="card list"><h3>Apoyo</h3>${fila('recursos','ayuda','Ayuda inmediata','Líneas de ayuda si tú u otra persona está en riesgo')}${fila('abrir-seguridad','escudo','Preguntas confidenciales','Solo las ve tu terapeuta')}</div>`}
  h+=`<div class="card list"><h3>Privacidad y tus datos</h3><p class="note">Tienes derecho a acceder, corregir, llevarte o pedir que se eliminen tus datos.</p>
    ${fila('legal','candado','Política de privacidad','','data-doc="PRIVACIDAD"')}${fila('legal','firmado','Consentimiento informado','','data-doc="CONSENTIMIENTO"')}${fila('legal','documento','Términos de uso','','data-doc="TERMINOS"')}
    ${C()?fila('mis-datos','descarga','Descargar mis datos','Una copia de tus registros')+(t?'':fila('solicitar-eliminacion','papelera','Solicitar eliminación de mis datos','Tu terapeuta responderá en máximo 30 días','','danger')):''}</div>`;
  h+=`<div class="card"><h3>Bloqueo</h3><p class="note">Pide un PIN al abrir la app, para que nadie más pueda verla en tu teléfono.</p>${Datos.ls.get('pin',null)?'<button class="btn" data-act="pin-quitar">Quitar PIN</button>':'<button class="btn" data-act="pin-poner">Poner PIN</button>'}</div>`;
  if(t&&!demo)h+=`<div class="card"><h3>Servidor</h3><label class="fld"><span class="lbl">Dirección del servidor</span><input id="srvurl" type="url" autocomplete="off" value="${e(Datos.url())}"></label><p class="note">Normalmente no hay que cambiarla. En uso: ${e(Datos.url())}</p><div class="row"><button class="btn" data-act="srv-guardar">Guardar</button><button class="btn ghost" data-act="srv-probar">Probar</button><button class="btn ghost" data-act="srv-defecto">Usar dirección predeterminada</button></div>
    <label class="fld"><span class="lbl">Clave profesional (si tu servidor la pide para crear parejas)</span><input id="clavepro" type="password" autocomplete="off" value="${e(Datos.cfg.claveProfesional||'')}"></label><button class="btn" data-act="clave-pro">Guardar clave profesional</button></div>
    <div class="card"><h3>Respaldo</h3><p class="note">Guarda las claves de tus parejas para recuperarlas en otro teléfono. Contiene datos clínicos: guárdalo en un lugar seguro.</p><div class="row"><button class="btn" data-act="respaldo">Exportar respaldo</button><label class="btn ghost">Importar<input type="file" accept=".json,application/json" id="imp" hidden></label></div></div>`;
  if(esPro())h+=`<div class="card"><h3>Acceso profesional</h3><p class="note">Este teléfono muestra las opciones para terapeutas. Si lo vas a usar como paciente o lo entregas a otra persona, quítalo.</p><button class="btn ghost" data-act="pro-quitar">Quitar acceso profesional</button></div>`;
  h+=Upd.cardHTML();
  h+=`<div class="card list">${fila('fundamentos','biblioteca','Fundamentos','Modelos, instrumentos y referencias científicas')}${fila('legal','documento','Licencias de terceros','Tipografías, íconos y software usados','data-doc="LICENCIAS"')}</div>`;
  if(demo)h+=`<div class="card"><button class="btn" data-act="demo-salir">Salir de la demostración</button></div>`;
  else h+=`<div class="card"><h3>Este teléfono</h3>${t?'':`<p class="note">Vinculado a la pareja ${e(C()||'')}.</p>`}<button class="btn ghost danger" data-act="borrar-todo">Desvincular y borrar los datos de este teléfono</button></div>`;
  h+=`<p class="note center">Terapia2 ${window.VINCULO_WEB?'v'+window.VINCULO_WEB:''} · herramienta de apoyo a la terapia; por sí sola no constituye un tratamiento.</p>`;
  return h}

function fundamentos(){const M=EVID.MODELOS,REF=EVID.REFERENCIAS;
  modal(`<h3>Fundamentos</h3>
  <p class="aviso">${ico('info')}<span>${e(LEGAL.AVISO)}</span></p>
  <p>La terapia de pareja tiene efectos grandes sobre la satisfacción: en un metaanálisis de 58 estudios (2.092 parejas) las parejas tratadas mejoraron mucho más que las que esperaban sin tratamiento, y las ganancias se mantuvieron en el seguimiento (Roddy et al., 2020).</p>
  <p>Terapia2 combina tres elementos con respaldo:</p>
  <ol><li><b>Objetivos de modelos con evidencia</b>: ${Object.values(M).filter(m=>m.corto!=='Común').map(m=>m.corto).join(', ')} y principios comunes.</li>
  <li><b>Escala de logro de metas (GAS)</b>: cada objetivo se describe en 5 niveles observables, de −2 a +2, y se combina en un puntaje T donde 50 es lo esperado (Kiresuk y Sherman, 1968).</li>
  <li><b>Monitoreo y retroalimentación</b>: medir el avance y la alianza en cada sesión y devolverlo a la pareja y al terapeuta. En un ensayo con 205 parejas, quienes recibieron retroalimentación lograron casi cuatro veces más cambio clínicamente significativo y menos separaciones (Anker, Duncan y Sparks, 2009). La satisfacción se registra cada semana con un cuestionario breve propio de Vínculo.</li></ol>
  <h3>Principios de la terapia de pareja efectiva</h3><p class="note">Adaptados de Gottman y Gottman (2015). Resumen con palabras propias y cómo los aplica Terapia2.</p>
  <ol class="refs princ">${EVID.PRINCIPIOS.map(x=>`<li><b>${e(x.t)}.</b> ${e(x.app)}</li>`).join('')}</ol>
  <p><b>Seguridad.</b> Antes y durante la terapia conjunta se pregunta por separado y en forma confidencial por violencia y control; ante violencia con control coercitivo la terapia conjunta no está indicada.</p>
  ${Object.values(M).map(m=>`<details><summary><b>${e(m.nombre)}</b></summary><p>${e(m.idea)}</p><p class="note">${e(m.evidencia)}</p></details>`).join('')}
  <h3>Referencias</h3><ol class="refs">${Object.values(REF).map(r=>`<li>${e(r)}</li>`).join('')}</ol>
  <p class="note">Las preguntas de satisfacción semanal, de la Casa y de la evaluación de la sesión son de redacción propia y no están validadas: orientan, pero no reemplazan los cuestionarios oficiales.</p>
  <p class="note"><b>Autoría y marcas.</b> Los textos de Terapia2 son de redacción propia, basados en la literatura citada; no reproducen libros ni materiales de terceros. Terapia2 no está afiliada ni respaldada por los autores ni por las instituciones citadas (como The Gottman Institute o ICEEFT). Los nombres de métodos y modelos pertenecen a sus titulares y se usan solo para indicar el origen de las ideas.</p>
  <div class="row end"><button class="btn pri" data-act="cerrar">Cerrar</button></div>`)}

/* ===================== Informe ===================== */
function informe(){const Rr=R(),f=Rr.formulacion||{},pa=pareja();const obs=MED.objetivosActivos(Rr);const c=MED.serieCSI(Rr),g=MED.serieGAS(Rr);
  const fila=(o)=>{const s=MED.serieObjetivo(Rr,o.id);const u=s[s.length-1]||{};const ses=MED.ultimaSesion(Rr);return`<tr><td>${e(o.titulo)}<br><small>${e(EVID.MODELOS[o.modelo]?.corto||'')} · ${e(o.estado||'activo')}</small></td><td>${ses?.gas?.[o.id]??'—'}</td><td>${u.a_self??'—'} / ${u.a_por_b??'—'}</td><td>${u.b_self??'—'} / ${u.b_por_a??'—'}</td></tr>`};
  const html=`<!doctype html><html lang="es"><meta charset="utf-8"><title>Informe de avance — ${e(nom('a'))} y ${e(nom('b'))}</title>
<style>body{font:14px/1.5 system-ui,sans-serif;max-width:760px;margin:24px auto;padding:0 16px;color:#1d1d1f}h1{font-size:22px}h2{font-size:16px;margin-top:22px;border-bottom:1px solid #ccc}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:6px;text-align:left;vertical-align:top}small{color:#666}.al{background:#fbeee8;padding:6px 8px;margin:4px 0;border-radius:6px}</style>
<h1>Informe de avance — terapia de pareja</h1><p>${e(nom('a'))} y ${e(nom('b'))} · inicio ${e(pa.inicio||'')} · emitido ${e(hoy())}</p>
<h2>Motivo y diagnóstico</h2><p><b>Motivo:</b> ${e(f.motivo||'—')}</p><p><b>Diagnóstico / hipótesis:</b> ${e(f.diagnostico||'—')}</p><p><b>Modelo:</b> ${e(EVID.MODELOS[f.modelo]?.nombre||'—')}</p><p><b>Áreas:</b> ${(f.areas||[]).map(a=>EVID.AREAS[a]).join(', ')||'—'}</p>
<h2>Objetivos</h2><table><tr><th>Objetivo</th><th>GAS última sesión</th><th>${e(nom('a'))}: auto / por pareja (última semana)</th><th>${e(nom('b'))}: auto / por pareja</th></tr>${obs.map(fila).join('')}</table>
<p>Puntaje GAS (T): ${g.map(x=>`${x.fecha}: ${x.t}`).join(' · ')||'—'}</p>
<h2>Satisfacción semanal (0–20, cuestionario propio)</h2><p>${e(nom('a'))}: ${c.a.map(x=>`${x.fecha}: ${x.total}`).join(' · ')||'—'}</p><p>${e(nom('b'))}: ${c.b.map(x=>`${x.fecha}: ${x.total}`).join(' · ')||'—'}</p>
<h2>Adherencia (últimos 7 días)</h2><p>${e(nom('a'))}: ${MED.adherencia(Rr,'a').dias}/7 · ${e(nom('b'))}: ${MED.adherencia(Rr,'b').dias}/7</p>
<h2>Alertas</h2>${MED.alertas(Rr).map(a=>`<div class="al">${e(a.txt)}</div>`).join('')||'<p>Sin alertas.</p>'}
<p><small>Generado con Terapia2. Documento clínico confidencial. Referencias: Kiresuk y Sherman (1968); Anker, Duncan y Sparks (2009).</small></p></html>`;
  UIX.compartirArchivo(`informe-${(nom('a')+'-'+nom('b')).toLowerCase().replace(/[^a-z0-9]+/g,'-')}-${hoy()}.html`,html)}

/* ===================== PIN ===================== */
const hashPin=p=>{let h=5381;for(const c of 'vinculo:'+p)h=Math.imul(h,33)^c.charCodeAt(0);return(h>>>0).toString(36)};
function pantallaPin(){return`<div class="lock"><div class="mark" aria-hidden="true"><span></span><span></span></div><h2>Terapia<span class="dos">2</span></h2><input id="pin" type="password" inputmode="numeric" maxlength="8" placeholder="PIN" autocomplete="off"><button class="btn pri" data-act="pin-entrar">Entrar</button></div>`}

/* ===================== Acciones ===================== */
async function accion(a,b){
  try{switch(a){
    case 'tab':S.tab=b.dataset.t;if(S.tab==='parejas')S.sub='resumen';break;
    case 'sub':S.sub=b.dataset.s;S.tab='pareja';break;
    case 'bib':S.filtroBib=b.dataset.f;break;
    case 'modo':if(b.dataset.m==='demo'){await sembrarDemo();return}Datos.elegirModo(b.dataset.m||null);break;
    case 'set-rol':if(b.dataset.r==='t'){if(!Datos.url()){toast('Primero guarda la dirección del servidor');return}Datos.setRol('t')}else if(b.dataset.r==='p'){if(!Datos.url()){toast('Primero guarda la dirección del servidor');return}Datos.setRol('p')}else Datos.setRol(null);break;
    case 'j-rol':S.jrol=b.dataset.r;b.parentNode.querySelectorAll('.sg').forEach(x=>x.classList.toggle('on',x===b));return;
    case 'unirse':{const cod=$('#j-cod').value,cla=$('#j-cla').value;if(!S.jrol){toast('Elige si eres él o ella');return}
      if(!$('#j-cons')?.checked){toast('Para unirte, lee y acepta el consentimiento informado');$('#j-cons')?.focus();return}
      b.disabled=true;b.textContent='Conectando…';
      try{await Datos.unirse(cod,cla,S.jrol,{version:LEGAL.VERSION})}catch(x){b.disabled=false;b.textContent='Unirme';toast(x.message,5000);return}
      S.tab='hoy';toast('¡Listo! Ya estás vinculado/a.');break}
    case 'srv-guardar':Datos.setServidor($('#srvurl').value);toast($('#srvurl').value.trim()?'Dirección guardada':'Se usará la dirección predeterminada');break;
    case 'srv-defecto':Datos.setServidor('');toast('Se usará la dirección predeterminada');break;
    case 'srv-probar':{const u=$('#srvurl').value.trim()||Datos.url();if(!Datos.urlValida(u)){toast('Dirección no válida: debe empezar con https://',5000);return}
      try{const r=await fetch(u,{cache:'no-store'}).then(x=>x.json());toast(r.ok&&r.servicio==='vinculo'?'El servidor responde correctamente':'Respuesta inesperada del servidor',5000)}catch(x){toast('No se pudo conectar con '+u+'. Revisa la dirección o tu internet.',6000)}return}
    case 'sync':{const r=await Datos.sync(C());toast('Sincronizado');break}
    case 'guardar-hoy':guardarHoy();return;
    case 'abrir-csi':abrirCSI();return;
    case 'csi-op':{S.csi[+b.dataset.i]=+b.dataset.v;b.parentNode.querySelectorAll('.op').forEach(x=>x.classList.toggle('on',x===b));return}
    case 'csi-guardar':{if(S.csi.some(v=>v==null)){toast('Responde las 4 preguntas');return}Datos.guardar(C(),{id:`csi-${rol()}-${hoy()}`,tipo:'csi',fecha:hoy(),items:S.csi,total:MED.csiTotal(S.csi)});cerrarModal();toast('Gracias. Satisfacción registrada.');break}
    case 'abrir-seguridad':abrirSeguridad();return;
    case 'seg-op':{S.seg[b.dataset.k]=b.dataset.v==='1';b.parentNode.querySelectorAll('.sg').forEach(x=>x.classList.toggle('on',x===b));return}
    case 'seg-guardar':{if(Object.keys(S.seg).length<EVID.SEGURIDAD.length){toast('Responde todas las preguntas');return}
      Datos.guardar(C(),{id:`sg-${rol()}-${hoy()}`,tipo:'seguridad',fecha:hoy(),resp:S.seg});cerrarModal();
      if(Object.values(S.seg).some(Boolean)){mostrarRecursos();return}toast('Gracias. Respuestas enviadas solo a tu terapeuta.');break}
    case 'recursos':mostrarRecursos();return;
    case 'abrir-inicial':abrirInicial();return;
    case 'ini-op':{S.ini[b.dataset.k]=+b.dataset.v;b.parentNode.querySelectorAll('.sg').forEach(x=>x.classList.toggle('on',x===b));return}
    case 'ini-casa':{S.iniCasa[b.dataset.k]=+b.dataset.v;b.parentNode.querySelectorAll('.sg').forEach(x=>x.classList.toggle('on',x===b));return}
    case 'ini-guardar':if(Object.keys(S.iniCasa).length<EVID.CASA.length){toast('Responde las preguntas de "Nuestra relación hoy"');return}
      Datos.guardar(C(),{id:`in-${rol()}`,tipo:'inicial',fecha:hoy(),areas:S.ini,casa:S.iniCasa,meta:$('#ini-meta').value.trim()});cerrarModal();toast('Evaluación enviada a tu terapeuta');break;
    case 'abrir-alianza':abrirAlianza(b.dataset.s);return;
    case 'ali-guardar':{if(Object.keys(S.ali.resp).length<EVID.ALIANZA.length){toast('Mueve las 4 barras');return}
      Datos.guardar(C(),{id:`al-${rol()}-${S.ali.sesion}`,tipo:'alianza',sesion:S.ali.sesion,fecha:hoy(),resp:S.ali.resp,texto:$('#ali-txt').value.trim()});cerrarModal();toast('Gracias por tu opinión');break}
    case 'cerrar':cerrarModal();return;
    case 'pausa':abrirPausa();return;
    case 'pausa-ok':{const m=+b.dataset.m;const ahora=Date.now();const vuelve=ahora+m*60000;Datos.guardar(C(),{id:uid('pa'),tipo:'pausa',fecha:hoy(),inicio:ahora,vuelve,minutos:m});
      Recordatorio.avisoPausa(vuelve).catch(()=>{});cerrarModal();render();respirar();return}
    case 'pausa-fin':{const p=R()[b.dataset.id];if(p)Datos.guardar(C(),Object.assign({},p,{terminada:true}));toast('Bien. Cuando ambos estén en calma, retomen con inicio suave.');break}
    case 'respirar':respirar();return;
    case 'ej':abrirEjercicio(b.dataset.id);return;
    case 'otra-preg':{const L=EVID.PREGUNTAS_MAPAS;const el=$('#preg');let q;do{q=L[Math.floor(Math.random()*L.length)]}while(L.length>1&&q===el.textContent);el.textContent=q;return}
    case 'inc-s':{const v=b.dataset.v;const L=S.inc.sentimientos;const i=L.indexOf(v);if(i>=0)L.splice(i,1);else L.push(v);b.classList.toggle('on');return}
    case 'inc-guardar':{const v=id=>$(id).value.trim();if(!S.inc.sentimientos.length){toast('Elige al menos un sentimiento');return}
      Datos.guardar(C(),{id:uid('ic'),tipo:'incidente',fecha:hoy(),titulo:v('#inc-tit'),sentimientos:S.inc.sentimientos,realidad:v('#inc-real'),valido:v('#inc-val'),detonantes:v('#inc-det'),responsabilidad:v('#inc-resp'),plan:v('#inc-plan'),privado:!$('#inc-comp').checked});
      cerrarModal();toast('Guardado. Ahora conversen sus versiones con calma.');S.tab='ejercicios';break}
    case 'ji':{const ji=S.hoy._ji;const k=b.dataset.k,v=b.dataset.v;
      if(k==='n'){ji.j=[];ji.ninguno=!ji.ninguno}else{const L=ji[k];const i=L.indexOf(v);if(i>=0)L.splice(i,1);else L.push(v);if(k==='j')ji.ninguno=false}
      const card=b.closest('.card');card.querySelectorAll('[data-act="ji"]').forEach(x=>{const on=x.dataset.k==='n'?(ji.ninguno&&!ji.j.length):ji[x.dataset.k].includes(x.dataset.v);x.classList.toggle('on',on);x.classList.toggle('warnop',on&&x.dataset.k==='j')});return}
    case 'fundamentos':fundamentos();return;
    case 'legal':modal(`<div class="legal">${LEGAL[b.dataset.doc]||''}</div><button class="btn" data-act="cerrar">Cerrar</button>`);return;
    case 'mis-datos':{const r=rol(),todo=Object.values(R()).filter(x=>x&&!x.borrado&&(x.autor===r||r==='t'));
      await UIX.compartirArchivo(`vinculo-mis-datos-${hoy()}.json`,JSON.stringify({app:'Terapia2',exportado:new Date().toISOString(),persona:nom(r),pareja:pareja().nombres,registros:todo},null,2),'application/json');return}
    case 'solicitar-eliminacion':modal(`<h3>Solicitar eliminación de mis datos</h3><p class="note">Tu terapeuta recibirá la solicitud. Lo que forma parte de tu ficha clínica se conserva el plazo que exige la ley (Ley 20.584) y se bloquea mientras tanto; lo demás se elimina. Te responderán en un máximo de 30 días.</p>
      <label class="fld"><span class="lbl">Motivo (opcional)</span><textarea id="el-mot" rows="2" maxlength="500"></textarea></label>
      <div class="row end"><button class="btn ghost" data-act="cerrar">Cancelar</button><button class="btn pri" data-act="solicitar-eliminacion-ok">Enviar solicitud</button></div>`);return;
    case 'solicitar-eliminacion-ok':if(Datos.cfg.modo==='demo'){cerrarModal();toast('En la demostración no se envían solicitudes');return}
      await Datos.pedir('solicitarEliminacion',C(),{motivo:$('#el-mot').value.trim()});cerrarModal();toast('Solicitud enviada a tu terapeuta');return;
    case 'resolver-solicitudes':await Datos.pedir('resolverSolicitudes',C());toast('Solicitudes marcadas como atendidas');$('#vinc')&&delete $('#vinc').dataset.ok;break;
    case 'eliminar-pareja':modal(`<h3>Eliminar pareja del servidor</h3><p class="note">Se borran del servidor todos los registros de ${e(nom('a'))} y ${e(nom('b'))}, y sus teléfonos dejan de sincronizar. No se puede deshacer. Antes, exporta el informe de avance si debe quedar en la ficha clínica.</p>
      <label class="fld"><span class="lbl">Escribe el código ${e(C())} para confirmar</span><input id="el-cod" autocapitalize="characters" autocomplete="off"></label>
      <div class="row end"><button class="btn ghost" data-act="cerrar">Cancelar</button><button class="btn danger" data-act="eliminar-pareja-ok">Eliminar definitivamente</button></div>`);return;
    case 'eliminar-pareja-ok':{const cod=C();await Datos.pedir('eliminar',cod,{confirmar:$('#el-cod').value});cerrarModal();Datos.quitarPareja(cod);S.tab='parejas';toast('Pareja eliminada del servidor');break}
    case 'clave-pro':Datos.setClaveProfesional($('#clavepro').value);toast('Clave profesional guardada');break;
    case 'nueva-pareja':modal(`<h3>Nueva pareja</h3><div class="g2"><label class="fld"><span class="lbl">Nombre de él</span><input id="n-a"></label><label class="fld"><span class="lbl">Nombre de ella</span><input id="n-b"></label></div><p class="note">Usa nombres de pila o iniciales.</p><div class="row end"><button class="btn ghost" data-act="cerrar">Cancelar</button><button class="btn pri" data-act="crear-pareja">Crear</button></div>`);return;
    case 'crear-pareja':{b.disabled=true;b.textContent='Creando…';const r=await Datos.crearPareja({a:$('#n-a').value.trim()||'Él',b:$('#n-b').value.trim()||'Ella'});cerrarModal();S.tab='pareja';S.sub='datos';render();
      modal(`<h3>Pareja creada</h3><p>Entrega estos datos a la pareja:</p><div class="cred"><div><span class="lbl">Código</span><b>${e(r.codigo)}</b></div><div><span class="lbl">Clave</span><b>${e(r.clavePareja)}</b></div></div><p class="note">Siguiente paso: completa el diagnóstico y agrega objetivos.</p><div class="row end"><button class="btn pri" data-act="cerrar">Listo</button></div>`);return}
    case 'abrir-pareja':S.casaEv=null;Datos.activar(b.dataset.c);S.tab='pareja';S.sub='resumen';Datos.sync(b.dataset.c).catch(()=>{});break;
    case 'guardar-diag':{const v=id=>$(id).value.trim();const prev=R().formulacion||{};
      Datos.guardar(C(),Object.assign({},prev,{id:'formulacion',tipo:'formulacion',motivo:v('#f-motivo'),diagnostico:v('#f-diag'),modelo:v('#f-modelo'),areas:[...document.querySelectorAll('[data-area]:checked')].map(x=>x.dataset.area),
        deep:Object.fromEntries([...document.querySelectorAll('[data-deep]')].map(x=>[x.dataset.deep,x.value.trim()])),ciclo:Object.assign(Object.fromEntries([...document.querySelectorAll('[data-ciclo]')].map(x=>[x.dataset.ciclo,x.value])),{desc:v('#f-ciclo')}),fortalezas:v('#f-fort'),riesgos:v('#f-riesgo')}));toast('Diagnóstico guardado');break}
    case 'casa-ev':{const k=b.dataset.k,v=+b.dataset.v;S.casaEv[k]=S.casaEv[k]===v?undefined:v;b.parentNode.querySelectorAll('.sg').forEach(x=>x.classList.toggle('on',S.casaEv[k]===+x.dataset.v));return}
    case 'guardar-eval':{const prev=R().formulacion||{};const casa={};Object.entries(S.casaEv||{}).forEach(([k,v])=>{if(v!=null)casa[k]=v});
      Datos.guardar(C(),Object.assign({},prev,{id:'formulacion',tipo:'formulacion',casa,banderas:Object.fromEntries([...document.querySelectorAll('[data-band]')].map(x=>[x.dataset.band,x.checked])),
        entrevistas:Object.fromEntries([...document.querySelectorAll('[data-ent]')].map(x=>[x.dataset.ent,x.checked])),mundo:Object.fromEntries([...document.querySelectorAll('[data-mundo]')].map(x=>[x.dataset.mundo,x.value.trim()]))}));
      toast('Evaluación guardada');break}
    case 'agregar-obj':agregarDeBiblioteca(b.dataset.id);return;
    case 'obj-nuevo':editarObjetivo({});return;
    case 'obj-editar':editarObjetivo(JSON.parse(JSON.stringify(R()[b.dataset.id])));return;
    case 'obj-guardar':guardarObjetivo();return;
    case 'obj-borrar':if(await confirmar('¿Eliminar este objetivo? Sus registros quedan guardados.','Eliminar')){Datos.borrar(C(),S.edit.id)}break;
    case 'gas-op':S.gasDraft[b.dataset.o]=S.gasDraft[b.dataset.o]===b.dataset.v?null:b.dataset.v;break;
    case 'guardar-sesion':guardarSesion();return;
    case 'enviar-msg':{const t=$('#m-txt').value.trim();if(!t)return;Datos.guardar(C(),{id:uid('ms'),tipo:'mensaje',fecha:hoy(),texto:t});toast('Mensaje enviado');break}
    case 'revisar':Datos.guardar(C(),{id:'rv-'+b.dataset.id,tipo:'revision',ref:b.dataset.id,fecha:hoy()});break;
    case 'ver-seg':{const s=regs('seguridad').filter(x=>x.autor===b.dataset.r).sort((x,y)=>x.fecha<y.fecha?1:-1)[0];
      modal(`<h3>Respuestas de ${e(nom(b.dataset.r))} · ${UIX.fCorta(s?.fecha)}</h3><ul>${EVID.SEGURIDAD.map(q=>`<li>${e(q.p)} <b>${s?.resp?.[q.id]?'Sí':'No'}</b></li>`).join('')}</ul><p class="note">Recomendación: entrevista individual con cada miembro antes de la próxima sesión conjunta y evaluación de riesgo. Si hay violencia con control coercitivo, suspender la terapia conjunta y derivar.</p><div class="row end"><button class="btn pri" data-act="cerrar">Cerrar</button></div>`);return}
    case 'guardar-pareja':{const p=pareja();Datos.guardar(C(),Object.assign({},p,{id:'pareja',tipo:'pareja',nombres:{a:$('#p-a').value.trim()||'Él',b:$('#p-b').value.trim()||'Ella'},fichaGestor:($('#p-ficha')?.value||'').trim().slice(0,60),compartirEval:$('#p-ce').checked,compartirCSI:$('#p-cc').checked,recordatorio:$('#p-rec').value}));toast('Guardado');break}
    case 'compartir-cred':{const p=Datos.P(C());UIX.compartirTexto(`Terapia2 — terapia de pareja\n1. Instala la app Terapia2 en tu teléfono.\n2. Elige "Soy parte de una pareja".\n3. Código: ${p.codigo}\n4. Clave: ${p.clavePareja||''}\n5. Elige si eres él o ella.\nCada uno usa su propio teléfono.`);return}
    case 'liberar':if(await confirmar(`¿Liberar el lugar de ${e(nom(b.dataset.r))}? Su teléfono actual dejará de estar vinculado.`,'Liberar')){await Datos.liberar(C(),b.dataset.r);toast('Lugar liberado')}break;
    case 'quitar-pareja':if(await confirmar('¿Quitar esta pareja de este teléfono? Los datos siguen en el servidor.','Quitar')){Datos.quitarPareja(C());S.tab='parejas'}break;
    case 'informe':informe();return;
    case 'guardar-rec':{const r={on:$('#rec-on').checked,hora:$('#rec-hora').value||'20:30'};Datos.ls.set('recordatorio',r);const ok=await Recordatorio.programar(r);toast(r.on?(ok?'Recordatorio activado a las '+r.hora:'Activa las notificaciones de Terapia2 en los ajustes del teléfono'):'Recordatorio desactivado');return}
    case 'pin-poner':modal(`<h3>Poner PIN</h3><input id="pin1" type="password" inputmode="numeric" maxlength="8" placeholder="PIN de 4 a 8 números"><div class="row end"><button class="btn ghost" data-act="cerrar">Cancelar</button><button class="btn pri" data-act="pin-ok">Guardar</button></div>`);return;
    case 'pin-ok':{const p=$('#pin1').value;if(!/^\d{4,8}$/.test(p)){toast('Usa de 4 a 8 números');return}Datos.ls.set('pin',hashPin(p));cerrarModal();toast('PIN guardado');break}
    case 'pin-quitar':Datos.ls.del('pin');toast('PIN quitado');break;
    case 'pin-entrar':if(hashPin($('#pin').value)===Datos.ls.get('pin',null)){S.bloqueado=false}else{toast('PIN incorrecto');return}break;
    case 'respaldo':UIX.compartirArchivo(`vinculo-respaldo-${hoy()}.json`,JSON.stringify(Datos.respaldo()),'application/json');return;
    case 'borrar-todo':if(await confirmar('Se borrarán todos los datos de Terapia2 de este teléfono. ¿Continuar?','Borrar')){await Recordatorio.programar({on:false});Datos.borrarTodo();S.tab=null}break;
    case 'demo-rol':Datos.demoRol(b.dataset.r);S.tab=null;S.hoy={};break;
    case 'demo-salir':Datos.salirDemo();S.tab=null;break;
    case 'pro-entrar':cerrarModal();Datos.setPro(true);if(Datos.cfg.modo==='demo')Datos.salirDemo();Datos.elegirModo('real');Datos.setRol('t');S.tab=null;break;
    case 'pro-demo':cerrarModal();Datos.setPro(true);await sembrarDemo();return;
    case 'pro-quitar':if(await confirmar('Este teléfono dejará de mostrar el acceso para terapeutas. Tus parejas guardadas no se borran.','Quitar')){Datos.setPro(false);if(Datos.cfg.modo==='demo')Datos.demoRol('a')}break;
  }}catch(x){toast(x.message||String(x),4000);console.error(x)}
  render()}

/* Gesto oculto: mantener presionado el logo 3 segundos abre el acceso profesional. */
(()=>{let t=null,x0=0,y0=0;const fin=()=>{clearTimeout(t);t=null};
  document.addEventListener('pointermove',ev=>{if(t&&Math.hypot(ev.clientX-x0,ev.clientY-y0)>12)fin()},true);
  document.addEventListener('pointerdown',ev=>{if(!ev.target.closest('[data-pro]'))return;fin();x0=ev.clientX;y0=ev.clientY;t=setTimeout(()=>{t=null;if(navigator.vibrate)navigator.vibrate(30);
    modal(`<h3>Acceso profesional</h3><p class="note">Para terapeutas. Este teléfono quedará habilitado para crear parejas y ver la información clínica.</p>
    <button class="btn pri" data-act="pro-entrar">Entrar como terapeuta</button><button class="btn" data-act="pro-demo">Demostración como terapeuta</button><button class="btn ghost" data-act="cerrar">Cancelar</button>`)},3000)});
  ['pointerup','pointercancel','scroll'].forEach(n=>document.addEventListener(n,fin,true));
  document.addEventListener('contextmenu',ev=>{if(ev.target.closest('[data-pro]'))ev.preventDefault()})})();
document.addEventListener('click',ev=>{const b=ev.target.closest('[data-act]');if(!b)return;ev.preventDefault();accion(b.dataset.act,b)});
document.addEventListener('input',ev=>{const t=ev.target;
  if(t.dataset.hoy&&t.dataset.k){const d=borrador(t.dataset.hoy);d[t.dataset.k]=+t.value;t.classList.remove('vacio');const v=document.querySelector(`[data-v="${t.dataset.hoy}-${t.dataset.k}"]`);if(v){v.innerHTML=valTxt(+t.value);v.classList.remove('vacio')}const av=document.getElementById('avance');if(av)av.innerHTML=avanceHTML();t.setAttribute('aria-valuetext',t.value+', '+NIVEL(+t.value));pintarSliders()}
  if(t.dataset.ali){S.ali.resp[t.dataset.ali]=+t.value;t.classList.remove('vacio');document.querySelector(`[data-v="ali-${t.dataset.ali}"]`).textContent=t.value;pintarSliders()}
  if(t.id==='h-aprecio')S.hoy._aprecio=t.value;if(t.id==='h-nota')S.hoy._nota=t.value});
document.addEventListener('change',ev=>{const t=ev.target;
  if(t.dataset.hoy&&t.dataset.tarea!=null){const d=borrador(t.dataset.hoy);const i=+t.dataset.tarea;d.hechas=d.hechas.filter(x=>x!==i);if(t.checked)d.hechas.push(i)}
  if(t.id==='imp'&&t.files[0]){t.files[0].text().then(x=>{Datos.restaurar(JSON.parse(x));toast('Respaldo restaurado');render()}).catch(x=>toast(x.message))}});
document.getElementById('modal').addEventListener('click',ev=>{if(ev.target.id==='modal')cerrarModal()});
document.addEventListener('keydown',ev=>{if(ev.key==='Escape')cerrarModal();if(ev.key==='Enter'&&ev.target.id==='pin')accion('pin-entrar',ev.target)});

Datos.on(()=>{if(S.silencio)return;
  const foco=document.activeElement;const escribiendo=foco&&(foco.tagName==='TEXTAREA'||(foco.tagName==='INPUT'&&!['range','checkbox'].includes(foco.type)));
  if(!$('#modal').hidden||escribiendo){$('#topbar').innerHTML=cabecera();return}
  render()});
const obs=new MutationObserver(()=>{if(S.tab==='pareja'&&S.sub==='datos'&&$('#vinc')&&!$('#vinc').dataset.ok){$('#vinc').dataset.ok=1;if(Datos.cfg.modo!=='demo')revisarVinculos();else $('#vinc').textContent=`Vinculados: ${nom('a')} ✓ · ${nom('b')} ✓ (demostración)`}});
obs.observe(document.getElementById('main'),{childList:true});

/* Al volver a la app: sincroniza y, si hay PIN, bloquea. */
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){if(Datos.cfg.modo)Datos.syncTodo().catch(()=>{})}
  else if(Datos.ls.get('pin',null)){S.bloqueado=true;render()}});

/* ===================== Demostración ===================== */
async function sembrarDemo(){toast('Preparando la demostración…',6000);S.silencio=true;try{
  Datos.elegirModo('demo');Datos.demoRol('t');
  const r=await Datos.crearPareja({a:'Andrés',b:'Camila'});const cod=r.codigo;
  const G=(d)=>{const x=new Date();x.setDate(x.getDate()-d);return MED.fecha(x)};
  Datos.guardar(cod,{id:'formulacion',tipo:'formulacion',motivo:'Discusiones frecuentes que escalan y distancia afectiva tras el nacimiento de su segundo hijo.',diagnostico:'Malestar relacional moderado. Ciclo perseguir–retirarse: Camila reclama atención y Andrés se retira al trabajo y al celular. Sin violencia en el tamizaje.',
    modelo:'eft',areas:['conflicto','distancia','comunicacion','tiempo'],ciclo:{a:'se retira',b:'persigue',desc:'Camila: soledad y miedo a no importar → reclamo. Andrés: sensación de fracaso → se calla y se aleja.'},deep:{},fortalezas:'Compromiso con la familia; humor compartido.',riesgos:'Sin violencia reportada. Cansancio por crianza.',
    casa:{mapas:1,carino:1,acercarse:2,perspectiva:1,conflicto:2,suenos:1,significado:0,confianza:0,compromiso:0},banderas:{},entrevistas:{ia:true,ib:true,historia:true,secretos:true,consumo:true},mundo:{a:'Padre distante; aprendió a resolver solo. Se siente evaluado.',b:'Familia cálida; teme quedar en segundo plano.'}},true);
  const base=['eft-ciclo','gottman-jinetes','gottman-mapas','comun-admiracion'];const ids=[];
  base.forEach((b,i)=>{const t=EVID.OBJETIVOS.find(x=>x.id===b);const id='ob-demo-'+i;ids.push(id);
    Datos.guardar(cod,{id,tipo:'objetivo',base:b,casa:t.casa,titulo:t.titulo,desc:t.desc,modelo:t.modelo,para:'ambos',peso:i===0?2:1,estado:'activo',indicadores:t.indicadores,gas:t.gas,tareas:t.tareas,orden:i,creado:Date.now()-50*864e5},true)});
  const sesiones=[42,35,28,21,14,7];
  sesiones.forEach((d,i)=>{const gas={};ids.forEach((id,j)=>{gas[id]=Math.max(-2,Math.min(2,Math.round(-2+i*.75+(j%2?-.4:.2))))});
    Datos.guardar(cod,{id:'se-demo-'+i,tipo:'sesion',fecha:G(d),gas,indicaciones:i===5?'Esta semana: cuando aparezca el ciclo, digan "estamos en el ciclo" y tomen la pausa de 20 minutos. Mantengan la conversación diaria sin pantallas.':''},true);
    Datos.guardar(cod,{id:'ns-se-demo-'+i,tipo:'notaSesion',ref:'se-demo-'+i,fecha:G(d),texto:i===5?'Primer ablandamiento de Camila; Andrés logra decir que se siente insuficiente.':'Trabajo de desescalada del ciclo.'},true)});
  await Datos.sync(cod);
  const rnd=(s=>()=>(s=(s*16807)%2147483647)/2147483647)(7);
  for(const p of['a','b']){Datos.demoRol(p);await Datos.unirse(cod,r.clavePareja,p);
    for(let d=44;d>=1;d--){if(rnd()<.22)continue;const prog=(44-d)/44;
      ids.forEach((id,j)=>{const b=p==='a'?2.5:3.5,sesgo=p==='a'?1.2:0;const v=x=>Math.max(0,Math.min(10,Math.round(x)));
        Datos.guardar(cod,{id:`ev-${p}-${id}-${G(d)}`,tipo:'evaluacion',objetivo:id,fecha:G(d),propio:v(b+sesgo+prog*5+rnd()*2-1-(j===1?.8:0)),otro:v((p==='a'?3.5:2.5)+prog*4.5+rnd()*2-1),hechas:rnd()<.6?[0]:[]},true)})}
    [42,35,28,21,14,7,1].forEach((d,i)=>{const items=p==='a'?[2,2,2,2].map((x,k)=>Math.min(5,x+Math.floor(i*.5+rnd()))):[1,2,1,2].map((x,k)=>Math.min(5,x+Math.floor(i*.55+rnd())));
      Datos.guardar(cod,{id:`csi-${p}-${G(d)}`,tipo:'csi',fecha:G(d),items,total:MED.csiTotal(items)},true)});
    Datos.guardar(cod,{id:`sg-${p}-${G(44)}`,tipo:'seguridad',fecha:G(44),resp:{fisica:false,miedo:false,control:false,forzar:false,inseguro:false}},true);
    for(let d=30;d>=1;d--){if(rnd()<.3)continue;const prog=(30-d)/30;const J=['critica','desprecio','defensa','evasion'].filter((k,i)=>rnd()<(p==='a'?[.3,.08,.5,.6][i]:[.6,.15,.3,.1][i])*(1.1-prog));const A=['inicio','aprecio','responsabilidad','calma'].filter(()=>rnd()<.2+prog*.6);
      Datos.guardar(cod,{id:`ji-${p}-${G(d)}`,tipo:'jinetes',fecha:G(d),jinetes:J,antidotos:A},true)}
    Datos.guardar(cod,{id:`pa-${p}-demo`,tipo:'pausa',fecha:G(9),inicio:Date.now()-9*864e5,vuelve:Date.now()-9*864e5+18e5,minutos:30},true);
    Datos.guardar(cod,{id:`ic-${p}-demo`,tipo:'incidente',fecha:G(6),titulo:'La discusión del cumpleaños de mi mamá',sentimientos:p==='a'?['a la defensiva','criticado/a','desbordado/a']:['sola','ignorado/a','triste'].map(x=>x==='sola'?'solo/a':x),
      realidad:p==='a'?'Llegué agotado y sentí que todo lo que hacía estaba mal.':'Organicé todo sola y sentí que no te importaba.',valido:p==='a'?'Entiendo que te sentiste sola con la organización.':'Entiendo que llegaste muy cansado del trabajo.',
      detonantes:p==='a'?'Me recuerda cuando mi papá me corregía todo.':'Me pasa cuando siento que soy la única que se preocupa.',responsabilidad:p==='a'?'Me encerré en el celular en vez de decir que estaba agotado.':'Empecé con un reproche en vez de pedir ayuda.',plan:p==='a'?'Avisaré cuando llegue agotado y pediré 20 minutos.':'Pediré ayuda con anticipación y con inicio suave.'},true);
    Datos.guardar(cod,{id:`in-${p}`,tipo:'inicial',fecha:G(44),casa:p==='a'?{mapas:2,carino:2,acercarse:2,perspectiva:2,conflicto:1,suenos:2,significado:3,confianza:3,compromiso:4}:{mapas:1,carino:1,acercarse:1,perspectiva:1,conflicto:1,suenos:1,significado:2,confianza:3,compromiso:3},areas:p==='a'?{conflicto:3,distancia:2,comunicacion:2,tiempo:2,crianza:1}:{conflicto:3,distancia:3,afecto:3,comunicacion:2,tiempo:3},meta:p==='a'?'Discutir menos.':'Sentir que le importo.'},true);
    Datos.guardar(cod,{id:`al-${p}-se-demo-4`,tipo:'alianza',sesion:'se-demo-4',fecha:G(13),resp:{escuchado:p==='a'?6:9,temas:p==='a'?5:8,enfoque:7,general:p==='a'?6:9},texto:p==='a'?'Siento que hablamos más de mí que de ella.':''},true);
    Datos.guardar(cod,{id:`ap-${p}-${G(1)}`,tipo:'aprecio',fecha:G(1),texto:p==='a'?'Que me esperara despierta para conversar.':'Que dejara el celular en la cena y me preguntara por mi día.'},true);
    await Datos.sync(cod)}
  Datos.demoRol(esPro()?'t':'a');await Datos.sync(cod)}finally{S.silencio=false}S.tab=esPro()?'pareja':'hoy';S.sub='resumen';toast(esPro()?'Demostración lista. Cambia de rol arriba.':'Demostración lista. Arriba puedes ver la app como cada miembro de la pareja.',3500);render()}

/* ===================== Arranque ===================== */
(async function(){
  if(Datos.ls.get('pin',null))S.bloqueado=true;
  render();
  try{await Upd.init()}catch(x){}
  if(Datos.cfg.modo)Datos.syncTodo().then(render).catch(()=>{});
  if(rol()&&rol()!=='t'){const r=Datos.ls.get('recordatorio',null);if(r&&r.on)Recordatorio.programar(r)}
})();
