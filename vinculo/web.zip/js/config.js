/* Configuración de Vínculo.
   VINCULO_SERVIDOR_URL: dirección del servidor de sincronización (ver servidor/vinculo-servidor.gs).
   Vacío = cada usuario la pega en Ajustes → Servidor. */
window.VINCULO_SERVIDOR_URL='';
