/* Configuración de Terapia2.
   VINCULO_SERVIDOR_URL: dirección del servidor de sincronización (servidor propio: servidor/vps/LEEME.md).
   Vacío = cada usuario la pega en Ajustes → Servidor. */
window.VINCULO_SERVIDOR_URL='https://vinculo.gestionclinicaspc.cl/api';
