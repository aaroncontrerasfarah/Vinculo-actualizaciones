/* Configuración de Vínculo.
   VINCULO_SERVIDOR_URL: dirección del servidor de sincronización (ver servidor/vinculo-servidor.gs).
   Vacío = cada usuario la pega en Ajustes → Servidor. */
window.VINCULO_SERVIDOR_URL='https://script.google.com/macros/s/AKfycbz32P61exRL2pVCqlPhA_8UGq-yPWe_wJgaPKmBvwYquFUd7yJl491qWfUcrzqmx8_GCA/exec';
