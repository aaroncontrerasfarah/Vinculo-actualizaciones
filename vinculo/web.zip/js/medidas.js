/* Terapia2 — cálculos clínicos puros (sin interfaz). Se prueban con `npm test`. */
"use strict";
const MED=(()=>{
  const DIA=86400000;
  const hoy=()=>fecha(new Date());
  function fecha(d){d=new Date(d);const z=n=>String(n).padStart(2,'0');return`${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}`}
  function aDate(f){const[y,m,d]=String(f).split('-').map(Number);return new Date(y,m-1,d)}
  /* Lunes de la semana de una fecha AAAA-MM-DD */
  function semana(f){const d=aDate(f);const w=(d.getDay()+6)%7;d.setDate(d.getDate()-w);return fecha(d)}
  const prom=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:null;
  const r1=x=>x==null?null:Math.round(x*10)/10;

  /* Satisfacción semanal (cuestionario propio): suma de 4 ítems de 0 a 5 (0–20). Bajo 9 = zona baja, orientativa. */
  const SAT_BAJO=9;
  function csiTotal(items){if(!Array.isArray(items)||items.length!==4||items.some(v=>v==null||isNaN(v)))return null;return items.reduce((s,v)=>s+Number(v),0)}
  function csiNivel(t){if(t==null)return'';return t<SAT_BAJO?'satisfacción baja':'sin señales de satisfacción baja'}

  /* GAS: puntaje T de Kiresuk y Sherman (rho = 0,3). niveles: [{x:-2..2, w:peso}] */
  function gasT(niveles,rho=.3){const v=(niveles||[]).filter(n=>n&&n.x!=null&&!isNaN(n.x));if(!v.length)return null;
    const sw=v.reduce((s,n)=>s+(n.w||1),0),sw2=v.reduce((s,n)=>s+(n.w||1)**2,0),swx=v.reduce((s,n)=>s+(n.w||1)*n.x,0);
    return Math.round((50+10*swx/Math.sqrt((1-rho)*sw2+rho*sw*sw))*10)/10}

  const regs=(R,tipo)=>Object.values(R||{}).filter(r=>r&&!r.borrado&&r.tipo===tipo);
  const objetivosActivos=(R)=>regs(R,'objetivo').filter(o=>o.estado!=='archivado').sort((a,b)=>(a.orden||0)-(b.orden||0)||(a.creado||0)-(b.creado||0));
  const aplica=(o,rol)=>!o.para||o.para==='ambos'||o.para===rol;

  /* Serie semanal de un objetivo: para cada miembro, cómo se evalúa a sí mismo y cómo lo evalúa su pareja. */
  function serieObjetivo(R,objId){
    const ev=regs(R,'evaluacion').filter(e=>e.objetivo===objId);
    const sem=new Map();
    const add=(s,k,v)=>{if(v==null||isNaN(v))return;if(!sem.has(s))sem.set(s,{a_self:[],a_por_b:[],b_self:[],b_por_a:[]});sem.get(s)[k].push(Number(v))};
    for(const e of ev){const s=semana(e.fecha);const otro=e.autor==='a'?'b':'a';
      add(s,e.autor+'_self',e.propio);add(s,otro+'_por_'+e.autor,e.otro)}
    return[...sem.keys()].sort().map(s=>{const x=sem.get(s);return{semana:s,a_self:r1(prom(x.a_self)),a_por_b:r1(prom(x.a_por_b)),b_self:r1(prom(x.b_self)),b_por_a:r1(prom(x.b_por_a))}})}

  /* Brecha de percepción: autoevaluación menos evaluación de la pareja (promedio de las últimas n semanas). */
  function brecha(serie,rol,n=2){const ult=serie.slice(-n);const s=prom(ult.map(x=>x[rol+'_self']).filter(v=>v!=null)),o=prom(ult.map(x=>x[rol+'_por_'+(rol==='a'?'b':'a')]).filter(v=>v!=null));
    return s==null||o==null?null:r1(s-o)}

  function serieCSI(R){const out={a:[],b:[]};regs(R,'csi').forEach(c=>{const t=c.total??csiTotal(c.items);if(t!=null&&out[c.autor])out[c.autor].push({fecha:c.fecha,total:t})});
    out.a.sort((x,y)=>x.fecha<y.fecha?-1:1);out.b.sort((x,y)=>x.fecha<y.fecha?-1:1);return out}

  function ultimaSesion(R){return regs(R,'sesion').sort((a,b)=>a.fecha<b.fecha?1:-1)[0]||null}
  function serieGAS(R){const obs=objetivosActivos(R);return regs(R,'sesion').filter(s=>s.gas).sort((a,b)=>a.fecha<b.fecha?-1:1)
    .map(s=>({fecha:s.fecha,t:gasT(obs.filter(o=>s.gas[o.id]!=null).map(o=>({x:Number(s.gas[o.id]),w:o.peso||1})))})).filter(x=>x.t!=null)}

  /* Cuatro Jinetes y antídotos por semana: cuenta de días en que cada uno reportó usarlos. */
  function serieJinetes(R){const sem=new Map();
    regs(R,'jinetes').forEach(j=>{const s=semana(j.fecha);if(!sem.has(s))sem.set(s,{a_j:0,a_a:0,b_j:0,b_a:0,a_desp:0,b_desp:0});const x=sem.get(s);
      x[j.autor+'_j']+=(j.jinetes||[]).length;x[j.autor+'_a']+=(j.antidotos||[]).length;if((j.jinetes||[]).includes('desprecio'))x[j.autor+'_desp']++});
    return[...sem.keys()].sort().map(s=>Object.assign({semana:s},sem.get(s)))}
  /* Perfil de la Casa: promedio 0–4 por nivel para cada miembro, desde la evaluación inicial más reciente. */
  function perfilCasa(R){const out={a:null,b:null};for(const r of['a','b']){const i=regs(R,'inicial').filter(x=>x.autor===r&&x.casa).sort((x,y)=>x.fecha<y.fecha?-1:1).pop();if(i)out[r]=i.casa}return out}
  /* Niveles débiles: los que el terapeuta marcó como problema o por trabajar, o con autorreporte bajo (≤1) de alguno. */
  function casaDebil(R){const f=(R.formulacion&&!R.formulacion.borrado)?R.formulacion:{};const ev=f.casa||{};const p=perfilCasa(R);const out=new Set();
    Object.entries(ev).forEach(([k,v])=>{if(v>=1)out.add(k)});['a','b'].forEach(r=>{if(p[r])Object.entries(p[r]).forEach(([k,v])=>{if(v!=null&&v<=1)out.add(k)})});return[...out]}

  /* Días con registro en los últimos n días (adherencia) */
  function adherencia(R,rol,n=7,ref=hoy()){const lim=fecha(aDate(ref).getTime()-(n-1)*DIA);
    const dias=new Set(regs(R,'evaluacion').filter(e=>e.autor===rol&&e.fecha>=lim&&e.fecha<=ref).map(e=>e.fecha));
    return{dias:dias.size,de:n}}
  function ultimoRegistro(R,rol){const f=regs(R,'evaluacion').filter(e=>e.autor===rol).map(e=>e.fecha).sort();return f[f.length-1]||null}
  function diasDesde(f,ref=hoy()){if(!f)return null;return Math.round((aDate(ref)-aDate(f))/DIA)}

  /* Alertas para el terapeuta, de mayor a menor gravedad. */
  function alertas(R,ref=hoy()){
    const A=[];const rev=new Set(regs(R,'revision').map(x=>x.ref));const nom=r=>(regs(R,'pareja')[0]?.nombres||{})[r]||(r==='a'?'Él':'Ella');
    regs(R,'seguridad').forEach(s=>{const si=Object.entries(s.resp||{}).filter(([k,v])=>v===true).map(([k])=>({fisica:'agresión física',miedo:'miedo',control:'control',forzar:'presión sexual',inseguro:'no se siente seguro/a en sesión'}[k]||k));
      if(si.length&&diasDesde(s.fecha,ref)<=60&&!rev.has(s.id))A.push({nivel:3,tipo:'seguridad',rol:s.autor,id:s.id,txt:`${nom(s.autor)} respondió "sí" en preguntas de seguridad (${si.join(', ')}). Evaluar por separado antes de seguir en sesiones conjuntas.`})});
    const f=(R.formulacion&&!R.formulacion.borrado)?R.formulacion:{};
    if(f.banderas?.violenciaCaract)A.push({nivel:3,tipo:'contra',txt:'Violencia con control coercitivo marcada en la lista de chequeo: la terapia conjunta está contraindicada. Entrevistas individuales, plan de seguridad y derivación.'});
    if(f.banderas?.aventuraActiva)A.push({nivel:3,tipo:'contra',txt:'La relación extrapareja sigue activa: no avanzar con terapia conjunta hasta que termine (política de cero secretos).'});
    const desde7=fecha(aDate(ref).getTime()-6*DIA);
    for(const r of['a','b']){const d=regs(R,'jinetes').filter(j=>j.autor===r&&j.fecha>=desde7&&j.fecha<=ref&&(j.jinetes||[]).includes('desprecio')).length;
      if(d>=2)A.push({nivel:2,tipo:'desprecio',rol:r,txt:`${nom(r)} reporta desprecio ${d} días esta semana. El desprecio es el jinete que más predice la ruptura: prioricen cultivar el aprecio.`})}
    const csi=serieCSI(R);
    for(const r of['a','b']){const c=csi[r];if(c.length>=2){const d=c[c.length-1].total-c[c.length-2].total;if(d<=-4)A.push({nivel:2,tipo:'csi',rol:r,txt:`La satisfacción de ${nom(r)} bajó ${-d} puntos en la satisfacción semanal (de ${c[c.length-2].total} a ${c[c.length-1].total}).`})}
      if(c.length&&c[c.length-1].total<SAT_BAJO&&c.length>=3&&c.slice(-3).every(x=>x.total<SAT_BAJO))A.push({nivel:1,tipo:'csi',rol:r,txt:`${nom(r)} se mantiene en la zona baja de satisfacción en las últimas 3 semanas.`})}
    regs(R,'alianza').forEach(a=>{const v=Object.values(a.resp||{}).map(Number);if(v.length&&Math.min(...v)<=5&&diasDesde(a.fecha,ref)<=21)A.push({nivel:2,tipo:'alianza',rol:a.autor,txt:`${nom(a.autor)} evaluó bajo la última sesión (mínimo ${Math.min(...v)}/10). Conviene conversarlo al inicio de la próxima.`})});
    for(const o of objetivosActivos(R)){const s=serieObjetivo(R,o.id);if(!s.length)continue;
      for(const r of['a','b']){if(!aplica(o,r))continue;const b=brecha(s,r);if(b!=null&&Math.abs(b)>=3)A.push({nivel:1,tipo:'brecha',rol:r,txt:`"${o.titulo}": ${nom(r)} se evalúa ${b>0?'más alto':'más bajo'} de lo que lo ve su pareja (diferencia ${Math.abs(b)} puntos).`})}
      const ult=s.slice(-2);const bajos=['a','b'].filter(r=>aplica(o,r)&&ult.length===2&&ult.every(x=>x[r+'_self']!=null&&x[r+'_self']<4));
      if(bajos.length)A.push({nivel:1,tipo:'bajo',txt:`"${o.titulo}": cumplimiento bajo (menos de 4/10) dos semanas seguidas. Revisar si la meta es realista o hay obstáculos.`})}
    for(const r of['a','b']){const d=diasDesde(ultimoRegistro(R,r),ref);if(d==null){if(objetivosActivos(R).length)A.push({nivel:0,tipo:'sinreg',rol:r,txt:`${nom(r)} todavía no registra avances.`})}else if(d>=7)A.push({nivel:0,tipo:'sinreg',rol:r,txt:`${nom(r)} no registra avances hace ${d} días.`})}
    return A.sort((x,y)=>y.nivel-x.nivel)}

  /* Fusión de registros: gana la versión modificada más recientemente. */
  function fusionar(local,entrantes){const cambiados=[];for(const r of entrantes||[]){if(!r||!r.id)continue;const l=local[r.id];if(!l||(r.mod||0)>=(l.mod||0)){local[r.id]=r;cambiados.push(r.id)}}return cambiados}

  return{SAT_BAJO,serieJinetes,perfilCasa,casaDebil,fecha,hoy,semana,aDate,prom,csiTotal,csiNivel,gasT,serieObjetivo,brecha,serieCSI,serieGAS,ultimaSesion,adherencia,ultimoRegistro,diasDesde,alertas,objetivosActivos,aplica,regs,fusionar}})();
if(typeof module!=='undefined')module.exports=MED;
