/* Terapia2 — base clínica: modelos de terapia de pareja con evidencia, áreas de problema,
   biblioteca de objetivos (con escala de logro GAS de -2 a +2) y referencias.
   Todo el texto es redacción propia, basada en la literatura citada en REFERENCIAS. */
"use strict";
const EVID=(()=>{

const MODELOS={
  ibct:{nombre:'Terapia Conductual Integrativa de Pareja (IBCT)',corto:'IBCT',
    autores:'Christensen y Jacobson',
    idea:'Combina aceptación emocional y cambio conductual. Se formula el caso con el análisis DEEP: Diferencias, sensibilidades Emocionales, Estrés externo y Patrón de interacción.',
    evidencia:'Ensayo clínico más grande de terapia de pareja (134 parejas, seguimiento a 5 años). Su versión en línea (OurRelationship) tiene varios ensayos aleatorizados.',
    refs:['christensen2010','doss2016','roddy2020']},
  eft:{nombre:'Terapia Focalizada en las Emociones (EFT)',corto:'EFT',
    autores:'Johnson y Greenberg',
    idea:'Basada en el apego. Se identifica el ciclo negativo (p. ej., perseguir–retirarse), se accede a las emociones primarias y se reestructuran las interacciones para crear vínculos seguros. Tres etapas: desescalada, reestructuración y consolidación.',
    evidencia:'Varios metaanálisis de ensayos aleatorizados, con efectos de moderados a grandes y mantenidos a 2 años.',
    refs:['wiebe2016','rathgeber2019','spengler2022']},
  tcc:{nombre:'Terapia Cognitivo-Conductual de Pareja (TCC / TBCT)',corto:'TCC',
    autores:'Jacobson y Margolin; Baucom y Epstein',
    idea:'Aumentar conductas positivas (intercambio conductual), entrenar comunicación hablante–oyente y solución de problemas, y revisar atribuciones y expectativas negativas.',
    evidencia:'El modelo con más ensayos aleatorizados; base de la mayoría de los metaanálisis.',
    refs:['rathgeber2019','roddy2020','christensen2010']},
  gottman:{nombre:'Método Gottman',corto:'Gottman',
    autores:'John y Julie Gottman',
    idea:'Casa de la Relación Sólida: mapas de amor, cariño y admiración, acercarse a los intentos de conexión, inicio suave, reparación, autocalma y diálogo sobre problemas perpetuos.',
    evidencia:'Basado en décadas de investigación observacional con parejas. Según los autores, un ensayo aleatorizado mostró mejores resultados al combinar su taller con nueve sesiones de terapia; hay además ensayos pequeños (p. ej., infidelidad).',
    refs:['gottman2015','irvine2024']},
  comun:{nombre:'Principios comunes',corto:'Común',
    autores:'Benson, McGinn y Christensen',
    idea:'Elementos compartidos por los modelos eficaces: visión diádica del problema, modificar conductas disfuncionales, reducir la evitación emocional, mejorar la comunicación y promover fortalezas.',
    evidencia:'Los modelos con evidencia obtienen resultados similares entre sí; el monitoreo continuo con retroalimentación mejora los resultados.',
    refs:['benson2012','anker2009','roddy2020']}
};

/* Áreas de problema para el diagnóstico y la evaluación inicial de cada miembro. */
const AREAS={
  comunicacion:'Comunicación',
  conflicto:'Discusiones que escalan',
  distancia:'Distancia emocional',
  afecto:'Poco afecto o reconocimiento',
  confianza:'Confianza / infidelidad',
  intimidad:'Intimidad y sexualidad',
  crianza:'Crianza y coparentalidad',
  finanzas:'Dinero',
  hogar:'Tareas del hogar',
  familia:'Familia de origen / suegros',
  estres:'Estrés externo (trabajo, salud, mudanza)',
  tiempo:'Poco tiempo juntos',
  celos:'Celos',
  consumo:'Consumo de alcohol u otras sustancias',
  estancado:'Temas que se repiten sin solución',
  significado:'Metas, valores o proyectos que no compartimos'
};

/* Casa de la Relación Sólida (Gottman): 7 pisos y 2 muros. Cada nivel trae un ítem breve de autorreporte
   (redacción propia, NO validado; sirve para orientar la evaluación, no reemplaza los cuestionarios oficiales). */
const CASA=[
  {id:'mapas',n:'Mapas de amor',d:'Conocer el mundo interior del otro: preocupaciones, sueños y estrés actual.',p:'Conozco bien lo que hoy preocupa, entusiasma y estresa a mi pareja.'},
  {id:'carino',n:'Cariño y admiración',d:'Sentir y expresar aprecio y respeto.',p:'Le expreso a mi pareja aprecio y admiración con frecuencia.'},
  {id:'acercarse',n:'Acercarse en vez de alejarse',d:'Responder a los pequeños llamados de atención y conexión.',p:'Cuando busco a mi pareja (un comentario, una mirada), suele responderme.'},
  {id:'perspectiva',n:'Perspectiva positiva',d:'Interpretar con buena fe los errores del otro. Mejora cuando mejoran los demás pisos.',p:'Cuando mi pareja se equivoca, tiendo a pensar que no fue con mala intención.'},
  {id:'conflicto',n:'Manejar el conflicto',d:'Inicio suave, aceptar influencia, reparar, calmarse y procesar las peleas.',p:'Podemos discutir un desacuerdo sin críticas, desprecio ni portazos.'},
  {id:'suenos',n:'Hacer realidad los sueños',d:'Conocer y apoyar las aspiraciones del otro, incluso las que hay dentro de un conflicto.',p:'Siento que mi pareja conoce y apoya mis sueños.'},
  {id:'significado',n:'Significado compartido',d:'Rituales, roles, metas y símbolos que construyen un "nosotros".',p:'Tenemos rituales, metas y valores que sentimos como nuestros.'},
  {id:'confianza',n:'Confianza',muro:true,d:'Saber que el otro estará ahí y actuará pensando en ambos.',p:'Confío en que mi pareja estará ahí cuando la necesite.'},
  {id:'compromiso',n:'Compromiso',muro:true,d:'Lealtad y cuidar la relación como lo más valioso.',p:'Siento que ambos estamos comprometidos con esta relación.'}
];
/* Señales de alarma para la lista de chequeo del terapeuta (segundo, tercer y noveno principios). */
const BANDERAS=[
  {id:'violenciaCaract',n:'Violencia con control coercitivo (caracterológica)',grave:true,txt:'La terapia conjunta está contraindicada: entrevistas individuales, plan de seguridad y derivación.'},
  {id:'violenciaSit',n:'Violencia situacional (sin control ni miedo)',grave:false,txt:'Puede tratarse en pareja con evaluación cuidadosa y foco en calmarse y manejar el conflicto.'},
  {id:'aventuraActiva',n:'Relación extrapareja que continúa',grave:true,txt:'No iniciar terapia conjunta hasta que termine; mantener la política de cero secretos.'},
  {id:'consumo',n:'Consumo problemático de alcohol o drogas',grave:false,txt:'Evaluar y coordinar tratamiento del consumo.'},
  {id:'psicopatologia',n:'Psicopatología individual que interfiere',grave:false,txt:'Derivar a tratamiento individual en paralelo; la psicosis activa contraindica la terapia conjunta.'},
  {id:'caos',n:'Caos: hostilidad intensa y continua',grave:false,txt:'Empezar por calmarse y por procesar incidentes antes de trabajar temas de fondo.'},
  {id:'desajuste',n:'Desajustes fundamentales (p. ej., hijos sí/no)',grave:false,txt:'Explorar los sueños detrás de cada posición; puede no haber acuerdo posible.'},
  {id:'unoSaliendo',n:'Uno de los dos ya decidió separarse',grave:false,txt:'Considerar terapia de discernimiento antes de la terapia de pareja.'}
];
/* Principios de la terapia de pareja efectiva, adaptados de Gottman y Gottman (2015) y resumidos con
   palabras propias, y dónde se aplican en la app. */
const PRINCIPIOS=[
  {n:1,t:'Usar métodos basados en la investigación',app:'La biblioteca de objetivos viene de modelos con evidencia, y la app mide el avance con escalas.'},
  {n:2,t:'Evaluar primero, decidir el tratamiento después',app:'Evaluación inicial de cada miembro, perfil de la Casa de la Relación Sólida y lista de chequeo clínica antes de elegir objetivos.'},
  {n:3,t:'Comprender el mundo interior de cada uno',app:'Registro de entrevistas individuales, historia de cada uno y política de cero secretos en el diagnóstico.'},
  {n:4,t:'Trazar la ruta del tratamiento',app:'La "ruta" muestra la casa con sus fortalezas y problemas, y conecta cada objetivo con el piso que trabaja.'},
  {n:5,t:'Calmarse primero, intervenir después',app:'Botón "Necesito una pausa": aviso a la pareja, hora de regreso y ejercicio de respiración (pausa de 30 minutos a 24 horas).'},
  {n:6,t:'Procesar los incidentes lamentables',app:'Ejercicio guiado de 5 pasos: sentimientos, realidades, detonantes, responsabilidad y plan.'},
  {n:7,t:'Cambiar los Cuatro Jinetes por formas suaves de manejar el conflicto',app:'Registro diario de crítica, desprecio, defensividad y evasión, y de sus antídotos; gráfico para el terapeuta.'},
  {n:8,t:'Fortalecer la amistad y la intimidad',app:'Preguntas abiertas para actualizar los mapas de amor, conversación para bajar el estrés y rituales de conexión.'},
  {n:9,t:'Suspender el juicio moral ante una infidelidad',app:'Objetivos por fases (reparación, sintonía y nuevo vínculo), alerta si la otra relación sigue y política de cero secretos.'},
  {n:10,t:'Profundizar para crear significado compartido',app:'Ejercicio "el sueño dentro del conflicto" y objetivos de rituales, roles y metas comunes.'},
  {n:11,t:'Mantener la esperanza',app:'Progreso visible para la pareja y el terapeuta, y mensajes de ánimo entre sesiones.'}
];
const JINETES=[
  {id:'critica',n:'Crítica',a:'inicio',an:'Inicio suave',ad:'Hablar de lo que siento y necesito, no de cómo es el otro.'},
  {id:'desprecio',n:'Desprecio',a:'aprecio',an:'Aprecio',ad:'Expresar respeto y reconocer lo que el otro hace bien.'},
  {id:'defensa',n:'Actitud defensiva',a:'responsabilidad',an:'Asumir mi parte',ad:'Reconocer aunque sea una parte del problema.'},
  {id:'evasion',n:'Evasión (cerrarme)',a:'calma',an:'Pausa para calmarme',ad:'Pedir una pausa, calmarme y volver a la hora acordada.'}
];
const SENTIMIENTOS=['a la defensiva','no escuchado/a','herido/a','desbordado/a','enojado/a','triste','no querido/a','incomprendido/a','criticado/a','preocupado/a','asustado/a','solo/a','ignorado/a','avergonzado/a','impotente','frustrado/a','culpable','con ganas de irme'];
const PREGUNTAS_MAPAS=['¿Qué es lo que más te preocupa estos días?','¿Qué te gustaría que pasara en tu vida este año?','¿Cómo te has sentido en el trabajo (o en lo que haces) últimamente?','¿Qué cosa pequeña te ha alegrado esta semana?','Si pudieras cambiar algo de nuestra rutina, ¿qué sería?','¿Qué recuerdo de nuestra historia te gusta volver a contar?','¿Qué necesitas de mí cuando estás estresado/a?','¿Hay algo que hayas querido contarme y no has encontrado el momento?','¿Qué sueño tuyo crees que he olvidado?','¿Cómo te imaginas nuestra vida en diez años?'];
/* Preguntas de redacción propia para explorar lo que hay detrás de un conflicto que se repite. */
const PREGUNTAS_SUENO=['¿Desde cuándo te importa tanto este tema?','¿Qué parte de tu historia o de tu familia aparece cuando hablamos de esto?','¿Qué emociones se te mueven cuando tocamos este tema?','¿Cómo sería para ti una buena salida, aunque no sea perfecta?','¿Qué estás cuidando o protegiendo con tu postura?','¿Qué te ayudaría a sentir que te tomo en serio en esto?','¿Qué te preocupa que pase si cedes un poco?'];

/* Biblioteca de objetivos. gas: niveles -2..+2 (Kiresuk y Sherman); 0 = resultado esperado.
   para: 'ambos' por defecto (el terapeuta puede asignarlo a uno). */
const OBJETIVOS=[
 {id:'tcc-hablante',casa:'conflicto',modelo:'tcc',areas:['comunicacion','conflicto'],
  titulo:'Conversar con turnos de hablante y oyente',
  desc:'Quien habla expresa lo que siente en primera persona y de forma breve; quien escucha resume lo que oyó antes de responder.',
  indicadores:['Habla en primera persona ("yo siento…", "a mí me pasa…")','Resume lo que escuchó antes de dar su opinión','No interrumpe ni descalifica'],
  gas:{'-2':'Ninguna conversación con turnos; las conversaciones terminan en discusión','-1':'Un intento en la semana, que se interrumpió','0':'Dos conversaciones de 15 minutos con turnos respetados','1':'Tres conversaciones; ambos se sienten escuchados','2':'Usan los turnos solos cada vez que hay un desacuerdo'},
  tareas:[{t:'Conversación de 15 min con turnos (quien tiene el objeto habla)',f:'2 veces por semana'}]},
 {id:'tcc-problemas',casa:'conflicto',modelo:'tcc',areas:['conflicto','finanzas','hogar','crianza'],
  titulo:'Resolver problemas en cinco pasos',
  desc:'Definir un problema concreto, proponer ideas sin criticarlas, evaluarlas juntos, llegar a un acuerdo por escrito y revisarlo después.',
  indicadores:['Elige un solo problema concreto por conversación','Propone al menos una solución','Cumple el acuerdo tomado'],
  gas:{'-2':'Los problemas se evitan o terminan en pelea','-1':'Se conversa, pero sin llegar a acuerdo','0':'Un acuerdo escrito en la semana','1':'Un acuerdo escrito y cumplido','2':'Dos o más acuerdos cumplidos y revisados'},
  tareas:[{t:'Reunión de pareja de 20 min con la pauta de 5 pasos',f:'1 vez por semana'}]},
 {id:'tcc-carino',casa:'carino',modelo:'tcc',areas:['afecto','distancia'],
  titulo:'Aumentar gestos de cariño (intercambio conductual)',
  desc:'Cada uno hace una lista de pequeñas acciones que el otro valora y realiza varias por semana, sin esperar que el otro lo haga primero.',
  indicadores:['Realiza gestos de la lista del otro','Nota y agradece los gestos que recibe'],
  gas:{'-2':'Ningún gesto en la semana','-1':'1–2 gestos','0':'3–4 gestos en la semana','1':'5–6 gestos y se agradecen','2':'Un gesto diario y se agradecen'},
  tareas:[{t:'Hacer un gesto de la lista de mi pareja',f:'diario'},{t:'Agradecer en voz alta un gesto recibido',f:'diario'}]},
 {id:'tcc-atribuciones',casa:'perspectiva',modelo:'tcc',areas:['conflicto','celos','confianza'],
  titulo:'Revisar interpretaciones negativas',
  desc:'Ante un malestar, registrar la situación, lo que pensé de mi pareja y una explicación alternativa menos culpabilizadora.',
  indicadores:['Registra al menos una situación','Encuentra una explicación alternativa','Pregunta antes de suponer'],
  gas:{'-2':'Sin registros; se atribuye mala intención con frecuencia','-1':'Un registro sin alternativa','0':'Dos registros con explicación alternativa','1':'Tres registros y se conversa uno en pareja','2':'Pregunta antes de suponer de forma habitual'},
  tareas:[{t:'Registro situación – pensamiento – explicación alternativa',f:'2 veces por semana'}]},
 {id:'ibct-deep',casa:'mapas',modelo:'ibct',areas:['conflicto','comunicacion','distancia'],
  titulo:'Comprender el tema central (análisis DEEP)',
  desc:'Identificar las diferencias, las sensibilidades emocionales de cada uno, el estrés externo y el patrón de interacción que se repite.',
  indicadores:['Describe su sensibilidad emocional sin culpar','Reconoce la sensibilidad del otro'],
  gas:{'-2':'Cada uno ve el problema solo en el otro','-1':'Uno de los dos reconoce su parte','0':'Ambos describen el patrón y sus sensibilidades','1':'Lo describen y lo usan para entender una discusión','2':'Lo anticipan antes de que la discusión escale'},
  tareas:[{t:'Escribir: ¿qué me duele cuando discutimos y de dónde viene?',f:'1 vez por semana'}]},
 {id:'ibct-union',casa:'acercarse',modelo:'ibct',areas:['distancia','conflicto','afecto'],
  titulo:'Unión empática: mostrar la emoción "blanda"',
  desc:'Expresar la tristeza, el miedo o la soledad que hay detrás del enojo, en vez de acusar.',
  indicadores:['Expresa una emoción vulnerable','Responde con comprensión a la emoción del otro'],
  gas:{'-2':'Solo se expresan reproches','-1':'Se nombra la emoción pero con reproche','0':'Una conversación en la semana desde la emoción vulnerable','1':'Dos conversaciones y ambos se sienten comprendidos','2':'Se hace de forma espontánea en los momentos difíciles'},
  tareas:[{t:'Compartir una emoción vulnerable de la semana',f:'1 vez por semana'}]},
 {id:'ibct-distancia',casa:'conflicto',modelo:'ibct',areas:['conflicto','comunicacion'],
  titulo:'Distanciamiento unificado: mirar "nuestro patrón" juntos',
  desc:'Ponerle nombre al patrón que se repite y conversarlo como algo externo ("eso que nos pasa"), con algo de humor.',
  indicadores:['Usa el nombre acordado del patrón','Describe el patrón sin culpar'],
  gas:{'-2':'No se reconoce ningún patrón','-1':'Se reconoce después, con reproches','0':'Se nombra el patrón después de una discusión, sin culpar','1':'Se nombra durante la discusión y baja la tensión','2':'Se detecta antes y se evita la escalada'},
  tareas:[{t:'Revisar juntos un incidente usando el nombre del patrón',f:'1 vez por semana'}]},
 {id:'ibct-tolerancia',casa:'conflicto',modelo:'ibct',areas:['conflicto','estres'],
  titulo:'Tolerancia y autocuidado ante las recaídas',
  desc:'Anticipar que el patrón volverá a aparecer, ensayar cómo responder y cuidarse a sí mismo sin depender de que el otro cambie.',
  indicadores:['Tiene un plan para cuando aparezca el patrón','Hace algo de autocuidado en la semana'],
  gas:{'-2':'Cada recaída se vive como fracaso total','-1':'Hay plan, pero no se usa','0':'Se usa el plan al menos una vez','1':'Se usa el plan y se recuperan rápido','2':'Las recaídas son breves y se conversan con calma'},
  tareas:[{t:'Actividad de autocuidado individual',f:'2 veces por semana'}]},
 {id:'eft-ciclo',casa:'conflicto',modelo:'eft',areas:['conflicto','distancia','comunicacion'],
  titulo:'Identificar y desescalar el ciclo negativo',
  desc:'Reconocer el ciclo (por ejemplo, uno persigue y el otro se retira), ver el ciclo como el enemigo común y detenerlo a tiempo.',
  indicadores:['Dice "estamos en el ciclo" y propone una pausa','Reconoce su movimiento en el ciclo (perseguir o retirarse)'],
  gas:{'-2':'El ciclo escala varias veces por semana','-1':'Se reconoce el ciclo solo después','0':'Se detiene el ciclo al menos una vez en la semana','1':'Se detiene y luego se reparan','2':'El ciclo aparece poco y se detiene en minutos'},
  tareas:[{t:'Decir "estamos en el ciclo" y tomar 20 minutos de pausa acordada',f:'cuando ocurra'}]},
 {id:'eft-emociones',casa:'acercarse',modelo:'eft',areas:['distancia','afecto','intimidad'],
  titulo:'Expresar emociones primarias y necesidades de apego',
  desc:'Hablar de lo que hay bajo la reacción (miedo a no importar, a no estar a la altura) y pedir lo que se necesita de forma directa.',
  indicadores:['Pide de forma directa lo que necesita','Responde con cercanía cuando el otro se muestra vulnerable'],
  gas:{'-2':'No se expresan necesidades; solo críticas o silencio','-1':'Se intenta, pero el otro responde a la defensiva','0':'Una conversación de apego en la semana con respuesta cercana','1':'Dos conversaciones y ambos se sienten seguros','2':'Se piden y se dan consuelo de forma habitual'},
  tareas:[{t:'Conversación: "lo que más necesito de ti cuando…"',f:'1 vez por semana'}]},
 {id:'eft-are',casa:'acercarse',modelo:'eft',areas:['distancia','afecto','tiempo'],
  titulo:'Estar disponibles: accesibilidad, receptividad y compromiso',
  desc:'Mostrarse accesible, responder a la emoción del otro y estar presente cuando más se necesita.',
  indicadores:['Deja lo que hace para atender al otro','Pregunta cómo está el otro y escucha'],
  gas:{'-2':'Casi nunca se sienten disponibles','-1':'A veces, de forma irregular','0':'La mayoría de los días se sienten disponibles','1':'Casi todos los días','2':'Ambos se sienten seguros de contar con el otro'},
  tareas:[{t:'10 minutos diarios sin pantallas para preguntar "¿cómo estás de verdad?"',f:'diario'}]},
 {id:'eft-herida',casa:'confianza',modelo:'eft',areas:['confianza'],
  titulo:'Reparar una herida de apego',
  desc:'Quien fue herido describe el impacto; quien hirió escucha, reconoce el daño y expresa arrepentimiento; se reconstruye la confianza paso a paso.',
  indicadores:['Reconoce el daño sin justificarse','Expresa el dolor sin atacar'],
  gas:{'-2':'La herida se evita o se usa como arma','-1':'Se habla, pero con defensas','0':'Una conversación de reparación guiada en sesión','1':'Se reconoce el daño y aparece consuelo','2':'Hay perdón y se recupera la cercanía'},
  tareas:[{t:'Escribir lo que necesito para volver a confiar',f:'1 vez por semana'}]},
 {id:'gottman-acercarse',casa:'acercarse',modelo:'gottman',areas:['distancia','afecto','tiempo'],
  titulo:'Responder a los intentos de conexión',
  desc:'Notar los pequeños llamados de atención del otro (un comentario, una mirada, una pregunta) y responder acercándose en lugar de ignorarlos.',
  indicadores:['Responde a los comentarios del otro','Inicia pequeños momentos de conexión'],
  gas:{'-2':'La mayoría de los intentos se ignoran','-1':'Se responde a algunos','0':'Se responde a la mayoría','1':'Se responde a casi todos y se inician nuevos','2':'Ambos se sienten vistos a diario'},
  tareas:[{t:'Anotar un intento de conexión que noté y cómo respondí',f:'diario'}]},
 {id:'gottman-suave',casa:'conflicto',modelo:'gottman',areas:['conflicto','comunicacion'],
  titulo:'Empezar con suavidad los temas difíciles',
  desc:'Plantear un problema describiendo la situación y lo que siento, y pidiendo algo positivo, sin críticas a la persona.',
  indicadores:['Describe la situación sin culpar','Termina con una petición concreta'],
  gas:{'-2':'Los temas se plantean con crítica o desprecio','-1':'A veces con suavidad','0':'Los temas difíciles de la semana se plantean con suavidad','1':'Siempre con suavidad y el otro escucha','2':'Se hace de forma natural y sin escalar'},
  tareas:[{t:'Plantear un tema con: "Me siento… cuando… ¿podrías…?"',f:'cuando ocurra'}]},
 {id:'gottman-reparar',casa:'conflicto',modelo:'gottman',areas:['conflicto','estancado'],
  titulo:'Reparar y calmarse durante una discusión',
  desc:'Usar frases de reparación ("espera, empecemos de nuevo"). Si alguno se desborda (pulso acelerado, mandíbula apretada, ganas de huir), pedir una pausa de al menos 30 minutos y menos de 24 horas, con hora de regreso, haciendo algo que distraiga y calme en vez de seguir rumiando.',
  indicadores:['Pide una pausa con hora de regreso, sin buscar la última palabra','Durante la pausa hace algo que calma (caminar, música, respirar) y no rumia','Vuelve a la hora acordada','Acepta los intentos de reparación del otro'],
  gas:{'-2':'Las discusiones se desbordan sin pausa','-1':'Hay pausa, pero no se retoma','0':'Una pausa con retorno acordado en la semana','1':'Las pausas funcionan y se reparan','2':'Se reparan rápido sin necesidad de pausas largas'},
  tareas:[{t:'Usar el botón "Necesito una pausa" cuando me desborde',f:'cuando ocurra'},{t:'Identificar mi señal corporal de desborde',f:'1 vez por semana'}]},
 {id:'gottman-rituales',casa:'significado',modelo:'gottman',areas:['tiempo','distancia','estres'],
  titulo:'Rituales de conexión',
  desc:'Despedidas y reencuentros con atención, y una conversación diaria sobre el estrés del día, apoyando sin dar soluciones.',
  indicadores:['Despedida y reencuentro con contacto','Conversa sobre el día escuchando'],
  gas:{'-2':'Sin rituales','-1':'Rituales irregulares','0':'Ritual diario la mayoría de los días','1':'Ritual diario y una cita semanal','2':'Rituales estables que ambos valoran'},
  tareas:[{t:'Conversación de 20 min sobre el día (apoyo, sin soluciones)',f:'diario'},{t:'Cita o salida de pareja',f:'1 vez por semana'}]},
 {id:'gottman-jinetes',casa:'conflicto',modelo:'gottman',areas:['conflicto','comunicacion','afecto'],
  titulo:'Cambiar los Cuatro Jinetes por sus antídotos',
  desc:'Reconocer cuándo aparecen la crítica, el desprecio, la actitud defensiva o la evasión, y reemplazarlos por inicio suave, aprecio, asumir mi parte y pausas para calmarme.',
  indicadores:['Registra cada día qué jinetes usó','Usa al menos un antídoto cuando aparece un jinete','No usa desprecio (burla, sarcasmo, ojos en blanco)'],
  gas:{'-2':'Jinetes casi a diario, con desprecio','-1':'Jinetes frecuentes; antídotos ocasionales','0':'Los jinetes bajan y se usa un antídoto la mayoría de las veces','1':'Jinetes poco frecuentes y sin desprecio','2':'Los antídotos son la forma habitual de discutir'},
  tareas:[{t:'Registrar jinetes y antídotos del día (en "Hoy")',f:'diario'}]},
 {id:'gottman-rapoport',casa:'conflicto',modelo:'gottman',areas:['conflicto','comunicacion','estancado'],
  titulo:'Entender antes de persuadir',
  desc:'En un desacuerdo, uno habla con inicio suave sobre lo que siente y necesita; el otro toma notas, solo pregunta para entender, resume y valida ("desde tu punto de vista tiene sentido que…"). Luego cambian. Recién después buscan un acuerdo.',
  indicadores:['Resume la postura del otro hasta que el otro diga "sí, es eso"','Valida antes de dar su propia postura','Dice lo que necesita en positivo, no lo que no quiere'],
  gas:{'-2':'Cada uno defiende su postura sin escuchar','-1':'Se intenta, pero se interrumpe para rebatir','0':'Una conversación completa con resumen y validación de ambos','1':'Dos conversaciones y llegan a un acuerdo','2':'Lo hacen solos ante cualquier desacuerdo'},
  tareas:[{t:'Conversación de un tema: hablar, resumir, validar y cambiar de rol',f:'1 vez por semana'}]},
 {id:'gottman-incidente',casa:'conflicto',modelo:'gottman',areas:['conflicto','confianza','estancado'],
  titulo:'Procesar una pelea o incidente lamentable',
  desc:'Con calma y "desde el balcón", revisar una pelea pasada en cinco pasos: cómo me sentí, mi realidad (y validar parte de la del otro), qué me detonó, mi parte de responsabilidad y un plan para la próxima vez.',
  indicadores:['Habla de cómo se sintió sin explicar ni acusar','Valida al menos una parte de la realidad del otro','Reconoce su parte en el incidente','Propone algo concreto para la próxima vez'],
  gas:{'-2':'Las peleas no se conversan o se reabren con rabia','-1':'Se conversan, pero se vuelve a pelear','0':'Un incidente procesado completo en la semana','1':'Procesado y con un plan que se cumple','2':'Procesan los incidentes solos y rápido'},
  tareas:[{t:'Ejercicio "Procesar un incidente" en Ejercicios',f:'1 vez por semana'}]},
 {id:'gottman-influencia',casa:'conflicto',modelo:'gottman',areas:['conflicto','finanzas','hogar','crianza','estancado'],
  titulo:'Aceptar influencia y ceder en lo flexible',
  desc:'Distinguir lo que para mí es esencial de aquello en que puedo ser flexible, y abrirme a la opinión del otro para llegar a acuerdos en que ambos ganan algo.',
  indicadores:['Cambia en algo su postura después de escuchar al otro','Distingue lo esencial de lo flexible'],
  gas:{'-2':'Ninguno cede en nada','-1':'Cede uno solo, con resentimiento','0':'Un acuerdo en que ambos ceden algo','1':'Varios acuerdos y ambos se sienten considerados','2':'Ceder se vuelve natural para ambos'},
  tareas:[{t:'Escribir: lo esencial para mí y en qué puedo ser flexible sobre el tema',f:'1 vez por semana'}]},
 {id:'gottman-mapas',casa:'mapas',modelo:'gottman',areas:['distancia','tiempo','afecto'],
  titulo:'Actualizar los mapas de amor',
  desc:'Conocer cómo está hoy el otro: hacerse preguntas abiertas sobre preocupaciones, alegrías, estrés y sueños, y escuchar con curiosidad.',
  indicadores:['Hace al menos una pregunta abierta al día','Recuerda y retoma lo que el otro le contó'],
  gas:{'-2':'Casi no saben qué vive el otro','-1':'Conversaciones solo logísticas','0':'Una conversación con preguntas abiertas la mayoría de los días','1':'A diario y retoman lo conversado','2':'Ambos se sienten conocidos por el otro'},
  tareas:[{t:'Hacer una pregunta abierta de la lista de Ejercicios',f:'diario'}]},
 {id:'gottman-estres',casa:'mapas',modelo:'gottman',areas:['estres','distancia','tiempo'],
  titulo:'Conversación para bajar el estrés',
  desc:'Cada día, unos 20 minutos para hablar del estrés de fuera de la relación. Quien escucha se pone del lado del otro, muestra interés y comprensión, y no da consejos a menos que se los pidan.',
  indicadores:['Escucha sin dar consejos no pedidos','Se pone de su lado ("nosotros contra el problema")'],
  gas:{'-2':'No se habla del estrés o se critica al otro por estar estresado','-1':'Se habla, pero con consejos o juicios','0':'Conversación de apoyo 3 o más días en la semana','1':'Casi a diario y ambos se sienten apoyados','2':'Es un ritual estable'},
  tareas:[{t:'20 minutos: "¿cómo estuvo tu día?" escuchando sin aconsejar',f:'diario'}]},
 {id:'gottman-sueno',casa:'suenos',modelo:'gottman',areas:['estancado','significado','finanzas','crianza','familia'],
  titulo:'Descubrir el sueño dentro del conflicto',
  desc:'En un tema en que están atascados, cada uno cuenta qué valores, historia o sueño hay detrás de su postura, mientras el otro solo pregunta y escucha, sin intentar resolver todavía.',
  indicadores:['Cuenta el sueño o valor detrás de su postura','Escucha sin intentar convencer','Expresa qué parte del sueño del otro puede apoyar'],
  gas:{'-2':'El tema estancado provoca rechazo o distancia','-1':'Se habla, pero solo de posturas','0':'Una conversación de sueños en que ambos se sienten comprendidos','1':'Aparece un acuerdo temporal que honra ambos sueños','2':'Pueden convivir con el tema con humor y cariño'},
  tareas:[{t:'Conversación "el sueño dentro del conflicto" (Ejercicios)',f:'1 vez por semana'}]},
 {id:'gottman-significado',casa:'significado',modelo:'gottman',areas:['significado','tiempo','crianza'],
  titulo:'Crear significado compartido',
  desc:'Conversar y acordar rituales (comidas, despedidas, fines de semana), roles (como pareja, padres, amigos), metas de vida y símbolos que los representen como "nosotros".',
  indicadores:['Participa en la conversación de rituales y metas','Cumple los rituales acordados'],
  gas:{'-2':'Sin rituales ni metas comunes','-1':'Se conversan, pero no se concretan','0':'Un ritual nuevo acordado y cumplido','1':'Rituales y una meta común en marcha','2':'Ambos sienten que construyen algo juntos'},
  tareas:[{t:'Conversar un ritual o meta en común y anotarlo',f:'1 vez por semana'}]},
 {id:'gottman-infidelidad',casa:'confianza',modelo:'gottman',areas:['confianza','celos'],
  titulo:'Recuperación tras una infidelidad (reparación, sintonía y nuevo vínculo)',
  desc:'Solo si la otra relación terminó. Primero, quien fue traicionado expresa su dolor y pregunta, y quien traicionó responde con transparencia y arrepentimiento sin justificarse. Después trabajan cómo se distanciaron. Por último reconstruyen la intimidad: no se vuelve a la relación anterior, se construye una nueva.',
  indicadores:['Transparencia total y voluntaria de quien traicionó','Responde a las preguntas sin defensividad','Quien fue traicionado expresa el dolor sin desprecio'],
  gas:{'-2':'Contacto con la otra persona o mentiras nuevas','-1':'Transparencia parcial; las conversaciones terminan en pelea','0':'Transparencia completa y una conversación de reparación en la semana','1':'Baja la intensidad del dolor; comienzan a hablar de la relación','2':'Pueden hablar de construir una relación nueva'},
  tareas:[{t:'Cumplir los acuerdos de transparencia',f:'diario'},{t:'Conversación guiada en sesión sobre lo ocurrido',f:'1 vez por semana'}]},
 {id:'comun-admiracion',casa:'carino',modelo:'comun',areas:['afecto','distancia'],
  titulo:'Expresar aprecio y admiración',
  desc:'Decir en voz alta lo que se valora del otro, de forma específica.',
  indicadores:['Expresa aprecio específico','Recibe el aprecio sin desestimarlo'],
  gas:{'-2':'Ningún aprecio expresado','-1':'1 vez en la semana','0':'3 veces en la semana','1':'Casi a diario','2':'A diario y ambos lo notan'},
  tareas:[{t:'Decir algo específico que valoro de mi pareja',f:'diario'}]},
 {id:'confianza-transparencia',casa:'confianza',modelo:'comun',areas:['confianza','celos'],
  titulo:'Reconstruir la confianza con acuerdos de transparencia',
  desc:'Acordar en sesión qué transparencia se ofrecerá por un tiempo, cumplirla de forma voluntaria y revisar el acuerdo.',
  indicadores:['Cumple los acuerdos de transparencia','Expresa el dolor sin interrogatorios repetidos'],
  gas:{'-2':'Acuerdos incumplidos o sin acuerdos','-1':'Cumplimiento parcial','0':'Acuerdos cumplidos durante la semana','1':'Cumplidos y la ansiedad disminuye','2':'Se puede empezar a flexibilizar el acuerdo'},
  tareas:[{t:'Cumplir el acuerdo de transparencia de la sesión',f:'diario'}]},
 {id:'crianza-equipo',casa:'significado',modelo:'comun',areas:['crianza'],
  titulo:'Funcionar como equipo en la crianza',
  desc:'Acordar reglas y respuestas comunes con los hijos, no desautorizarse frente a ellos y conversar los desacuerdos en privado.',
  indicadores:['Respeta los acuerdos de crianza','Conversa los desacuerdos en privado'],
  gas:{'-2':'Se desautorizan frente a los hijos','-1':'Hay acuerdos, pero se rompen','0':'Se cumplen los acuerdos esta semana','1':'Se cumplen y se revisan juntos','2':'Los hijos perciben un frente común'},
  tareas:[{t:'Reunión breve de coordinación de crianza',f:'1 vez por semana'}]},
 {id:'estres-diadico',casa:'mapas',modelo:'comun',areas:['estres','tiempo'],
  titulo:'Afrontar juntos el estrés externo',
  desc:'Contar el estrés propio, escuchar el del otro y ofrecer el apoyo que el otro pide (escucha, ayuda práctica o distracción).',
  indicadores:['Comparte su estrés a tiempo','Pregunta qué tipo de apoyo necesita el otro'],
  gas:{'-2':'El estrés se descarga en la pareja','-1':'Se comparte, pero sin apoyo','0':'Se comparte y se apoya al menos 2 veces','1':'Apoyo frecuente y ajustado a lo pedido','2':'Se sienten equipo frente al estrés'},
  tareas:[{t:'Preguntar: "¿qué te ayudaría ahora: escucharte, ayudarte o distraernos?"',f:'cuando ocurra'}]},
 {id:'intimidad-cercania',casa:'acercarse',modelo:'comun',areas:['intimidad','afecto'],
  titulo:'Recuperar la cercanía física y la intimidad',
  desc:'Aumentar el contacto físico afectuoso sin presión y conversar con respeto sobre deseos y límites.',
  indicadores:['Inicia contacto afectuoso sin presión','Conversa sobre deseos y límites'],
  gas:{'-2':'Sin contacto afectuoso','-1':'Contacto escaso','0':'Contacto afectuoso varios días de la semana','1':'Contacto frecuente y una conversación sobre intimidad','2':'Ambos se sienten satisfechos con su cercanía'},
  tareas:[{t:'Momento de contacto afectuoso sin expectativas',f:'3 veces por semana'}]},
 {id:'hogar-reparto',casa:'conflicto',modelo:'tcc',areas:['hogar','finanzas'],
  titulo:'Repartir tareas y gastos con un acuerdo claro',
  desc:'Listar las tareas o gastos, repartirlos con un acuerdo por escrito y revisarlo cada semana.',
  indicadores:['Cumple su parte del acuerdo','Revisa el acuerdo sin reproches'],
  gas:{'-2':'Sin acuerdo; reproches frecuentes','-1':'Acuerdo cumplido a medias','0':'Acuerdo cumplido esta semana','1':'Cumplido y revisado juntos','2':'Funciona sin necesidad de recordatorios'},
  tareas:[{t:'Revisión semanal del acuerdo de tareas o gastos',f:'1 vez por semana'}]}
];

/* Satisfacción semanal con la relación: cuestionario breve de redacción propia de Vínculo.
   4 preguntas de 0 a 5 (total 0 a 20). No es un instrumento validado ni tiene punto de corte clínico:
   sirve para seguir la tendencia de cada persona semana a semana. La "zona baja" (menos de 9, es decir,
   un promedio bajo "Algo") es orientativa y solo activa avisos para el terapeuta. */
const SATISF={
  nombre:'Satisfacción semanal con la relación',max:20,bajo:9,
  items:[
    {p:'Esta semana me sentí cerca de mi pareja.'},
    {p:'Esta semana sentí que nuestra relación me hace bien.'},
    {p:'Esta semana nos tratamos con cariño y respeto.'},
    {p:'Pensando en el rumbo de nuestra relación, me siento tranquilo/a.'}
  ].map(x=>Object.assign(x,{o:['Nada','Un poco','Algo','Bastante','Mucho','Completamente']}))
};

/* Preguntas de seguridad: confidenciales, solo las ve el terapeuta. Redacción propia. */
const SEGURIDAD=[
  {id:'fisica',p:'En el último mes, ¿tu pareja te empujó, golpeó, zamarreó o lastimó físicamente?'},
  {id:'miedo',p:'¿Has sentido miedo de tu pareja o de lo que pueda hacer?'},
  {id:'control',p:'¿Tu pareja controla tu dinero, tu teléfono o con quién te ves?'},
  {id:'forzar',p:'¿Te has sentido presionado/a u obligado/a a algo sexual que no querías?'},
  {id:'inseguro',p:'¿Te sientes inseguro/a de hablar con franqueza en las sesiones conjuntas?'}
];

/* Evaluación breve de la sesión. Preguntas de redacción y diseño propios, pensadas para terapia de pareja
   (equilibrio entre ambos miembros, tarea concreta, esperanza). No reproducen ni adaptan instrumentos con
   licencia como la Session Rating Scale (SRS); de la literatura se toma solo la idea de pedir
   retroalimentación en cada sesión (Anker, Duncan y Sparks, 2009). No es un instrumento validado. */
const ALIANZA=[
  {id:'escuchado',p:'Hoy pude decir lo que necesitaba decir'},
  {id:'temas',p:'Salgo con algo concreto para practicar esta semana'},
  {id:'enfoque',p:'Siento que mi terapeuta nos entiende a ambos por igual'},
  {id:'general',p:'Tengo más esperanza en nuestra relación que antes de la sesión'}
];

const RECURSOS=[
  {n:'133',d:'Carabineros — emergencias'},
  {n:'149',d:'Fono Familia de Carabineros — violencia intrafamiliar'},
  {n:'1455',d:'Orientación en violencia contra las mujeres (SernamEG), gratuito y confidencial'},
  {n:'+56 9 9700 7000',d:'WhatsApp de SernamEG, para escribir sin hablar en voz alta'},
  {n:'*4141',d:'Línea de prevención del suicidio (Minsal), gratuita, 24 horas'},
  {n:'600 360 7777',d:'Salud Responde (Minsal)'}
];

const REFERENCIAS={
  roddy2020:'Roddy, M. K., Walsh, L. M., Rothman, K., Hatch, S. G., y Doss, B. D. (2020). Meta-analysis of couple therapy: Effects across outcomes, designs, timeframes, and other moderators. Journal of Consulting and Clinical Psychology, 88(7), 583–596. https://doi.org/10.1037/ccp0000514',
  doss2020:'Doss, B. D., Roddy, M. K., Wiebe, S. A., y Johnson, S. M. (2022). A review of the research during 2010–2019 on evidence-based treatments for couple relationship distress. Journal of Marital and Family Therapy, 48(1), 283–306.',
  christensen2010:'Christensen, A., Atkins, D. C., Baucom, B., y Yi, J. (2010). Marital status and satisfaction five years following a randomized clinical trial comparing traditional versus integrative behavioral couple therapy. Journal of Consulting and Clinical Psychology, 78(2), 225–235. https://doi.org/10.1037/a0018132',
  doss2016:'Doss, B. D., Cicila, L. N., Georgia, E. J., Roddy, M. K., Nowlan, K. M., Benson, L. A., y Christensen, A. (2016). A randomized controlled trial of the web-based OurRelationship program. Journal of Consulting and Clinical Psychology, 84(4), 285–296. https://doi.org/10.1037/ccp0000063',
  wiebe2016:'Wiebe, S. A., y Johnson, S. M. (2016). A review of the research in Emotionally Focused Therapy for couples. Family Process, 55(3), 390–407. https://doi.org/10.1111/famp.12229',
  rathgeber2019:'Rathgeber, M., Bürkner, P.-C., Schiller, E.-M., y Holling, H. (2019). The efficacy of emotionally focused couples therapy and behavioral couples therapy: A meta-analysis. Journal of Marital and Family Therapy, 45(3), 447–463. https://doi.org/10.1111/jmft.12336',
  spengler2022:'Spengler, P. M., Lee, N. A., Wiebe, S. A., y Wittenborn, A. K. (2022). A comprehensive meta-analysis on the efficacy of emotionally focused couple therapy. Couple and Family Psychology: Research and Practice.',
  irvine2024:'Irvine, T. J., Peluso, P. R., Benson, K., Cole, C., Cole, D., Gottman, J. M., y Schwartz Gottman, J. (2024). A pilot study examining the effectiveness of Gottman Method Couples Therapy over treatment-as-usual for couples dealing with infidelity. The Family Journal, 32(1), 81–94.',
  benson2012:'Benson, L. A., McGinn, M. M., y Christensen, A. (2012). Common principles of couple therapy. Behavior Therapy, 43(1), 25–35.',
  anker2009:'Anker, M. G., Duncan, B. L., y Sparks, J. A. (2009). Using client feedback to improve couple therapy outcomes: A randomized clinical trial in a naturalistic setting. Journal of Consulting and Clinical Psychology, 77(4), 693–704. https://doi.org/10.1037/a0016062',
  kiresuk1968:'Kiresuk, T. J., y Sherman, R. E. (1968). Goal attainment scaling: A general method for evaluating comprehensive community mental health programs. Community Mental Health Journal, 4(6), 443–453.',
  gottman2015:'Gottman, J. S., y Gottman, J. M. (2015). 10 principles for doing effective couples therapy. W. W. Norton.',
  bradford2010:'Bradford, K. (2010). Screening couples for intimate partner violence. Journal of Family Psychotherapy, 21, 76–82.',
  mederos1999:'Bograd, M., y Mederos, F. (1999). Battering and couples therapy: Universal screening and selection of treatment modality. Journal of Marital and Family Therapy, 25(3), 291–312.'
};

/* Objetivos sugeridos según el diagnóstico: áreas elegidas y modelo preferido. */
function sugerir(areas,modelo,casaDebil){
  const A=new Set(areas||[]),K=new Set(casaDebil||[]);
  return OBJETIVOS.map(o=>{let s=0;o.areas.forEach(a=>{if(A.has(a))s+=2});if(o.casa&&K.has(o.casa))s+=2;if(modelo&&o.modelo===modelo)s+=1.5;if(o.modelo==='comun')s+=.3;return{o,s}})
    .filter(x=>x.s>=2).sort((a,b)=>b.s-a.s).map(x=>x.o)}

return{MODELOS,AREAS,CASA,BANDERAS,PRINCIPIOS,JINETES,SENTIMIENTOS,PREGUNTAS_MAPAS,PREGUNTAS_SUENO,OBJETIVOS,SATISF,SEGURIDAD,ALIANZA,RECURSOS,REFERENCIAS,sugerir}})();
if(typeof module!=='undefined')module.exports=EVID;
