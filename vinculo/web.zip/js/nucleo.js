/* Terapia2 — núcleo del servidor de sincronización.
   Es el mismo código en tres lugares:
   - servidor/vinculo-servidor.gs (Google Apps Script; se arma con tools/armar_servidor.sh),
   - el modo demostración de la app (servidor simulado dentro del teléfono),
   - las pruebas (npm test).
   No usa nada propio de un entorno: recibe el almacén (alm), las funciones de cifrado (cr) y opciones (op):
   - op.claveProfesional: hash de la clave que exige el servidor para crear parejas (vacío = cualquiera).
   - op.exigirConsentimiento: no deja unirse sin aceptar el consentimiento informado vigente. */
var NUCLEO = (function () {
  var TIPOS_TERAPEUTA = { pareja: 1, formulacion: 1, objetivo: 1, sesion: 1, notaSesion: 1, mensaje: 1, revision: 1 };
  var TIPOS_PAREJA = { evaluacion: 1, tarea: 1, aprecio: 1, pausa: 1, incidente: 1, jinetes: 1, csi: 1, seguridad: 1, alianza: 1, nota: 1, inicial: 1, consentimiento: 1 };
  /* Solo los ve el terapeuta (y quien los escribió). */
  var PRIVADOS = { seguridad: 1, alianza: 1, nota: 1, jinetes: 1, notaSesion: 1, formulacion: 1, inicial: 1, revision: 1, consentimiento: 1 };
  var MAX_REG = 20000, MAX_CAMBIOS = 500;
  var LETRAS = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

  function err(m) { return { ok: false, error: m }; }
  function codigoNuevo(cr) { var s = ''; for (var i = 0; i < 6; i++) s += LETRAS.charAt(cr.azar(LETRAS.length)); return s; }
  function clave(cr, n) { var s = ''; for (var i = 0; i < n; i++) s += LETRAS.charAt(cr.azar(LETRAS.length)); return s; }
  function limpiar(c) { return String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }

  function config(R) { var p = R.pareja; return p && !p.borrado ? p : {}; }

  function visible(r, rol, R) {
    if (rol === 't') return true;
    if (PRIVADOS[r.tipo] || r.privado === true) return r.autor === rol;
    var c = config(R);
    if ((r.tipo === 'evaluacion' || r.tipo === 'tarea') && r.autor !== rol) return !!c.compartirEval;
    if (r.tipo === 'csi' && r.autor !== rol) return !!c.compartirCSI;
    return true;
  }

  function puedeEscribir(r, rol, previo) {
    if (!r || typeof r.id !== 'string' || !r.id || r.id.length > 120 || typeof r.tipo !== 'string') return false;
    if (rol === 't') return !!TIPOS_TERAPEUTA[r.tipo] && (!previo || !!TIPOS_TERAPEUTA[previo.tipo]);
    if (!TIPOS_PAREJA[r.tipo] || r.autor !== rol) return false;
    return !previo || previo.autor === rol;
  }

  function autenticar(D, d, cr) {
    var rol = d.rol;
    if (rol === 't') return D.meta.hT === cr.hash(String(d.token || '')) ? null : 'Clave de terapeuta incorrecta';
    if (rol !== 'a' && rol !== 'b') return 'Rol no válido';
    var h = D.meta.tokens[rol];
    if (!h) return 'Este teléfono fue desvinculado. Vuelve a unirte con el código y la clave de la pareja.';
    return h === cr.hash(String(d.token || '')) ? null : 'Este teléfono ya no está vinculado a la pareja. Pide al terapeuta que libere tu lugar y vuelve a unirte.';
  }

  function atender(d, alm, cr, op) {
    op = op || {};
    if (!d || typeof d !== 'object') return err('Solicitud vacía');
    if (d.app !== 'vinculo') return err('Solicitud no válida');
    var codigo = limpiar(d.codigo), D;
    switch (d.accion) {
      case 'crear': {
        if (op.claveProfesional && cr.hash(String(d.claveProfesional || '')) !== op.claveProfesional)
          return { ok: false, error: 'Para crear parejas en este servidor se necesita la clave profesional (Ajustes → Servidor).', codigoError: 'clave_profesional' };
        var intentos = 0;
        do { codigo = codigoNuevo(cr); intentos++; } while (alm.existe(codigo) && intentos < 20);
        if (alm.existe(codigo)) return err('No se pudo crear el código, intenta de nuevo');
        var claveT = clave(cr, 12), claveP = clave(cr, 6);
        D = { meta: { codigo: codigo, creado: cr.ahora(), hT: cr.hash(claveT), hP: cr.hash(claveP), tokens: { a: null, b: null }, srv: 0 }, R: {} };
        alm.escribir(codigo, D);
        return { ok: true, codigo: codigo, claveTerapeuta: claveT, clavePareja: claveP };
      }
      case 'unirse': {
        D = alm.leer(codigo);
        if (!D) return err('No existe una pareja con ese código');
        if (D.meta.hP !== cr.hash(limpiar(d.clave))) return err('La clave de la pareja no coincide');
        if (d.rol !== 'a' && d.rol !== 'b') return err('Elige quién eres');
        if (D.meta.tokens[d.rol]) return err('Ese lugar ya está ocupado por otro teléfono. Si cambiaste de teléfono, pide al terapeuta que lo libere.');
        var cons = d.consentimiento && typeof d.consentimiento.version === 'string' ? d.consentimiento : null;
        if (op.exigirConsentimiento && !cons) return err('Para unirte debes aceptar el consentimiento informado.');
        var token = clave(cr, 24);
        D.meta.tokens[d.rol] = cr.hash(token);
        /* Constancia del consentimiento en el servidor (no la puede editar la app). */
        if (cons) { D.meta.consentimientos = D.meta.consentimientos || []; D.meta.consentimientos.push({ rol: d.rol, version: cons.version.slice(0, 40), fecha: cr.ahora() }); }
        alm.escribir(codigo, D);
        return { ok: true, token: token, codigo: codigo };
      }
      case 'liberar': {
        D = alm.leer(codigo); if (!D) return err('No existe una pareja con ese código');
        var e1 = autenticar(D, { rol: 't', token: d.token }, cr); if (e1) return err(e1);
        if (d.liberar !== 'a' && d.liberar !== 'b') return err('Indica qué lugar liberar');
        D.meta.tokens[d.liberar] = null; alm.escribir(codigo, D);
        return { ok: true };
      }
      case 'estado': {
        D = alm.leer(codigo); if (!D) return err('No existe una pareja con ese código');
        var e2 = autenticar(D, { rol: 't', token: d.token }, cr); if (e2) return err(e2);
        return { ok: true, vinculados: { a: !!D.meta.tokens.a, b: !!D.meta.tokens.b }, srv: D.meta.srv,
          consentimientos: D.meta.consentimientos || [], solicitudes: D.meta.solicitudes || [] };
      }
      /* Un miembro de la pareja pide eliminar sus datos. Lo resuelve el terapeuta, que debe conservar
         la ficha clínica el tiempo que exige la ley; la solicitud queda registrada con su fecha. */
      case 'solicitarEliminacion': {
        D = alm.leer(codigo); if (!D) return err('No existe una pareja con ese código');
        var e4 = autenticar(D, d, cr); if (e4) return err(e4);
        if (d.rol === 't') return err('Solo un miembro de la pareja puede solicitarlo');
        D.meta.solicitudes = D.meta.solicitudes || [];
        D.meta.solicitudes.push({ rol: d.rol, fecha: cr.ahora(), motivo: String(d.motivo || '').slice(0, 500) });
        alm.escribir(codigo, D);
        return { ok: true };
      }
      case 'resolverSolicitudes': {
        D = alm.leer(codigo); if (!D) return err('No existe una pareja con ese código');
        var e5 = autenticar(D, { rol: 't', token: d.token }, cr); if (e5) return err(e5);
        (D.meta.solicitudes || []).forEach(function (x) { if (!x.resuelta) x.resuelta = cr.ahora(); });
        alm.escribir(codigo, D);
        return { ok: true };
      }
      /* El terapeuta elimina la pareja completa del servidor. */
      case 'eliminar': {
        D = alm.leer(codigo); if (!D) return err('No existe una pareja con ese código');
        var e6 = autenticar(D, { rol: 't', token: d.token }, cr); if (e6) return err(e6);
        if (limpiar(d.confirmar) !== codigo) return err('Escribe el código de la pareja para confirmar');
        if (!alm.borrar) return err('Este servidor no permite eliminar parejas');
        alm.borrar(codigo);
        return { ok: true };
      }
      case 'sync': {
        D = alm.leer(codigo); if (!D) return err('No existe una pareja con ese código');
        var e3 = autenticar(D, d, cr); if (e3) return err(e3);
        var cambios = Array.isArray(d.cambios) ? d.cambios.slice(0, MAX_CAMBIOS) : [];
        var rechazados = [], aceptados = [], tocado = false;
        for (var i = 0; i < cambios.length; i++) {
          var r = cambios[i], previo = r && D.R[r.id];
          var tam = 0; try { tam = JSON.stringify(r).length; } catch (x) { tam = MAX_REG + 1; }
          if (tam > MAX_REG || !puedeEscribir(r, d.rol, previo)) { rechazados.push(r && r.id); continue; }
          if (d.rol === 't') r.autor = 't';
          if (previo && (previo.mod || 0) > (r.mod || 0)) { continue; }
          D.meta.srv++; r.srv = D.meta.srv; D.R[r.id] = r; aceptados.push(r.id); tocado = true;
        }
        if (tocado) alm.escribir(codigo, D);
        var desde = Number(d.desde) || 0, salida = [];
        for (var id in D.R) { var x = D.R[id]; if ((x.srv || 0) > desde && visible(x, d.rol, D.R)) salida.push(x); }
        return { ok: true, srv: D.meta.srv, registros: salida, aceptados: aceptados, rechazados: rechazados };
      }
    }
    return err('Acción desconocida');
  }

  return { atender: atender, visible: visible, puedeEscribir: puedeEscribir, limpiar: limpiar };
})();
if (typeof module !== 'undefined') module.exports = NUCLEO;
