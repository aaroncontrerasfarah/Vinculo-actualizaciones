/* Terapia2 — textos legales: política de privacidad, términos de uso y consentimiento informado.
   Una sola fuente para la app y para las páginas web del servidor (servidor/vps).
   Al cambiar el fondo de un texto, sube VERSION: los pacientes nuevos aceptan la versión vigente y
   el servidor guarda cuál aceptó cada uno.
   Los campos entre corchetes [ ] se completan antes de publicar (ver LANZAMIENTO.md, etapa 3).
   Revisión legal pendiente: esta redacción es una base de trabajo, no asesoría jurídica. */
"use strict";
var LEGAL = (function () {
  var VERSION = '2026-11';
  /* Aviso central: se muestra igual en la app, la página de descarga, los términos y el consentimiento. */
  var AVISO = 'Terapia2 es una herramienta de apoyo para usar dentro de un proceso de terapia de pareja con un profesional. Por sí sola, sin la guía de un psicólogo o psicóloga, no constituye un tratamiento.';
  var APK = 'https://github.com/aaroncontrerasfarah/vinculo-actualizaciones/raw/main/vinculo/vinculo.apk';
  var RESP = {
    nombre: 'Aarón Contreras Farah',
    rut: '15.371.009-0',
    correo: 'contacto@gestionclinicaspc.cl',
    domicilio: 'Santiago, Chile',
    sitio: 'https://gestionclinicaspc.cl',
    servidor: 'Amazon Web Services (AWS), en Estados Unidos, a través del proveedor de hosting contratado por el responsable'
  };

  var PRIVACIDAD = '' +
'<h3>Política de privacidad de Terapia2</h3>' +
'<p class="note">Versión ' + VERSION + '</p>' +
'<h4>1. Quién es responsable de tus datos</h4>' +
'<p>' + RESP.nombre + ', RUT ' + RESP.rut + ', con domicilio en ' + RESP.domicilio + ' (en adelante, "el responsable"). Contacto para todo lo relativo a tus datos: <b>' + RESP.correo + '</b>.</p>' +
'<p>Tu terapeuta es quien decide usar Terapia2 en tu tratamiento y es responsable de tu ficha clínica según la Ley 20.584.</p>' +
'<h4>2. Qué datos tratamos</h4>' +
'<ul><li>Nombre o iniciales con que tu terapeuta registró a la pareja.</li>' +
'<li>Tus registros en la app: cumplimiento de objetivos, tareas, aprecios, pausas, incidentes, Cuatro Jinetes y antídotos, satisfacción semanal con la relación, evaluación de las sesiones y notas.</li>' +
'<li>Tus respuestas a preguntas confidenciales de seguridad, incluidas preguntas sobre violencia.</li>' +
'<li>Lo que registra tu terapeuta: evaluación, diagnóstico, objetivos, notas de sesión e indicaciones.</li>' +
'<li>Datos técnicos mínimos: fecha y hora de cada sincronización y la dirección IP desde la que se conecta el teléfono, para seguridad.</li></ul>' +
'<p>Muchos de estos datos son <b>datos de salud</b>, que la ley chilena considera <b>datos sensibles</b>.</p>' +
'<h4>3. Para qué los usamos</h4>' +
'<p>Solo para apoyar tu terapia de pareja: que tú registres tu avance entre sesiones y que tu terapeuta lo revise para orientar el tratamiento. No los usamos para publicidad, no los vendemos, no hacemos perfiles comerciales y la app no usa servicios de analítica ni de publicidad.</p>' +
'<h4>4. Base legal</h4>' +
'<p>Tu <b>consentimiento expreso</b>, que das al unirte a tu terapia en la app (Ley 19.628 sobre protección de la vida privada y Ley 21.719 que la reforma). Puedes retirarlo cuando quieras (punto 8).</p>' +
'<h4>5. Quién puede ver qué</h4>' +
'<ul><li><b>Tu terapeuta</b> ve todos tus registros.</li>' +
'<li><b>Tu pareja</b> ve los objetivos, los mensajes del terapeuta, los aprecios, pausas e incidentes compartidos. Ve tus evaluaciones diarias y tu satisfacción semanal solo si tu terapeuta lo activa.</li>' +
'<li><b>Nadie más que tu terapeuta</b> ve tus preguntas confidenciales, Cuatro Jinetes, notas privadas y evaluación de las sesiones. Tu pareja nunca las ve.</li></ul>' +
'<p>Estas reglas las aplica el servidor, no el teléfono: aunque alguien modificara la app, no podría leer lo que no le corresponde.</p>' +
'<h4>6. Dónde se guardan y cómo se protegen</h4>' +
'<ul><li>En tu teléfono, para que la app funcione sin internet. Puedes protegerla con un PIN (Más → Bloqueo).</li>' +
'<li>En un servidor administrado por el responsable (' + RESP.servidor + '). Los datos viajan cifrados (HTTPS) y se guardan cifrados (AES-256). Las claves de acceso se guardan como huella criptográfica, nunca en texto plano.</li>' +
'<li>Si tu terapeuta usa el gestor clínico del responsable (' + RESP.sitio + '), puede ver allí un resumen de tu avance junto a tu ficha clínica.</li></ul>' +
'<p><b>Transferencia internacional:</b> el servidor está en Estados Unidos, por lo que tus datos se almacenan fuera de Chile. Se guardan cifrados con una clave que administra el responsable, de modo que el proveedor del servidor no puede leerlos, y el proveedor solo los aloja, sin usarlos para fines propios. Al aceptar el consentimiento autorizas expresamente esta transferencia.</p>' +
'<p>No transferimos tus datos a terceros salvo al proveedor del servidor, que solo los aloja, o cuando lo exija la ley o un tribunal.</p>' +
'<h4>7. Cuánto tiempo los guardamos</h4>' +
'<p>Mientras dure tu tratamiento. Después, los datos que forman parte de tu ficha clínica se conservan el plazo que exige la normativa de salud (Ley 20.584 y su reglamento) y luego se eliminan.</p>' +
'<h4>8. Tus derechos</h4>' +
'<p>Puedes pedir <b>acceso</b> a tus datos, su <b>rectificación</b>, <b>supresión</b>, <b>oposición</b> a su tratamiento, <b>portabilidad</b> y <b>bloqueo</b>, y retirar tu consentimiento:</p>' +
'<ul><li>Desde la app: Más → Privacidad y tus datos → "Descargar mis datos" o "Solicitar eliminación".</li>' +
'<li>Desde la web: ' + RESP.sitio.replace('https://', 'https://vinculo.') + '/eliminar-datos</li>' +
'<li>Por correo: ' + RESP.correo + '</li></ul>' +
'<p>Respondemos en un máximo de 30 días corridos. Si la información forma parte de tu ficha clínica, la eliminación se hará cuando termine el plazo legal de conservación; mientras tanto, se bloquea y deja de usarse. Si no quedas conforme, puedes reclamar ante la Agencia de Protección de Datos Personales.</p>' +
'<h4>9. Menores de edad</h4>' +
'<p>Terapia2 está pensada para adultos en terapia de pareja. No debe usarla una persona menor de 18 años.</p>' +
'<h4>10. Cambios</h4>' +
'<p>Si esta política cambia en algo importante, te lo avisaremos en la app y, cuando corresponda, te pediremos aceptarla de nuevo.</p>';

  var TERMINOS = '' +
'<h3>Términos de uso de Terapia2</h3>' +
'<p class="note">Versión ' + VERSION + '</p>' +
'<h4>1. Qué es Terapia2</h4>' +
'<p><b>' + AVISO + '</b></p>' +
'<p>La app se usa entre sesiones, por indicación de tu terapeuta. No reemplaza la terapia ni la atención de salud, no entrega diagnósticos automáticos y no sirve para emergencias. Las decisiones clínicas son de tu terapeuta.</p>' +
'<h4>2. Emergencias</h4>' +
'<p>Si tú u otra persona están en peligro, llama al 133 (Carabineros), al 149 (Fono Familia), al 1455 (violencia contra la mujer) o al *4141 (prevención del suicidio), o acude al servicio de urgencia más cercano.</p>' +
'<h4>3. Acceso</h4>' +
'<p>Para usar la app necesitas el código y la clave que te entrega tu terapeuta. Son personales: no los compartas. Cada lugar de la pareja admite un solo teléfono. Si cambias de teléfono, tu terapeuta puede liberar tu lugar.</p>' +
'<h4>4. Uso adecuado</h4>' +
'<p>Te comprometes a registrar información veraz, a no intentar acceder a datos de otras personas y a no usar la app para hostigar, controlar o vigilar a tu pareja.</p>' +
'<h4>5. Base clínica</h4>' +
'<p>Los contenidos se basan en modelos de terapia de pareja con respaldo científico, citados en "Fundamentos", y están escritos con palabras propias: no reproducen libros ni materiales de terceros. Algunos cuestionarios breves de la app orientan, pero no reemplazan los instrumentos oficiales.</p>' +
'<p>Terapia2 no está afiliada ni respaldada por los autores ni por las instituciones citadas (como The Gottman Institute o ICEEFT). Los nombres de métodos y modelos pertenecen a sus titulares y se usan solo para indicar el origen de las ideas.</p>' +
'<h4>6. Disponibilidad</h4>' +
'<p>Procuramos que el servicio esté siempre disponible, pero puede haber interrupciones por mantención o fallas. La app guarda tus registros en el teléfono y los envía cuando vuelve la conexión.</p>' +
'<h4>7. Propiedad intelectual</h4>' +
'<p>La app, su diseño y sus textos son de ' + RESP.nombre + '. Tus registros son tuyos y de tu proceso terapéutico.</p>' +
'<h4>8. Ley aplicable</h4>' +
'<p>Estos términos se rigen por la ley chilena. Contacto: ' + RESP.correo + '.</p>';

  var CONSENTIMIENTO = '' +
'<h3>Consentimiento informado para usar Terapia2</h3>' +
'<p class="note">Versión ' + VERSION + '</p>' +
'<p>Tu terapeuta te propone usar Terapia2 como apoyo a la terapia de pareja. <b>' + AVISO + '</b> Antes de aceptar, lee lo siguiente:</p>' +
'<ol><li><b>Qué harás:</b> registrar entre sesiones cómo avanzas en los objetivos acordados, cómo ves a tu pareja, tu satisfacción con la relación y tu evaluación de las sesiones, y usar ejercicios guiados.</li>' +
'<li><b>Quién lo verá:</b> tu terapeuta ve todo. Tu pareja ve solo lo compartido; nunca tus notas privadas ni tus respuestas confidenciales.</li>' +
'<li><b>Preguntas de seguridad:</b> te preguntaremos de forma confidencial si hay violencia o miedo en la relación. Si respondes que sí, tu terapeuta conversará contigo a solas antes de seguir con sesiones conjuntas.</li>' +
'<li><b>Es voluntario:</b> puedes dejar de usar la app o retirar este consentimiento cuando quieras, sin que eso afecte tu atención.</li>' +
'<li><b>Riesgos:</b> si otra persona accede a tu teléfono podría ver tu información. Te recomendamos activar el PIN de la app. Registrar cómo ves a tu pareja puede generar tensión; conversa con tu terapeuta cómo usar esa información.</li>' +
'<li><b>No es para emergencias:</b> ante riesgo, usa las líneas 133, 149, 1455 o *4141.</li>' +
'<li><b>Tus datos:</b> se guardan cifrados en un servidor ubicado en Estados Unidos y se tratan según la Política de privacidad. Son parte de tu ficha clínica y se conservan el plazo que exige la ley.</li></ol>' +
'<p>Al marcar la casilla declaro ser mayor de 18 años, haber leído este consentimiento, la Política de privacidad y los Términos de uso, y acepto <b>de forma expresa</b> que se traten mis datos de salud para los fines descritos, incluido su almacenamiento en un servidor en Estados Unidos.</p>';

  var LICENCIAS = '' +
'<h3>Licencias de terceros</h3>' +
'<p>Terapia2 incluye componentes de terceros que se distribuyen bajo licencias libres:</p>' +
'<ul><li><b>Archivo</b> (Omnibus-Type), <b>Instrument Sans</b> (Instrument) e <b>IBM Plex Mono</b> (IBM): tipografías bajo SIL Open Font License 1.1.</li>' +
'<li><b>Lucide</b>: el trazo de varios íconos se basa en Lucide, © Lucide Contributors, bajo licencia ISC. Íconos derivados de Feather, © Cole Bemis, bajo licencia MIT.</li>' +
'<li><b>Capacitor</b> (Ionic): marco para la app de Android, bajo licencia MIT.</li></ul>' +
'<p>Las licencias permiten el uso comercial siempre que se mantengan estos avisos. El texto completo de cada licencia está en el sitio de cada proyecto.</p>';

  /* Página de descarga para testers y pacientes (servidor: /descargar). */
  var DESCARGA = '' +
'<p style="font-size:19px;margin:0 0 4px"><b>Terapia de pareja</b></p>' +
'<p>La app que acompaña tu terapia de pareja entre sesiones: registra cómo avanzas, practica ejercicios y mantén a tu terapeuta al tanto.</p>' +
'<p style="background:rgba(42,114,135,.12);border-radius:12px;padding:12px 14px"><b>Importante:</b> ' + AVISO + '</p>' +
'<p><a href="' + APK + '" style="display:inline-block;background:var(--acc);color:#fff;text-decoration:none;font-weight:600;padding:14px 22px;border-radius:12px">Descargar para Android</a></p>' +
'<p class="note">Solo para Android. Necesitas el código y la clave que te entregó tu terapeuta.</p>' +
'<h4>Cómo instalarla</h4>' +
'<ol><li>Toca <b>Descargar para Android</b> desde tu teléfono (en Chrome).</li>' +
'<li>Si Chrome avisa que el archivo puede ser dañino, toca <b>Descargar de todas formas</b>.</li>' +
'<li>Abre el archivo. Si el teléfono pide permiso para <b>instalar apps desconocidas</b>, actívalo para Chrome y vuelve atrás.</li>' +
'<li>Si aparece <b>Play Protect</b>, toca <b>Más detalles</b> y luego <b>Instalar de todas formas</b>. Aparece porque la app todavía no está en Google Play.</li>' +
'<li>Abre Terapia2, toca <b>Unirme a mi terapia</b> y escribe el código y la clave de tu terapeuta.</li></ol>' +
'<p class="note">En algunos Samsung, si no aparece la opción de instalar, desactiva un momento Ajustes → Seguridad y privacidad → Bloqueador automático, y vuelve a activarlo después.</p>' +
'<p class="note"><a href="/privacidad">Política de privacidad</a> · <a href="/terminos">Términos de uso</a> · <a href="/eliminar-datos">Eliminar mis datos</a> · ' + RESP.correo + '</p>';

  /* Página web completa (para el servidor). */
  function pagina(titulo, cuerpo) {
    return '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
      '<title>' + titulo + ' · Terapia2</title><style>:root{color-scheme:light dark;--bg:#f4eee8;--ink:#2a2220;--muted:#6d605b;--acc:#8a3b5c}' +
      '@media (prefers-color-scheme:dark){:root{--bg:#161213;--ink:#efe6e1;--muted:#a8998f;--acc:#d27fa1}}' +
      'body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.6 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}' +
      'main{max-width:68ch;margin:0 auto;padding:32px 16px 64px}h1{color:var(--acc);font-size:28px;margin:0 0 8px}h3{font-size:24px;margin:24px 0 4px}' +
      'h4{font-size:18px;margin:28px 0 6px}.note{color:var(--muted);font-size:14px;margin:0}a{color:var(--acc)}li{margin-bottom:6px}' +
      'label{display:block;margin:14px 0 4px;font-weight:600}input,textarea{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #c9bdb4;border-radius:10px;font:inherit;background:transparent;color:inherit}' +
      'button{margin-top:18px;background:var(--acc);color:#fff;border:0;border-radius:11px;padding:12px 18px;font:600 16px system-ui;cursor:pointer}</style></head>' +
      '<body><main><h1>Terapia2</h1>' + cuerpo + '</main></body></html>';
  }

  return { VERSION: VERSION, AVISO: AVISO, APK: APK, DESCARGA: DESCARGA, RESP: RESP, PRIVACIDAD: PRIVACIDAD, TERMINOS: TERMINOS, CONSENTIMIENTO: CONSENTIMIENTO, LICENCIAS: LICENCIAS, pagina: pagina };
})();
if (typeof module !== 'undefined') module.exports = LEGAL;
